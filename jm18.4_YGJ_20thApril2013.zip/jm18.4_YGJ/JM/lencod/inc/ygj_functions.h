/*!
 ***************************************************************************
 * \file
 *    YGJ_functions.h (based upon img_dist_ssim.h)
 *
 * \author
 *    Main contributors (see contributors.h for copyright, address and affiliation details)
 *    
 *   
 *
 * \date
 *    14th May 2011
 *
 * \brief
 *    Headerfile to calculate structural similarity (SSIM) index and use myo-sobel (2x2) mask
 **************************************************************************
 */

#ifndef _YGJ_FUNCTIONS_H_
#define _YGJ_FUNCTIONS_H_

// YGJ 10th July 2012 - Test Hadamard Value to be within bounds of operating zone of PseudoSSIM and only then execute it. Range listed under comments in YGJ_SSIMBasedDistortion.
// Binary Friendly Numbers Used
// Min is 10 for 4x4 because PseudoSSIM model is based on 8x8 mode, the 8x8 model starts on from a minimum of 35, which approximately means that a 4x4 will be 8.75
// Max is 6k for 8x8. => 1.5k for 4x4.

#define YGJ_MIN4x4         10 //1 //4 //8 //64
#define YGJ_MAX4x4         1500 //640 //4080 //1420

#define YGJ_MIN4x8         20 //2 //8 // 16 //128
#define YGJ_MAX4x8         3000 //1280 //8160 //1840

#define YGJ_MIN8x4         20 //2 //8 //16 //128
#define YGJ_MAX8x4         3000 //1280 //8160 //1840

#define YGJ_MIN8x8         40 //4 //16 //32 //256
#define YGJ_MAX8x8         6000 //2960 //16320 //2000

#define YGJ_MIN8x16        80 //8 //32 //64 //512
#define YGJ_MAX8x16        12000 //5920 //32640 //4000

#define YGJ_MIN16x8        80 //8 //32 //64 //512
#define YGJ_MAX16x8        12000 //5920 //32640 //4000

#define YGJ_MIN16x16       320 //16 //64 //128 //1024
#define YGJ_MAX16x16       48000 //11840 //65280 //8000

#define YGJ_SSIMSub	   0 //4  // Number of Right Shift to allow to Substitute PSeudo SSIM Value in plae of SATD or SSE

//----------------

//extern int Set_YGJ_SATD4x4(int Value);
//extern int Get_YGJ_SATD4x4();
//
//extern int Set_YGJ_SATD8x8(int Value);
//extern int Get_YGJ_SATD8x8();
//
//extern int Set_YGJ_SATD16x16(int Value);
//extern int Get_YGJ_SATD16x16();
////-----
//
//extern int Set_YGJ_SSE4x4(int Value);
//extern int Get_YGJ_SSE4x4();
//
//extern int Set_YGJ_SSE8x8(int Value);
//extern int Get_YGJ_SSE8x8();
//
////---
//
//extern int Set_YGJ_SAD4x4(int Value);
//extern int Get_YGJ_SAD4x4();
//
//extern int Set_YGJ_SAD8x8(int Value);
//extern int Get_YGJ_SAD8x8();

//----------------
// Uses the #define values above to decide when to use Hadamard value, SSIM value or when to take an average of both.
//extern int YGJ_me_mcost(int blocksize_x, int blocksize_y, int HadCost, int SSIMCost);
//extern int YGJ_me_mcost(int blocksize_x, int HadCost, int SSIMCost);

struct ssim_sample
{
    int blksize;
    //----
    int AbsMeanDiff;
    float Covariance;
    double SSIMScore;
    // --
    int OneMinSSIM1k;
    //-----
    int PseudoSSIM;
    int TradDist;

    struct ssim_sample *next;
};

typedef struct ssim_sample SSIMSample;

extern SSIMSample *SSIMSample_head;

extern void SSIMSample_print_list(void);

//================================================================
extern int YGJ_NonOverlap_LSSIMwSobel (VideoParameters *p_Vid, imgpel **refImg, imgpel **encImg, int opix_x, int mb_x, int height, int width);
//================================================================
//================================================================
extern int YGJ_SSIMDistMetric (VideoParameters *p_Vid, imgpel **refImg, imgpel **encImg, int opix_x, int mb_x, int height, int TradDist);
extern distblk YGJ_SSIMDistMetric_dstblk (VideoParameters *p_Vid, imgpel **refImg, imgpel **encImg, int opix_x, int mb_x, int height, int TradDist);
extern int YGJ_SSIMDistMetric_1D_ME (VideoParameters *p_Vid, short *refImg, short *encImg, int SSIMSqBlkWidth, int TradDist, short *Diff);
//extern int YGJ_SSIMDistMetric_1D_ME_Overlap (VideoParameters *p_Vid, short *refImg, short *encImg, int height, int width, int TradDist);

// YGJ 1st May 2012 - Modifying Res if <60 or > 192 in terms of Luma provided no edge found on SSIM Map.
extern void YGJ_SSIMResAssess (VideoParameters *p_Vid, imgpel **refImg, int **encImg, int opix_x, int mb_x, int height, int width);
//================================================================
// YGJ 23rd April 2012 - Current Image Pixel x and y (mv_search.c - GetDirectCost8x8)
//extern int YGJ_SSIMDist_CurImg_pix_x;
//extern int YGJ_SSIMDist_CurImg_pix_y;

extern distblk distortion4x4SSIM(short* diff, distblk min_dist);
extern distblk distortion8x8SSIM(short* diff, distblk min_dist);
// YGJ Added 8th Feb 2012
extern distblk distortion4x4SSIMwSATD(short* diff, distblk min_dist);
extern distblk distortion8x8SSIMwSATD(short* diff, distblk min_dist);
//===================
// YGJ Added 4th Jan 2013
extern distblk distortion4x4SSIMwSSE(short* diff, distblk min_dist);
extern distblk distortion8x8SSIMwSSE(short* diff, distblk min_dist);
//===================
// YGJ Added 4th Jan 2013
extern distblk distortion4x4SSIMwSAD(short* diff, distblk min_dist);
extern distblk distortion8x8SSIMwSAD(short* diff, distblk min_dist);
//===================
// YGJ 13th Feb 2012
extern int YGJ_Intra_QPSteering(int masterQP, int currMBqp, VideoParameters *p_Vid, InputParameters *p_Inp, imgpel **cur_img, imgpel **res_img, imgpel **prd_img, int opix_x, int mb_x, int IntraBlockSize );
extern int YGJ_Inter_QPSteering(int masterQP, int currMBqp, VideoParameters *p_Vid, InputParameters *p_Inp, Macroblock *currMB, imgpel **cur_img, imgpel **res_img, imgpel **prd_img, int opix_x, int mb_x, int InterBlockSize );
//================================================================

extern void YGJ_WriteBMP(FILE *fEnc, char strEnc[80], unsigned char *imgEnc, int w, int h );
//================================================================

// YGJ 21st Feb 2013
// Setting up C1 and C2 Constansts at initialisation of encoder than each time SSIM is called.
// Should save considerable/significant amount of time as it is based upon (Luma) bit depth. 
extern int Set8bitSSIMConst();
extern int Set8bitSSIMConst_int();
extern int SetSSIMConst(int BitDepthLuma);
extern int SetSSIMConst_int(int BitDepthLuma);
//================================================================
#endif

