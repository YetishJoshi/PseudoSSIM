/*!
 *************************************************************************************
 * \file YGJ_functions.c (based upon: img_dist_ssim.c)
 *
 * \brief
 *    Compute structural similarity (SSIM) index using the encoded image and the reference image
 *
 * \author
 *    Main contributors (see contributors.h for copyright, address and affiliation details)
 *	  - Yetish Joshi    <y dot joshi at mdx dot ac dot uk>   Generated this separate file (14-May-2011)
 *************************************************************************************
 */

#include "contributors.h"

#include <limits.h>

#include "global.h"
#include <ygj_functions.h>

#include "img_distortion.h"
#include "enc_statistics.h"

#include "image.h"
#include "memalloc.h"
#include "memalloc.h"
#include "mb_access.h"
#include "refbuf.h"
#include "mv_search.h"
// Motion estimation distortion header file
#include "me_distortion.h"

#include "intra16x16.h"
#include "transform8x8.h"

// From me_distortion.h
#define CHECKOVERFLOW(mcost) 

// Used in SSIM and Edge Loops
#define max_SSIM_NoOverlap 4
#define max_SSIM_Overlap 9
#define Edge_max_count 4




/***********************************************************************
// YGJ 17th March 2013 - Creating Structure to store Linked list of SSIM Sample Data
// That can be saved in memory and written to file at the end of the frame/sequence.
// http://www.thegeekstuff.com/2012/08/c-linked-list-example/
// Just remember to comply with C89 rules of declaring variables first before undertaking operations, otherwise VC will complain without a clue as to what the problem is.
/***********************************************************************
*/

SSIMSample *SSIMSample_head = NULL;
SSIMSample *SSIMSample_curr = NULL;
int NodeCount;
int NodeCount20k;

SSIMSample* SSIMSample_create_list(int blksize, int AbsMeanDiff, float Covariance, double SSIMScore, int OneMinSSIM1k, int PseudoSSIM, int TradDist)
{
    //printf("\n creating list with headnode as [%d]\n",val);
    SSIMSample *ptr = (SSIMSample*)malloc(sizeof(SSIMSample));
    if (NULL == ptr)
    {
        printf("\n Node creation failed \n");
        return NULL;
    }
    //ptr->val = val;
    ptr->AbsMeanDiff = AbsMeanDiff;
    ptr->blksize = blksize;
    ptr->Covariance = Covariance;
    ptr->OneMinSSIM1k = OneMinSSIM1k;
    ptr->PseudoSSIM = PseudoSSIM;
    ptr->SSIMScore = SSIMScore;
    ptr->TradDist = TradDist;
    ptr->next = NULL;

    SSIMSample_head = SSIMSample_curr = ptr;
    
    NodeCount = 1;
    NodeCount20k = 0;

    //printf("\n creating list with headnode as [%d]\n",PseudoSSIM);

    return ptr;
}

SSIMSample* SSIMSample_add_to_list(int add_to_end, int blksize, int AbsMeanDiff, float Covariance, double SSIMScore, int OneMinSSIM1k, int PseudoSSIM, int TradDist)
{
    //if(add_to_end)
    //    printf("\n Adding node to end of list with value [%d]\n",val);
    //else
    //    printf("\n Adding node to beginning of list with value [%d]\n",val);

    SSIMSample *ptr = (SSIMSample*)malloc(sizeof(SSIMSample));
    
    if(NULL == SSIMSample_head)
    {
        return (SSIMSample_create_list(blksize, AbsMeanDiff, Covariance, SSIMScore, OneMinSSIM1k, PseudoSSIM, TradDist));
    }

    if (NULL == ptr)
    {
        printf("\n Node creation failed \n");
        return NULL;
    }
    //ptr->val = val;       
    ptr->AbsMeanDiff = AbsMeanDiff;
    ptr->blksize = blksize;
    ptr->Covariance = Covariance;
    ptr->OneMinSSIM1k = OneMinSSIM1k;
    ptr->PseudoSSIM = PseudoSSIM;
    ptr->SSIMScore = SSIMScore;
    ptr->TradDist = TradDist;
    ptr->next = NULL;

    NodeCount++;

    //printf("\n adding to list with headnode as [%d]\n",PseudoSSIM);

    if(add_to_end)
    {
        SSIMSample_curr->next = ptr;
        SSIMSample_curr = ptr;
    }
    else
    {
        ptr->next = SSIMSample_head;
        SSIMSample_head = ptr;
    }

        
    if (NodeCount == 20000)
    {
        //printf("\n adding to list with NodeCount as [%d]\n",NodeCount+(NodeCount10k*10000));
        NodeCount = 0;
        NodeCount20k++;
        SSIMSample_print_list();
        SSIMSample_head = NULL;
    }


    return ptr;
}

void SSIMSample_print_list(void)
{
    SSIMSample *ptr = SSIMSample_head;
    // Declare variable at the start before any C code.
	FILE *outfilePseudoVal = NULL;
    
           
    // write to log file     
    if ((outfilePseudoVal = fopen("LoggedSSIMSamples.dat", "r")) == 0)            // check if file exists
      {
        if ((outfilePseudoVal = fopen("LoggedSSIMSamples.dat", "a")) == NULL)       // append new statistic at the end
        {
          snprintf(errortext, ET_SIZE, "Error open file %s  \n", "LoggedSSIMSamples.dat");
          error(errortext, 500);
        }
        else                                            // Create header for new log file
        {

            fprintf(outfilePseudoVal, "BlockSize SSIM OneMinSSIM1k Covariance AbsMeanDiff PseudoSSIM TradDist\n");
        }
      }
      else
      {
        fclose (outfilePseudoVal);
        if ((outfilePseudoVal = fopen("LoggedSSIMSamples.dat", "a")) == NULL)       // File exists, just open for appending
        {
          snprintf(errortext, ET_SIZE, "Error open file %s  \n", "LoggedSSIMSamples.dat");
          error(errortext, 500);
        }
      }

     
    while(ptr != NULL)
        {
            //printf("\n [%d] \n",ptr->val);
            fprintf(outfilePseudoVal, "%d %f %d %f %d %d %d\n", ptr->blksize, ptr->SSIMScore, ptr->OneMinSSIM1k, ptr->Covariance, ptr->AbsMeanDiff, ptr->PseudoSSIM, ptr->TradDist);
            ptr = ptr->next;
        }

     
    fclose (outfilePseudoVal);


    return;
}

/***********************************************************************
*/


// YGJ 17th March 2013 - Created a structure to store SSIM related values that will be passed back once SSIM has been determined
// http://stackoverflow.com/questions/252780/why-should-we-typedef-a-struct-so-often-in-c
typedef struct
{
    int AbsMeanDiff;
    float Covariance;
    double SSIMScore;
} ssiminf;


int YGJ_LSSIM_meanEnc[9] = {0,0,0,  0,0,0,  0,0,0};

int YGJ_SATD4x4; // Used to store SATD 8x8 score from transform8x8
int YGJ_SATD8x8; // Used to store SATD 8x8 score from transform8x8
int YGJ_SATD16x16; // Used to store SATD 8x8 score from transform8x8

int YGJ_SSE4x4; // Used to store SSE 8x8 score from transform8x8
int YGJ_SSE8x8; // Used to store SSE 8x8 score from transform8x8

int YGJ_SAD4x4; // Used to store SAD 8x8 score from transform8x8
int YGJ_SAD8x8; // Used to store SAD 8x8 score from transform8x8

// Set upon Initialisation of the Encoder to save time calculating it

float YGJ_C1;    // Used if CalcSSIMConst is enabled
int  YGJ_C1_int; // Used if SSIM_int is enabled

float YGJ_C2;    // Used if CalcSSIMConst is enabled
int  YGJ_C2_int; // Used if SSIM_int is enabled

//int YGJ_CalcSSIMConst; // Set upon initialisation of Encoder, whether to use Pre Calc. SSIM. Constants.
int YGJ_SSIM_int; // Set upon initialisation of Encoder if to use Integer based techniques (set to One) to calculate SSIM or Normal float based (Set to Zero)


//------------------
int Set_YGJ_SSIM_int(int Enable) 
{
    YGJ_SSIM_int = Enable;
    return YGJ_SSIM_int;
}

int Get_YGJ_SSIM_int(){return YGJ_SSIM_int;}
//------------------

//------------------
int Set_YGJ_C1_int(int C1_int) 
{
    YGJ_C1_int = C1_int;
    return YGJ_C1_int;
}

int Get_YGJ_C1_int(){return YGJ_C1_int;}
//------------------

//------------------
float Set_YGJ_C1(float C1) 
{
    YGJ_C1 = C1;
    return YGJ_C1;
}

float Get_YGJ_C1(){return YGJ_C1;}
//------------------

//------------------
int Set_YGJ_C2_int(int C2_int) 
{
    YGJ_C2_int = C2_int;
    return YGJ_C2_int;
}

int Get_YGJ_C2_int(){return YGJ_C2_int;}
//------------------

//------------------
float Set_YGJ_C2(float C2) 
{
    YGJ_C2 = C2;
    return YGJ_C2;
}

float Get_YGJ_C2(){return YGJ_C2;}
//------------------

//------------------
// Most typical
int Set8bitSSIMConst()
{
    Set_YGJ_C1((float)(6.5025));

    Set_YGJ_C2((float)(58.5225));

    // YGJ 25th Feb 2013
    // Also Set SSIM Determine Integer Based as True
    // As Get_YGJ_SSIM_int is called before Determining acutal SSIM
    // but out of scope of p_Vid pointer which stores Input Paremeters.
    Set_YGJ_SSIM_int(FALSE);
    return 0;
}
//------------------

//------------------
// Int version of most typical
int Set8bitSSIMConst_int()
{
    Set_YGJ_C1_int(6);

    Set_YGJ_C2_int(58);

    // YGJ 25th Feb 2013
    // Also Set SSIM Determine Integer Based as True
    // As Get_YGJ_SSIM_int is called before Determining acutal SSIM
    // but out of scope of p_Vid pointer which stores Input Paremeters.
    Set_YGJ_SSIM_int(TRUE);

    return 0;
}
//------------------

//------------------
int SetSSIMConst(int BitDepthLuma)
{
    int LumaRange = (2 << BitDepthLuma) - 1;

    float C1xLumaRangeSq = (float)(0.01 * (float)LumaRange);
    
    float C2xLumaRangeSq = (float)(0.03 * (float)LumaRange);

    Set_YGJ_C1(C1xLumaRangeSq*C1xLumaRangeSq);

    Set_YGJ_C2(C2xLumaRangeSq*C2xLumaRangeSq);

    // YGJ 25th Feb 2013
    // Also Set SSIM Determine Integer Based as True
    // As Get_YGJ_SSIM_int is called before Determining acutal SSIM
    // but out of scope of p_Vid pointer which stores Input Paremeters.
    Set_YGJ_SSIM_int(FALSE);
    return 0;
}
//------------------

//------------------
int SetSSIMConst_int(int BitDepthLuma)
{
    int LumaRange = (2 << BitDepthLuma) - 1;

    int C1xLumaRangeSq = (LumaRange >> 7)^2; // 1/128 ~ 0.08
    
    int C2xLumaRangeSq = (LumaRange >> 5)^2; // 1/32 ~ 0.03125

    Set_YGJ_C1((float)C1xLumaRangeSq);

    Set_YGJ_C2((float)C2xLumaRangeSq);

    // YGJ 25th Feb 2013
    // Also Set SSIM Determine Integer Based as True
    // As Get_YGJ_SSIM_int is called before Determining acutal SSIM
    // but out of scope of p_Vid pointer which stores Input Paremeters.
    Set_YGJ_SSIM_int(TRUE);

    return 0;
}
//------------------


//!< YGJ Fri 3rd Feb 2012 - Returns the Window Height or Width which will be 1/2 the Height or Width  value.
//!< Sets the size of the Search Window to be Used.
int YGJ_Calc_WinHeightOrWidth(int height) {return (height >> 1);}

//!< YGJ Fri 3rd Feb 2012 - Returns the Window Pixels Value which will be a multiple of win_height with win_width
//!< This is the area covered in pixels by the Local SSIM Search Window
int YGJ_Calc_WinPixels(int win_height, int win_width) {return (win_height * win_width);}

//!< YGJ Fri 3rd Feb 2012 - Returns the OverlapSize based upon the win_height or win_width which will be 1/2 (the input value).
//!< This means that 50% overlap is maintained between each Search Window when determining SSIM based upon neighbouring Local SSIM values.
int YGJ_Calc_OverlapSize(int win_height) {return (win_height >> 1);}

//!< YGJ Fri 3rd Feb 2012 - Returns the ShiftDivbyOverlapSize  which will be 1/2  the OverlapSize (height or Width)
// !< This is used to save the SSIM result in the correct LSSIM array location
int YGJ_Calc_ShiftDivByOverlap(int OverlapSize) {return (OverlapSize >> 1);}


//double YGJ_DetermineSSIM(int ivarOrg, int imeanOrg, int ivarEnc, int imeanEnc, int icovOrgEnc, int win_pixels, float win_pixels_bias, float C1, float C2, int Location, float *Covar, int *AbsMeanDiff)
ssiminf YGJ_DetermineSSIM(int ivarOrg, int imeanOrg, int ivarEnc, int imeanEnc, int icovOrgEnc, int win_pixels, float win_pixels_bias, float C1, float C2, int Location, float Covar, int AbsMeanDiff)   
{
	double mb_ssim = 0.0;
	float varOrg, varEnc, covOrgEnc;
	float meanOrg =  (float)imeanOrg / (float)win_pixels;
	float meanEnc =  (float)imeanEnc / (float)win_pixels;
    int CurrAbsMeanDiff;
    ssiminf SSIMInfo;
	

	// YGJ 1st May 2012 - Average Enc for Sliding Window
	YGJ_LSSIM_meanEnc[Location] = (int) meanEnc;

	varOrg    = ((float) ivarOrg - ((float) imeanOrg) * meanOrg) / win_pixels_bias;
	varEnc    = ((float) ivarEnc - ((float) imeanEnc) * meanEnc) /  win_pixels_bias;
	covOrgEnc = ((float) icovOrgEnc - ((float) imeanOrg) * meanEnc) /  win_pixels_bias;

    // YGJ 17th Mar 2013    
    // This was used to validate whether the correct pixels values were being calculated.
    // However now the calls are more direct this has meant this message does not appear.
    // Also this would be invalid for video greater than 8 bit pixel values. Such as RAW Video.

    // YGJ 30th Nov 2012 - Been taking away C2 from this score for a while, so best make it so. 
    // The constant should not be needed. The 2 times Covariance simply helps to maintain some form of accuracy as it is converted to integer form.
    
    // 20th Feb 2013 - Use Location value to see if using overlapping
    covOrgEnc = (Location == 0) ? 
        covOrgEnc
        : Covar + covOrgEnc; // Add previous location(s) Covar value with current


    SSIMInfo.Covariance = covOrgEnc;

    // YGJ 30th Nov 2012

    CurrAbsMeanDiff = abs((int)meanOrg - (int)meanEnc);
    // 23rd Feb 2013 - Use Location value to see if using overlapping
    CurrAbsMeanDiff = (Location == 0) ?
        CurrAbsMeanDiff // As is
        : CurrAbsMeanDiff + AbsMeanDiff;  // Add previous location(s) Covar value with current
   
    SSIMInfo.AbsMeanDiff = CurrAbsMeanDiff;

	mb_ssim  =  (double)((2.0 * meanOrg * meanEnc + C1) * (2.0 * covOrgEnc + C2));
	mb_ssim /=  (double)(meanOrg * meanOrg + meanEnc * meanEnc + C1) * (varOrg + varEnc + C2);

	//printf("YGJ_DetermineSSIM, %f \n", mb_ssim); // Dangerous - produced over a 2GB txt file when encoding just 3 frames. 

    SSIMInfo.SSIMScore = mb_ssim;

	return SSIMInfo;
}


// YGJ 11th Spet 2012 - Trying to use Ints where possible part of the Single Simple SSIM
//double YGJ_DetermineSSIM_int(int ivarOrg, int imeanOrg, int ivarEnc, int imeanEnc, int icovOrgEnc, int win_pixels, float C1, float C2, int Location, float Covar, int AbsMeanDiff)
ssiminf YGJ_DetermineSSIM_int(int ivarOrg, int imeanOrg, int ivarEnc, int imeanEnc, int icovOrgEnc, int win_pixels, float C1, float C2, int Location, float Covar, int AbsMeanDiff)
{
	double mb_ssim = 0.0;
	int varOrg, varEnc, covOrgEnc;
	
	int meanOrg;
	int meanEnc;
    int CurrAbsMeanDiff;
    float CurrCovar;

    ssiminf SSIMInfo;

	int x = 0;

	switch (win_pixels)
	{
	case 4: x = 2;
		break;
	case 8: x = 3;
        break;
    case 16: x = 4;
		break;
	case 32: x = 5;
		break;
	case 64: x = 6;
		break;
	case 128: x = 7;
		break;
	//case 256: x = 8;
	//	break;
	default: x = 8;
	}

	meanOrg = imeanOrg >> x;
	meanEnc = imeanEnc >> x; 	

	varOrg    = (ivarOrg - imeanOrg * meanOrg) >> x;	
	varEnc    = (ivarEnc - imeanEnc * meanEnc) >> x;
	covOrgEnc = (icovOrgEnc - (imeanOrg) * meanEnc) >> x;

    
    // 20th Feb 2013 - Use Location value to see if using overlapping
    CurrCovar = (Location == 0)?          
        (float)covOrgEnc //As is
        : Covar + (float)covOrgEnc; // Add previous location(s) Covar value with current

    SSIMInfo.Covariance = CurrCovar;

     
    CurrAbsMeanDiff = abs((int)meanOrg - (int)meanEnc);
    // 23rd Feb 2013 - Use Location value to see if using overlapping
    CurrAbsMeanDiff = (Location == 0) ?
        CurrAbsMeanDiff // As is
        : CurrAbsMeanDiff + AbsMeanDiff;  // Add previous location(s) Covar value with current

    SSIMInfo.AbsMeanDiff = CurrAbsMeanDiff;


	// 21st Feb 2013 - Use Integers to speed things up
	mb_ssim  =  (double)((((meanOrg * meanEnc)<< 1) + C1) * ((covOrgEnc<<1)+ C2));
	mb_ssim /=  (double)(meanOrg * meanOrg + meanEnc * meanEnc + C1) * (varOrg + varEnc + C2);

    //printf("YGJ_DetermineSSIM_int, %f \n", mb_ssim); // Dangerous - produced over a 2GB txt file when encoding just 3 frames. 

    SSIMInfo.SSIMScore = mb_ssim;

	return SSIMInfo;
}



//double YGJ_Compute_LocalSSIM(float C1, float C2, int i, imgpel **refImg, imgpel **encImg, int opix_x, int mb_x, int win_height, int win_width, int win_pixels, float win_pixels_bias, int Location, float Covar, int AbsMeanDiff)
ssiminf YGJ_Compute_LocalSSIM(float C1, float C2, int i, imgpel **refImg, imgpel **encImg, int opix_x, int mb_x, int win_height, int win_width, int win_pixels, float win_pixels_bias, int Location, float Covar, int AbsMeanDiff)
{
	imgpel *imgOrg, *imgPred;

    ssiminf SSIMInfo;

//	int *imgPred;

	//double mb_ssim; 
	//int n = j, m = i;

	int w_widmin1 = win_width - 1;
	int n = 0;
	int m_ref = i+opix_x + w_widmin1;
	int m_enc = i+mb_x + w_widmin1;	
						
	int imeanOrg = 0;
	int imeanEnc = 0; 
	int ivarOrg  = 0;
	int ivarEnc  = 0;
	int icovOrgEnc = 0;

    //if (win_pixels > (win_height*win_width))
    //    printf("YGJ_Compute_LocalSSIM, win_pixels, %d, > win_height*win_width, %d, %d \n", win_pixels, win_height, win_width);

	for ( n = 0;n < win_height; n++)	
	{		    
		imgOrg = &refImg[n][m_ref];    
		imgPred = &encImg[n][m_enc];
						
		switch(win_width)
		{
		case 8:
            
            //if (((int)*imgOrg < 0) || ((int)*imgOrg > 255) || ((int)*imgPred < 0) || ((int)*imgPred > 255))        
            //    printf("YGJ_Compute_LocalSSIM - (Loc. 7) Invalid Luma Value. imgOrg %d, win_width, %d, j, %d,  imgPred, %d, diff, %d\n", imgOrg, win_width, n, imgPred, imgOrg-imgPred);

			// 7
			imeanOrg += (int)*imgOrg;
			imeanEnc += (int)*imgPred;
			ivarOrg += (int)*imgOrg * (int)*imgOrg;
			ivarEnc += (int)*imgPred * (int)*imgPred;
			icovOrgEnc += (int)*imgOrg-- * (int)*imgPred--;		

            //if (((int)*imgOrg < 0) || ((int)*imgOrg > 255) || ((int)*imgPred < 0) || ((int)*imgPred > 255))        
            //    printf("YGJ_Compute_LocalSSIM - (Loc. 6) Invalid Luma Value. imgOrg %d, win_width, %d, j, %d,  imgPred, %d, diff, %d\n", imgOrg, win_width, n, imgPred, imgOrg-imgPred);


			// 6
			imeanOrg += (int)*imgOrg;
			imeanEnc += (int)*imgPred;
			ivarOrg += (int)*imgOrg * (int)*imgOrg;
			ivarEnc += (int)*imgPred * (int)*imgPred;
			icovOrgEnc += (int)*imgOrg-- * (int)*imgPred--;	

            //if (((int)*imgOrg < 0) || ((int)*imgOrg > 255) || ((int)*imgPred < 0) || ((int)*imgPred > 255))        
            //    printf("YGJ_Compute_LocalSSIM - (Loc. 5) Invalid Luma Value. imgOrg %d, win_width, %d, j, %d,  imgPred, %d, diff, %d\n", imgOrg, win_width, n, imgPred, imgOrg-imgPred);

			// 5
			imeanOrg += (int)*imgOrg;
			imeanEnc += (int)*imgPred;
			ivarOrg += (int)*imgOrg * (int)*imgOrg;
			ivarEnc += (int)*imgPred * (int)*imgPred;
			icovOrgEnc += (int)*imgOrg-- * (int)*imgPred--;	

            //if (((int)*imgOrg < 0) || ((int)*imgOrg > 255) || ((int)*imgPred < 0) || ((int)*imgPred > 255))        
            //    printf("YGJ_Compute_LocalSSIM - (Loc. 4) Invalid Luma Value. imgOrg %d, win_width, %d, j, %d,  imgPred, %d, diff, %d\n", imgOrg, win_width, n, imgPred, imgOrg-imgPred);

			// 4
			imeanOrg += (int)*imgOrg;
			imeanEnc += (int)*imgPred;
			ivarOrg += (int)*imgOrg * (int)*imgOrg;
			ivarEnc += (int)*imgPred * (int)*imgPred;
			icovOrgEnc += (int)*imgOrg-- * (int)*imgPred--;	

					
		case 4: 

            //if (((int)*imgOrg < 0) || ((int)*imgOrg > 255) || ((int)*imgPred < 0) || ((int)*imgPred > 255))        
            //    printf("YGJ_Compute_LocalSSIM - (Loc. 3) Invalid Luma Value. imgOrg %d, win_width, %d, j, %d,  imgPred, %d, diff, %d\n", imgOrg, win_width, n, imgPred, imgOrg-imgPred);


			// 3
			imeanOrg += (int)*imgOrg;
			imeanEnc += (int)*imgPred;
			ivarOrg += (int)*imgOrg * (int)*imgOrg;
			ivarEnc += (int)*imgPred * (int)*imgPred;
			icovOrgEnc += (int)*imgOrg-- * (int)*imgPred--;		

            //if (((int)*imgOrg < 0) || ((int)*imgOrg > 255) || ((int)*imgPred < 0) || ((int)*imgPred > 255))        
            //    printf("YGJ_Compute_LocalSSIM - (Loc. 2) Invalid Luma Value. imgOrg %d, win_width, %d, j, %d,  imgPred, %d, diff, %d\n", imgOrg, win_width, n, imgPred, imgOrg-imgPred);


			// 2
			imeanOrg += (int)*imgOrg;
			imeanEnc += (int)*imgPred;
			ivarOrg += (int)*imgOrg * (int)*imgOrg;
			ivarEnc += (int)*imgPred * (int)*imgPred;
			icovOrgEnc += (int)*imgOrg-- * (int)*imgPred--;	
		
		case 2:

            //if (((int)*imgOrg < 0) || ((int)*imgOrg > 255) || ((int)*imgPred < 0) || ((int)*imgPred > 255))        
            //    printf("YGJ_Compute_LocalSSIM - (Loc. 1) Invalid Luma Value. imgOrg %d, win_width, %d, j, %d,  imgPred, %d, diff, %d\n", imgOrg, win_width, n, imgPred, imgOrg-imgPred);


			// 1
			imeanOrg += (int)*imgOrg;
			imeanEnc += (int)*imgPred;
			ivarOrg += (int)*imgOrg * (int)*imgOrg;
			ivarEnc += (int)*imgPred * (int)*imgPred;
			icovOrgEnc += (int)*imgOrg-- * (int)*imgPred--;	

            //if (((int)*imgOrg < 0) || ((int)*imgOrg > 255) || ((int)*imgPred < 0) || ((int)*imgPred > 255))        
            //    printf("YGJ_Compute_LocalSSIM - (Loc. 0) Invalid Luma Value. imgOrg %d, win_width, %d, j, %d,  imgPred, %d, diff, %d\n", imgOrg, win_width, n, imgPred, imgOrg-imgPred);

			// 0
			imeanOrg += (int)*imgOrg;
			imeanEnc += (int)*imgPred;
			ivarOrg += (int)*imgOrg * (int)*imgOrg;
			ivarEnc += (int)*imgPred * (int)*imgPred;
			icovOrgEnc += (int)*imgOrg * (int)*imgPred;	

		}


	}
	SSIMInfo = (Get_YGJ_SSIM_int() == FALSE)?
        YGJ_DetermineSSIM(ivarOrg, imeanOrg, ivarEnc, imeanEnc, icovOrgEnc, win_pixels, win_pixels_bias, C1, C2, Location, Covar, AbsMeanDiff):    
        YGJ_DetermineSSIM_int(ivarOrg, imeanOrg, ivarEnc, imeanEnc, icovOrgEnc, win_pixels, C1, C2, Location, Covar, AbsMeanDiff);

    return SSIMInfo;
}

void YGJ_printBlkValues(int i, imgpel **refImg, int opix_x, int win_height, int win_width)
{
	imgpel *imgOrg;

	int w_widmin1 = win_width - 1;
	int n = 0;
	int m_ref = i+opix_x + w_widmin1;

	for ( n = 0;n < win_height; n++)	
	{		    
		imgOrg = &refImg[n][m_ref];    
						
		switch(win_width)
		{
		case 8: 
			printf("%d,", (int)(*imgOrg--)); 
			printf("%d,", (int)(*imgOrg--)); 
			printf("%d,", (int)(*imgOrg--)); 
			printf("%d,", (int)(*imgOrg--)); 		
		
		case 4: 
			printf("%d,", (int)(*imgOrg--)); 
			printf("%d,", (int)(*imgOrg--)); 
					
		case 2: 
			printf("%d,", (int)(*imgOrg--)); 
			printf("%d", (int)(*imgOrg--)); 
		}
		printf("\n");
	}
	printf("\n");
}

//Assume it will be square, either 4x4 or 8x8.
void YGJ_printBlkValues_1D_ME(imgpel *refImg, int win_height)
{
	//imgpel *imgOrg;

	//int w_widmin1 = win_height - 1;
	int n = 0;
	int m_ref; //= i+opix_x + w_widmin1;

	for ( n = 0;n < (win_height * win_height) ; n+=win_height)	
	{		    
		//imgOrg = &refImg[m_ref];    
        m_ref = n+ win_height;
						
		switch(win_height)
		{
		case 8: 
            m_ref--;
			printf("%d,", (int)refImg[m_ref]); //(*imgOrg--)); 
            m_ref--;
			printf("%d,", (int)refImg[m_ref]); //(*imgOrg--)); 
            m_ref--;
			printf("%d,", (int)refImg[m_ref]); //(*imgOrg--)); 
            m_ref--;
			printf("%d,", (int)refImg[m_ref]); //(*imgOrg--)); 		
		
		case 4: 
            m_ref--;
			printf("%d,", (int)refImg[m_ref]); //(*imgOrg--)); 
            m_ref--;
			printf("%d,", (int)refImg[m_ref]); //(*imgOrg--)); 
					
		case 2: 
            m_ref--;
			printf("%d,", (int)refImg[m_ref]); //(*imgOrg--))
            m_ref--;; 
			printf("%d", (int)refImg[m_ref]); //(*imgOrg--)); 
		}
		printf("\n");
	}
	printf("\n");
}

void YGJ_printBlkValues_ME(imgpel *refImg, imgpel *encImg, int win_height)
{

    printf("\n\nBlksize, %d, SSIM, %f, (1-SSIM)x1k, %d, Covariance, %f, AbsMeanDiff, %d, Pseudo-SSIM, %d, TradDist, %d \n", 
        SSIMSample_curr->blksize, SSIMSample_curr->SSIMScore, SSIMSample_curr->OneMinSSIM1k, SSIMSample_curr->Covariance, SSIMSample_curr->AbsMeanDiff, SSIMSample_curr->PseudoSSIM, SSIMSample_curr->TradDist);

    printf("\nPrinting contents of RefImg (Original Block or Image) \n\n");
	YGJ_printBlkValues_1D_ME(refImg, win_height);
	
    printf("\nPrinting contents of EncImg (Encoded Block or Image) \n\n\n");
	YGJ_printBlkValues_1D_ME(encImg, win_height);

}

void YGJ_printBlkValues_ME_short(short *refImg, short *encImg, int win_height)
{

    printf("\n\nBlksize, %d, SSIM, %f, (1-SSIM)x1k, %d, Covariance, %f, AbsMeanDiff, %d, Pseudo-SSIM, %d, TradDist, %d \n", 
        SSIMSample_curr->blksize, SSIMSample_curr->SSIMScore, SSIMSample_curr->OneMinSSIM1k, SSIMSample_curr->Covariance, SSIMSample_curr->AbsMeanDiff, SSIMSample_curr->PseudoSSIM, SSIMSample_curr->TradDist);

    printf("\nPrinting contents of RefImg (Original Block or Image) \n\n");
	YGJ_printBlkValues_1D_ME(refImg, win_height);
	
    printf("\nPrinting contents of EncImg (Encoded Block or Image) \n\n\n");
	YGJ_printBlkValues_1D_ME(encImg, win_height);

}

// YGJ 19th March 2013
// Assuming to be Square
void YGJ_printBlkValues_Intra(imgpel **refImg, int opix_x, imgpel **encImg, int mb_x, int win_height) // (int i, imgpel **refImg, int opix_x, int win_height, int win_width)
{

    printf("\n\nBlksize, %d, SSIM, %f, (1-SSIM)x1k, %d, Covariance, %f, AbsMeanDiff, %d, Pseudo-SSIM, %d, TradDist, %d \n", 
        SSIMSample_curr->blksize, SSIMSample_curr->SSIMScore, SSIMSample_curr->OneMinSSIM1k, SSIMSample_curr->Covariance, SSIMSample_curr->AbsMeanDiff, SSIMSample_curr->PseudoSSIM, SSIMSample_curr->TradDist);

    printf("\nPrinting contents of RefImg (Original Block or Image) \n\n");
	//YGJ_printBlkValues_1D_ME(refImg, win_height);
    YGJ_printBlkValues( 0, refImg, opix_x, win_height, win_height);
	
    printf("\nPrinting contents of EncImg (Encoded Block or Image) \n\n\n");
	//YGJ_printBlkValues_1D_ME(encImg, win_height);
    YGJ_printBlkValues( 0, encImg, mb_x, win_height, win_height);

}


// YGJ 17th Mar 2013 - Please avoid using - This function is not working as it should. Especially becuase now SSIM is called directly and not through the calls of distortion4x4 or 8x8. Also the pixel coordinates are no longer being noted, therefore the assessment will be flawed
// YGJ 17th Mar 2013 - No longer actually used. SSIM is called directly, as this method was cumbersome and error prone.
// The difference was worked out only to be used to reconstruct the original. Hence a direct method is now in place.
// Therefore the following route is now redundant., but kept for historical sense and because main code still links here,
// albeit there is an If-Then-Else statement to catch it before it is called.
// Redundant Route:
//  distortionAxASSIMwXXXX -> YGJ_SSIMOverlapDistMetricFactor - >  OneDimSSIM.
// Please note that the If Then check for the Pixel values do still exist should by chance these functions get called.
//double YGJ_OneDimSSIM(float C1, float C2, int m, imgpel **currImg, short* diff, int height, int win_height, int win_width, int win_pixels, float win_pixels_bias, int Location, float Covar, int AbsMeanDiff)
ssiminf YGJ_OneDimSSIM(float C1, float C2, int m, imgpel **currImg, short* diff, int height, int win_height, int win_width, int win_pixels, float win_pixels_bias, int Location, float Covar, int AbsMeanDiff)
{
	//double mb_ssim;
    ssiminf SSIMInfo;

	double cur_distortion = 0.0;
	int imeanOrg = 0, imeanEnc = 0, ivarOrg = 0, ivarEnc = 0, icovOrgEnc = 0;
	
	//int Org=0, Enc=0;

	int currImg_pix_x = 0;//YGJ_SSIMDist_CurImg_pix_x;
	int currImg_pix_y = 0;//YGJ_SSIMDist_CurImg_pix_y;

	////====================
			
	int OneDimPos1 = m;
	//--	

	int j = 0, i = win_width - 1;
	int cur_yj = 0, cur_xi = 0;
	int d_pos = 0;
	int curr_pix = 0, pred_pix = 0, diff_pix=0;

    // YGJ 25th Feb 2013 - Not an issue in OneDimSSIM
    //if (win_pixels != (win_height*win_width))
      //  printf("YGJ_Compute_LocalSSIM, win_pixels, %d, not equal to win_height*win_width, %d, %d \n", win_pixels, win_height, win_width);

	for (j = 0; j < win_height; j++)
	{							
		
		cur_yj = currImg_pix_y + j;
		cur_xi = currImg_pix_x + i;

		d_pos = OneDimPos1 + i;

		//curr_pix = (int)currImg[cur_yj][cur_xi--];
		curr_pix = (int)currImg[cur_yj][cur_xi];
        // YGJ 25th Feb 2013 - Had a bug was decrementing cur_xi twice. Also made it more readable by introducing diff_pix.
        diff_pix = (int)diff[d_pos];
		
		// YGJ 9th May 2012 - Done to check if diff is negative or positive before determing if it should be subtracted or added to current image's pixel value to recover predicted pixel value.
		//pred_pix =  diff[d_pos] > 0 ? curr_pix - diff_pix: curr_pix + diff_pix;
        // Assume Original - Reconstructed  = Difference. Therefore, Original - Difference = Reconstructed.
        pred_pix =  curr_pix - diff_pix;
			
        if ((pred_pix < 0) || (pred_pix > 255))
            printf("Invalid Luma Value 8. %d, i, %d, j, %d,  curr_pix, %d, diff_pix, %d\n", pred_pix, i, j, curr_pix, diff_pix);


		switch(win_width)
		{
		case 8: 

			// 7
			imeanOrg   += curr_pix; 
			imeanEnc   += pred_pix;
			ivarOrg    += curr_pix * curr_pix;
			ivarEnc    += pred_pix * pred_pix;
			icovOrgEnc += curr_pix * pred_pix;

//			curr_pix = (int)currImg[cur_yj][cur_xi];
//			pred_pix =  diff[d_pos] > 0 ? (int)currImg[cur_yj][cur_xi--] - (int)diff[d_pos--] : (int)currImg[cur_yj][cur_xi--] + (int)diff[d_pos--];

		    curr_pix = (int)currImg[cur_yj][cur_xi--];
            // YGJ 25th Feb 2013 - Had a bug was decrementing cur_xi twice. Also made it more readable by introducing diff_pix.
            diff_pix = (int)diff[d_pos--];
		
		    // YGJ 9th May 2012 - Done to check if diff is negative or positive before determing if it should be subtracted or added to current image's pixel value to recover predicted pixel value.
		    //pred_pix =  diff[d_pos] > 0 ? curr_pix - diff_pix: curr_pix + diff_pix;                    
            // Assume Original - Reconstructed  = Difference. Therefore, Original - Difference = Reconstructed.
            pred_pix =  curr_pix - diff_pix;
                   
            if ((pred_pix < 0) || (pred_pix > 255))      
                printf("Invalid Luma Value 7. %d, i, %d, j, %d,  curr_pix, %d, diff_pix, %d\n", pred_pix, i, j, curr_pix, diff_pix);

			// 6
			imeanOrg   += curr_pix; 
			imeanEnc   += pred_pix;
			ivarOrg    += curr_pix * curr_pix;
			ivarEnc    += pred_pix * pred_pix;
			icovOrgEnc += curr_pix * pred_pix;

		    curr_pix = (int)currImg[cur_yj][cur_xi--];
            // YGJ 25th Feb 2013 - Had a bug was decrementing cur_xi twice. Also made it more readable by introducing diff_pix.
            diff_pix = (int)diff[d_pos--];
		
		    // YGJ 9th May 2012 - Done to check if diff is negative or positive before determing if it should be subtracted or added to current image's pixel value to recover predicted pixel value.
		    //pred_pix =  diff[d_pos] > 0 ? curr_pix - diff_pix: curr_pix + diff_pix;                    
            // Assume Original - Reconstructed  = Difference. Therefore, Original - Difference = Reconstructed.
            pred_pix =  curr_pix - diff_pix;
            if ((pred_pix < 0) || (pred_pix > 255))                        
                printf("Invalid Luma Value 6. %d, i, %d, j, %d,  curr_pix, %d, diff_pix, %d\n", pred_pix, i, j, curr_pix, diff_pix);

			// 5
			imeanOrg   += curr_pix; 
			imeanEnc   += pred_pix;
			ivarOrg    += curr_pix * curr_pix;
			ivarEnc    += pred_pix * pred_pix;
			icovOrgEnc += curr_pix * pred_pix;

		    curr_pix = (int)currImg[cur_yj][cur_xi--];
            // YGJ 25th Feb 2013 - Had a bug was decrementing cur_xi twice. Also made it more readable by introducing diff_pix.
            diff_pix = (int)diff[d_pos--];
		
		    // YGJ 9th May 2012 - Done to check if diff is negative or positive before determing if it should be subtracted or added to current image's pixel value to recover predicted pixel value.
		    //pred_pix =  diff[d_pos] > 0 ? curr_pix - diff_pix: curr_pix + diff_pix;                    
            // Assume Original - Reconstructed  = Difference. Therefore, Original - Difference = Reconstructed.
            pred_pix =  curr_pix - diff_pix;

            if ((pred_pix < 0) || (pred_pix > 255))            
                printf("Invalid Luma Value 5. %d, i, %d, j, %d,  curr_pix, %d, diff_pix, %d\n", pred_pix, i, j, curr_pix, diff_pix);

			// 4
			imeanOrg   += curr_pix; 
			imeanEnc   += pred_pix;
			ivarOrg    += curr_pix * curr_pix;
			ivarEnc    += pred_pix * pred_pix;
			icovOrgEnc += curr_pix * pred_pix;

		    curr_pix = (int)currImg[cur_yj][cur_xi--];
            // YGJ 25th Feb 2013 - Had a bug was decrementing cur_xi twice. Also made it more readable by introducing diff_pix.
            diff_pix = (int)diff[d_pos--];
		
		    // YGJ 9th May 2012 - Done to check if diff is negative or positive before determing if it should be subtracted or added to current image's pixel value to recover predicted pixel value.
		    //pred_pix =  diff[d_pos] > 0 ? curr_pix - diff_pix: curr_pix + diff_pix;                    
            // Assume Original - Reconstructed  = Difference. Therefore, Original - Difference = Reconstructed.
            pred_pix =  curr_pix - diff_pix;

            if ((pred_pix < 0) || (pred_pix > 255))            
                printf("Invalid Luma Value 4. %d, i, %d, j, %d,  curr_pix, %d, diff_pix, %d\n", pred_pix, i, j, curr_pix, diff_pix);

		case 4: 

			// 3
			imeanOrg   += curr_pix; 
			imeanEnc   += pred_pix;
			ivarOrg    += curr_pix * curr_pix;
			ivarEnc    += pred_pix * pred_pix;
			icovOrgEnc += curr_pix * pred_pix;

		    curr_pix = (int)currImg[cur_yj][cur_xi--];
            // YGJ 25th Feb 2013 - Had a bug was decrementing cur_xi twice. Also made it more readable by introducing diff_pix.
            diff_pix = (int)diff[d_pos--];
		
		    // YGJ 9th May 2012 - Done to check if diff is negative or positive before determing if it should be subtracted or added to current image's pixel value to recover predicted pixel value.
		    //pred_pix =  diff[d_pos] > 0 ? curr_pix - diff_pix: curr_pix + diff_pix;                    
            // Assume Original - Reconstructed  = Difference. Therefore, Original - Difference = Reconstructed.
            pred_pix =  curr_pix - diff_pix;

            if ((pred_pix < 0) || (pred_pix > 255))            
                printf("Invalid Luma Value 3. %d, i, %d, j, %d,  curr_pix, %d, diff_pix, %d\n", pred_pix, i, j, curr_pix, diff_pix);

			// 2
			imeanOrg   += curr_pix; 
			imeanEnc   += pred_pix;
			ivarOrg    += curr_pix * curr_pix;
			ivarEnc    += pred_pix * pred_pix;
			icovOrgEnc += curr_pix * pred_pix;

		    curr_pix = (int)currImg[cur_yj][cur_xi--];
            // YGJ 25th Feb 2013 - Had a bug was decrementing cur_xi twice. Also made it more readable by introducing diff_pix.
            diff_pix = (int)diff[d_pos--];
		
		    // YGJ 9th May 2012 - Done to check if diff is negative or positive before determing if it should be subtracted or added to current image's pixel value to recover predicted pixel value.
		    //pred_pix =  diff[d_pos] > 0 ? curr_pix - diff_pix: curr_pix + diff_pix;                    
            // Assume Original - Reconstructed  = Difference. Therefore, Original - Difference = Reconstructed.
            pred_pix =  curr_pix - diff_pix;

            if ((pred_pix < 0) || (pred_pix > 255))            
                printf("Invalid Luma Value 2. %d, i, %d, j, %d,  curr_pix, %d, diff_pix, %d\n", pred_pix, i, j, curr_pix, diff_pix);

		case 2: 

			// 1
			imeanOrg   += curr_pix; 
			imeanEnc   += pred_pix;
			ivarOrg    += curr_pix * curr_pix;
			ivarEnc    += pred_pix * pred_pix;
			icovOrgEnc += curr_pix * pred_pix;

		    curr_pix = (int)currImg[cur_yj][cur_xi--];
            // YGJ 25th Feb 2013 - Had a bug was decrementing cur_xi twice. Also made it more readable by introducing diff_pix.
            diff_pix = (int)diff[d_pos--];
		
		    // YGJ 9th May 2012 - Done to check if diff is negative or positive before determing if it should be subtracted or added to current image's pixel value to recover predicted pixel value.
		    //pred_pix =  diff[d_pos] > 0 ? curr_pix - diff_pix: curr_pix + diff_pix;                    
            // Assume Original - Reconstructed  = Difference. Therefore, Original - Difference = Reconstructed.
            pred_pix =  curr_pix - diff_pix;

            if ((pred_pix < 0) || (pred_pix > 255))            
                printf("Invalid Luma Value 1. %d, i, %d, j, %d,  curr_pix, %d, diff_pix, %d\n", pred_pix, i, j, curr_pix, diff_pix);

			// 0
			imeanOrg   += curr_pix; 
			imeanEnc   += pred_pix;
			ivarOrg    += curr_pix * curr_pix;
			ivarEnc    += pred_pix * pred_pix;
			icovOrgEnc += curr_pix * pred_pix;
			
		}

	// This will push it to the next row whilst keeping the same x location
	OneDimPos1 += height;
	}

	//mb_ssim = YGJ_DetermineSSIM(ivarOrg, imeanOrg, ivarEnc, imeanEnc, icovOrgEnc, win_pixels, win_pixels_bias, C1, C2, Location, Covar, AbsMeanDiff);
        	
    //YGJ Sat 23rd 	Feb 2013
    SSIMInfo = (Get_YGJ_SSIM_int() == FALSE)?
        YGJ_DetermineSSIM(ivarOrg, imeanOrg, ivarEnc, imeanEnc, icovOrgEnc, win_pixels, win_pixels_bias, C1, C2, Location, Covar, AbsMeanDiff):    
        YGJ_DetermineSSIM_int(ivarOrg, imeanOrg, ivarEnc, imeanEnc, icovOrgEnc, win_pixels, C1, C2, Location, Covar, AbsMeanDiff);

    //printf("YGJ_OneDimSSIM %f \n", mb_ssim);

	return SSIMInfo;

	}


// YGJ 29th Jan 2012  - SSIM with a 2x2 Non-Over-lapping Sliding Window on a one-dimensional array, 
//  YGJ 23rd March 2012 - SSIM from 1 Dimensional Array for both ref and enc but navigating in terms of a 2D. Bit odd
//double YGJ_OneDimSSIM_ME(float C1, float C2, int m, short *refImg, short* encImg, int height, int win_height, int win_width, int win_pixels, float win_pixels_bias, int Location)
//double YGJ_OneDimSSIM_ME(float C1, float C2, short *refImg, short* encImg, int SSIM_width, int SSIM_win_width, int win_pixels, float win_pixels_bias, int Location, float Covar, int AbsMeanDiff)
ssiminf YGJ_OneDimSSIM_ME(float C1, float C2, short *refImg, short* encImg, int SSIM_width, int SSIM_win_width, int win_pixels, float win_pixels_bias, int Location, float Covar, int AbsMeanDiff)
{
	//double mb_ssim;
    ssiminf SSIMInfo;

	int imeanOrg = 0, imeanEnc = 0, ivarOrg = 0, ivarEnc = 0, icovOrgEnc = 0;
	int ref_pix=0, enc_pix=0;
	int j=0, loc=0;
	// if  win_width == 2 then shift by 1 otherwise assume to be equal to 4 and thus shift by 2
	// later in the for loop shift the height by this value for w_shift, thus avoiding a multiplication
	// Used to ensure it stays within the sub-quadrant . i.e S0, S0+1, S0+w, S0+w+1
	int w_shift = (SSIM_win_width == 2) ? 1 : 2; 


	// Assuming height = width
	// May need to cast short as int at a later point.
	// Need to ensure 2D window search space is mapped to a 1D arrays.
	// In  j, m is used as the start position. For the y limit, it will be 1/2 Width times width (plus one to allow the last row)
	// In i, with the row set up it is a access of moving along from that location by the width of the windowing used
	for (j = 0; j < (SSIM_width << w_shift); j += SSIM_width)
	{
       
		loc = j + SSIM_win_width;
		// YGJ 26th March 2012 - Attempting to reduce a loop to save processing time. Currently according to Code Analyst it takes 7% of the 
		//was previously  for (i = j; i < j + win_width; i++), since win_width will be 2 (for 4x4) or 4 (for 8x8) thought best expand it.
		switch(SSIM_win_width)
		{
		case 4:
			//loc = j + 3;
            //if ((ref_pix < 0) || (ref_pix > 255) || (enc_pix < 0) || (enc_pix > 255))        
            //    printf("YGJ_OneDimSSIM_ME - (Loc. 4) Invalid Luma Value. ref_pix %d, SSIM_win_width, %d, j, %d,  enc_pix, %d, diff, %d\n", ref_pix, SSIM_win_width, j, enc_pix, ref_pix-enc_pix);
            
            loc--;

			ref_pix = (int)refImg[loc]; 
			enc_pix = (int)encImg[loc];

			imeanOrg   += ref_pix;
			imeanEnc   += enc_pix;
			ivarOrg    += ref_pix * ref_pix;
			ivarEnc    += enc_pix * enc_pix;
			icovOrgEnc += ref_pix * enc_pix;


            //if ((ref_pix < 0) || (ref_pix > 255) || (enc_pix < 0) || (enc_pix > 255))        
            //    printf("YGJ_OneDimSSIM_ME - (Loc. 3) Invalid Luma Value. ref_pix %d, SSIM_win_width, %d, j, %d,  enc_pix, %d, diff, %d\n", ref_pix, SSIM_win_width, j, enc_pix, ref_pix-enc_pix);
            
			loc--;

			ref_pix = (int)refImg[loc]; 
			enc_pix = (int)encImg[loc];

			imeanOrg   += ref_pix;
			imeanEnc   += enc_pix;
			ivarOrg    += ref_pix * ref_pix;
			ivarEnc    += enc_pix * enc_pix;
			icovOrgEnc += ref_pix * enc_pix;

		case 2:
			//loc = j + 1;	

            //if ((ref_pix < 0) || (ref_pix > 255) || (enc_pix < 0) || (enc_pix > 255))        
            //    printf("YGJ_OneDimSSIM_ME - (Loc. 2) Invalid Luma Value. ref_pix %d, SSIM_win_width, %d, j, %d,  enc_pix, %d, diff, %d\n", ref_pix, SSIM_win_width, j, enc_pix, ref_pix-enc_pix);
                        
            loc--;

			ref_pix = (int)refImg[loc]; 
			enc_pix = (int)encImg[loc];

			imeanOrg   += ref_pix;
			imeanEnc   += enc_pix;
			ivarOrg    += ref_pix * ref_pix;
			ivarEnc    += enc_pix * enc_pix;
			icovOrgEnc += ref_pix * enc_pix;


            //if ((ref_pix < 0) || (ref_pix > 255) || (enc_pix < 0) || (enc_pix > 255))        
            //    printf("YGJ_OneDimSSIM_ME - (Loc. 1) Invalid Luma Value. ref_pix %d, SSIM_win_width, %d, j, %d,  enc_pix, %d, diff, %d\n", ref_pix, SSIM_win_width, j, enc_pix, ref_pix-enc_pix);

			loc--;

			ref_pix = (int)refImg[loc]; 
			enc_pix = (int)encImg[loc];

			imeanOrg   += ref_pix;
			imeanEnc   += enc_pix;
			ivarOrg    += ref_pix * ref_pix;
			ivarEnc    += enc_pix * enc_pix;
			icovOrgEnc += ref_pix * enc_pix;
		
		}

	}

	// Working Fine	on 14th May 2012 (YGJ)
	//if (ref_pix > 255 || ref_pix < 0 || enc_pix < -255 || enc_pix > 255)
	//		printf("YGJ_Compute_LocalSSIM, ref_pix, %d, enc_pix, %d, imeanOrg, %d, imeanEnc, %d, location, %d, j, %d, SSIM_width, %d, SSIM_win_width, %d, loc, % d \n", 
	//		ref_pix, enc_pix, imeanOrg, imeanEnc, Location, j, SSIM_width, SSIM_win_width, loc);


	//mb_ssim = YGJ_DetermineSSIM(ivarOrg, imeanOrg, ivarEnc, imeanEnc, icovOrgEnc, win_pixels, win_pixels_bias, C1, C2, Location, Covar, AbsMeanDiff);
    //YGJ Sat 23rd 	Feb 2013
    SSIMInfo = (Get_YGJ_SSIM_int() == FALSE)?
        YGJ_DetermineSSIM(ivarOrg, imeanOrg, ivarEnc, imeanEnc, icovOrgEnc, win_pixels, win_pixels_bias, C1, C2, Location, Covar, AbsMeanDiff):    
        YGJ_DetermineSSIM_int(ivarOrg, imeanOrg, ivarEnc, imeanEnc, icovOrgEnc, win_pixels, C1, C2, Location, Covar, AbsMeanDiff);

	return SSIMInfo;

	}


//double YGJ_OneDimSSIM_ME_Single(float C1, float C2, short *refImg, short* encImg, int SSIM_width, int win_pixels, float win_pixels_bias, int Location, float *Covar, int *AbsMeanDiff)
ssiminf YGJ_OneDimSSIM_ME_Single(float C1, float C2, short *refImg, short* encImg, int SSIM_width, int win_pixels, float win_pixels_bias, int Location, float Covar, int AbsMeanDiff)
{
	//double mb_ssim;
    ssiminf SSIMInfo;

	int imeanOrg = 0, imeanEnc = 0, ivarOrg = 0, ivarEnc = 0, icovOrgEnc = 0;
	int ref_pix=0, enc_pix=0;
	int j=0, loc=0;
    int w_shift = (SSIM_width == 4) ? 2 : 3; 

    // YGJ 25th Feb 2013 - Not an issue in OneDimSSIM_ME_Single
    //if (win_pixels != (SSIM_width*SSIM_width))
      //  printf("YGJ_Compute_LocalSSIM, win_pixels, %d, not equal to SSIM_width^2, %d ^2, \n", win_pixels, SSIM_width);


	// Assuming height = width
	// May need to cast short as int at a later point.
	// Need to ensure 2D window search space is mapped to a 1D arrays.
	// In  j, m is used as the start position. For the y limit, it will be 1/2 Width times width (plus one to allow the last row)
	// In i, with the row set up it is a access of moving along from that location by the width of the windowing used
	for (j = 0; j < (SSIM_width << w_shift); j += SSIM_width)
	{

		loc = j + SSIM_width;

		// YGJ 26th March 2012 - Attempting to reduce a loop to save processing time. Currently according to Code Analyst it takes 7% of the 
		//was previously  for (i = j; i < j + win_width; i++), since win_width will be 2 (for 4x4) or 4 (for 8x8) thought best expand it.
		switch(SSIM_width)
		{
		case 8:
			//loc = j + 3;

            //if ((ref_pix < 0) || (ref_pix > 255) || (enc_pix < 0) || (enc_pix > 255))        
            //    printf("YGJ_OneDimSSIM_ME_Single - (Loc. 8) Invalid Luma Value. ref_pix %d, SSIM_width, %d, j, %d,  enc_pix, %d, diff, %d\n", ref_pix, SSIM_width, j, enc_pix, ref_pix-enc_pix);


			loc--;

			ref_pix = (int)refImg[loc]; 
			enc_pix = (int)encImg[loc];

			imeanOrg   += ref_pix;
			imeanEnc   += enc_pix;
			ivarOrg    += ref_pix * ref_pix;
			ivarEnc    += enc_pix * enc_pix;
			icovOrgEnc += ref_pix * enc_pix;


            //if ((ref_pix < 0) || (ref_pix > 255) || (enc_pix < 0) || (enc_pix > 255))        
            //    printf("YGJ_OneDimSSIM_ME_Single - (Loc. 7) Invalid Luma Value. ref_pix %d, SSIM_width, %d, j, %d,  enc_pix, %d, diff, %d\n", ref_pix, SSIM_width, j, enc_pix, ref_pix-enc_pix);


			loc--;

			ref_pix = (int)refImg[loc]; 
			enc_pix = (int)encImg[loc];

			imeanOrg   += ref_pix;
			imeanEnc   += enc_pix;
			ivarOrg    += ref_pix * ref_pix;
			ivarEnc    += enc_pix * enc_pix;
			icovOrgEnc += ref_pix * enc_pix;

		//case 6:
			//loc = j + 1;		

            //if ((ref_pix < 0) || (ref_pix > 255) || (enc_pix < 0) || (enc_pix > 255))        
            //    printf("YGJ_OneDimSSIM_ME_Single - (Loc. 6) Invalid Luma Value. ref_pix %d, SSIM_width, %d, j, %d,  enc_pix, %d, diff, %d\n", ref_pix, SSIM_width, j, enc_pix, ref_pix-enc_pix);


			loc--;

			ref_pix = (int)refImg[loc]; 
			enc_pix = (int)encImg[loc];

			imeanOrg   += ref_pix;
			imeanEnc   += enc_pix;
			ivarOrg    += ref_pix * ref_pix;
			ivarEnc    += enc_pix * enc_pix;
			icovOrgEnc += ref_pix * enc_pix;


            //if ((ref_pix < 0) || (ref_pix > 255) || (enc_pix < 0) || (enc_pix > 255))        
            //    printf("YGJ_OneDimSSIM_ME_Single - (Loc. 5) Invalid Luma Value. ref_pix %d, SSIM_width, %d, j, %d,  enc_pix, %d, diff, %d\n", ref_pix, SSIM_width, j, enc_pix, ref_pix-enc_pix);


			loc--;

			ref_pix = (int)refImg[loc]; 
			enc_pix = (int)encImg[loc];

			imeanOrg   += ref_pix;
			imeanEnc   += enc_pix;
			ivarOrg    += ref_pix * ref_pix;
			ivarEnc    += enc_pix * enc_pix;
			icovOrgEnc += ref_pix * enc_pix;

		case 4:
			//loc = j + 3;

            //if ((ref_pix < 0) || (ref_pix > 255) || (enc_pix < 0) || (enc_pix > 255))        
            //    printf("YGJ_OneDimSSIM_ME_Single - (Loc. 4) Invalid Luma Value. ref_pix %d, SSIM_width, %d, j, %d,  enc_pix, %d, diff, %d\n", ref_pix, SSIM_width, j, enc_pix, ref_pix-enc_pix);

			loc--;

			ref_pix = (int)refImg[loc]; 
			enc_pix = (int)encImg[loc];

			imeanOrg   += ref_pix;
			imeanEnc   += enc_pix;
			ivarOrg    += ref_pix * ref_pix;
			ivarEnc    += enc_pix * enc_pix;
			icovOrgEnc += ref_pix * enc_pix;

            //if ((ref_pix < 0) || (ref_pix > 255) || (enc_pix < 0) || (enc_pix > 255))        
            //    printf("YGJ_OneDimSSIM_ME_Single - (Loc. 3) Invalid Luma Value. ref_pix %d, SSIM_width, %d, j, %d,  enc_pix, %d, diff, %d\n", ref_pix, SSIM_width, j, enc_pix, ref_pix-enc_pix);

			loc--;

			ref_pix = (int)refImg[loc]; 
			enc_pix = (int)encImg[loc];

			imeanOrg   += ref_pix;
			imeanEnc   += enc_pix;
			ivarOrg    += ref_pix * ref_pix;
			ivarEnc    += enc_pix * enc_pix;
			icovOrgEnc += ref_pix * enc_pix;

		case 2:
			//loc = j + 1;		

            //if ((ref_pix < 0) || (ref_pix > 255) || (enc_pix < 0) || (enc_pix > 255))        
            //    printf("YGJ_OneDimSSIM_ME_Single - (Loc. 2) Invalid Luma Value. ref_pix %d, SSIM_width, %d, j, %d,  enc_pix, %d, diff, %d\n", ref_pix, SSIM_width, j, enc_pix, ref_pix-enc_pix);

			loc--;

			ref_pix = (int)refImg[loc]; 
			enc_pix = (int)encImg[loc];

			imeanOrg   += ref_pix;
			imeanEnc   += enc_pix;
			ivarOrg    += ref_pix * ref_pix;
			ivarEnc    += enc_pix * enc_pix;
			icovOrgEnc += ref_pix * enc_pix;

            //if ((ref_pix < 0) || (ref_pix > 255) || (enc_pix < 0) || (enc_pix > 255))        
            //    printf("YGJ_OneDimSSIM_ME_Single - (Loc. 1) Invalid Luma Value. ref_pix %d, SSIM_width, %d, j, %d,  enc_pix, %d, diff, %d\n", ref_pix, SSIM_width, j, enc_pix, ref_pix-enc_pix);

			loc--;

			ref_pix = (int)refImg[loc]; 
			enc_pix = (int)encImg[loc];

			imeanOrg   += ref_pix;
			imeanEnc   += enc_pix;
			ivarOrg    += ref_pix * ref_pix;
			ivarEnc    += enc_pix * enc_pix;
			icovOrgEnc += ref_pix * enc_pix;
		
		}

	}

	// Working Fine	on 14th May 2012 (YGJ)
	//if (ref_pix > 255 || ref_pix < 0 || enc_pix < -255 || enc_pix > 255)
	//		printf("YGJ_Compute_LocalSSIM, ref_pix, %d, enc_pix, %d, imeanOrg, %d, imeanEnc, %d, location, %d, j, %d, SSIM_width, %d, SSIM_win_width, %d, loc, % d \n", 
	//		ref_pix, enc_pix, imeanOrg, imeanEnc, Location, j, SSIM_width, SSIM_win_width, loc);


    //YGJ Sat 23rd 	Feb 2013
    SSIMInfo = (Get_YGJ_SSIM_int() == FALSE)?
        YGJ_DetermineSSIM(ivarOrg, imeanOrg, ivarEnc, imeanEnc, icovOrgEnc, win_pixels, win_pixels_bias, C1, C2, Location, Covar, AbsMeanDiff):    
        YGJ_DetermineSSIM_int(ivarOrg, imeanOrg, ivarEnc, imeanEnc, icovOrgEnc, win_pixels, C1, C2, Location, Covar, AbsMeanDiff);

	return SSIMInfo;

	}



int YGJ_MyoEdgeDetect(double xy, double xmin1y, double xymin1) { return (((4 * xy - 2*(xmin1y + xymin1)) > 0.0) ? 	1 : 0 ); }

// YGJ 1st May 2012
// Uses the Average Luma for Encoded block when calculating SSIM - used to apply local average
// x, x-1, x-3, x-4 - Includes the surrounding Sliding Windows Average Values. Min Value for Location is 4, max is 8
// Assumes Local SSIM was calculated using a Slidin Window that starts from top left goes across before going down one, in terms of window size (win_height, win_width, respectively) . 
// Since Edge Detect is dependent on the location above and and adjacent (left) to it those windows are used, along side the diagnol, making it possible to calc average using shifting.
//int YGJ_LocalLumaAve(int Location) { return ((YGJ_LSSIM_meanEnc[Location] + YGJ_LSSIM_meanEnc[Location-1] + YGJ_LSSIM_meanEnc[Location-3] + YGJ_LSSIM_meanEnc[Location-4]) >> 2);}
//int YGJ_LocalLumaAve(int Location) { return YGJ_LSSIM_meanEnc[Location];}
int YGJ_LocalLumaAve(int Quadrant) 
{ 		
	int Init_Loc[4] = {0, 2, 6, 7};
	int Loc = Init_Loc[Quadrant];
	
	int Side1_Loc[4] = {1, 1, 7, 7};
	int Side1 = Side1_Loc[Quadrant];
			
	int Side2_Loc[4] = {4, 6, 4, 6};
	int Side2 = Side2_Loc[Quadrant];
	
	// YGJ 8th May 2012
	// (a + b/2 + c/2 + d/4)/~2, where a is the top left, top right, bottom left or bottom right local SSIM average value, weighted as one as they cover the respective quadrant; 
	// b and c refer the adjacent local SSIM average values, but only half is in this particular quadrant, and finally d is always 5, as this is at the centre covers all four quadrants.
	// Ideally it should be divided by 2 and 1/4 but for the fact speed is important this is shortened to 2 by using bit shift.
	int QuadrantAverage = ((YGJ_LSSIM_meanEnc[Loc] + ((YGJ_LSSIM_meanEnc[Side1] + YGJ_LSSIM_meanEnc[Side2]) >> 1) + (YGJ_LSSIM_meanEnc[5] >> 2)) >> 1);

	return QuadrantAverage;
}

	

//Used to set the average based upon the local SSIM values 
//void YGJ_SetResidualAverage(int i, int j,  int **encImg, int mb_x, int mb_y, int win_height, int win_width, int LocalAverage)
void YGJ_SetResidualAverage(int i, int **encImg, int mb_x, int win_height, int win_width, int LocalAverage)
{		
	int jj = 0, ii = win_width - 1;
	int enc_yj = 0, enc_xi = mb_x + ii + i; 

	for (jj = 0; jj < win_height; jj++)	
	{	
		enc_yj = jj;

		switch(win_width)
		{
					
		case 8: 
			encImg[enc_yj][enc_xi--] += LocalAverage; // +  encImg[enc_yj][enc_xi]) >> 1; //7
			encImg[enc_yj][enc_xi--] += LocalAverage; //+  encImg[enc_yj][enc_xi]) >> 1; //6
			encImg[enc_yj][enc_xi--] += LocalAverage; // +  encImg[enc_yj][enc_xi]) >> 1; //5
			encImg[enc_yj][enc_xi--] += LocalAverage; // +  encImg[enc_yj][enc_xi]) >> 1; //4
						
		case 4: 
			encImg[enc_yj][enc_xi--] += LocalAverage; // +  encImg[enc_yj][enc_xi]) >> 1; //3
			encImg[enc_yj][enc_xi--] += LocalAverage; // +  encImg[enc_yj][enc_xi]) >> 1; //2
					
		case 2:		
			encImg[enc_yj][enc_xi--] += LocalAverage; // +  encImg[enc_yj][enc_xi]) >> 1; //1
			encImg[enc_yj][enc_xi--] += LocalAverage; // +  encImg[enc_yj][enc_xi]) >> 1; //0
	
		}
	}
	return;
}


//Used to set the average luma for encoded block  based upon the local SSIM values 
// if boolOverlap == 1 then Assumes Overlapping SSIM was used.  Thus calcs average of averages.
void YGJ_SetQuadResidualAverage(int **encImg, int mb_x, int win_height, int win_width, int overlapSize_width, int overlapSize_height, int Quadrant, int boolOverlap)
{
		
	int jj = 0, ii = win_width - 1;
	int enc_yj = 0, enc_xi = 0,  enc_pix = 0;
	int Init_Loc[4] = {4, 5, 7, 8};
	int Location = Init_Loc[Quadrant];
	// x, x-1, x-3, x-4 - Includes the surrounding Sliding Windows Average Values. Min Value for Location is 4, max is 8
	//int LocalAverage = boolOverlap == 1? YGJ_LocalLumaAve(Location) : YGJ_LSSIM_meanEnc[Quadrant];
	int LocalAverage = boolOverlap == 1? YGJ_LocalLumaAve(Quadrant) : YGJ_LSSIM_meanEnc[Quadrant];

	int Init_win_y[4] = {0, 0, 1, 1};
	int Init_win_x[4] = {0, 1, 0, 1};

	int j = Init_win_y[Quadrant] == 0 ? 0 : win_height;
	int i = Init_win_x[Quadrant] == 0 ? 0 : win_width;

	// Only operate if beyond these bounds
	//if ((LocalAverage > 48 && LocalAverage < 208) || (LocalAverage < -48 && LocalAverage > -208) )
	if ((LocalAverage > 32 && LocalAverage < 224) || (LocalAverage < -32 && LocalAverage > -224) )
		return;
	
	// Therefore a max/ min of +15/-15.
	LocalAverage = LocalAverage >> 4; // 1/16  (0.0625)

	YGJ_SetResidualAverage(i, &encImg[j], mb_x, win_height, win_width, LocalAverage);

	return;
}

// YGJ 4th May 2012 - Internal call to CalcSSIM - Nine Locations
//double YGJ_CalcSSIM_Overlap(double *LSSIM, float C1, float C2, int overlapSize_width, int overlapSize_height, imgpel **refImg, imgpel **encImg, int opix_x, int mb_x, int win_height, int win_width, int win_pixels, float win_pixels_bias, float Covar, int AbsMeanDiff)
ssiminf YGJ_CalcSSIM_Overlap(double *LSSIM, float C1, float C2, int overlapSize_width, int overlapSize_height, imgpel **refImg, imgpel **encImg, int opix_x, int mb_x, int win_height, int win_width, int win_pixels, float win_pixels_bias)
{
	double cur_distortion = 0.0;
    ssiminf SSIMInfo;

	// First Row - LSSIM[j][i] = Compute SSIM(i, j) // 0,0,; w, 0; 2w, 0;
	//cur_distortion += LSSIM[0] = 
    
    SSIMInfo = YGJ_Compute_LocalSSIM(C1, C2, 0, refImg, encImg, opix_x, mb_x, win_height, win_width, win_pixels, win_pixels_bias, 0, 0, 0);
    cur_distortion += LSSIM[0] = SSIMInfo.SSIMScore;
    
    SSIMInfo = YGJ_Compute_LocalSSIM(C1, C2, overlapSize_width, refImg, encImg, opix_x, mb_x, win_height, win_width, win_pixels, win_pixels_bias, 1, SSIMInfo.Covariance, SSIMInfo.AbsMeanDiff);
	cur_distortion += LSSIM[1] = SSIMInfo.SSIMScore;

    SSIMInfo = YGJ_Compute_LocalSSIM(C1, C2, win_width, refImg, encImg, opix_x, mb_x, win_height, win_width, win_pixels, win_pixels_bias, 2, SSIMInfo.Covariance, SSIMInfo.AbsMeanDiff);
    cur_distortion += LSSIM[2] = SSIMInfo.SSIMScore;
		
	// Second  Row - LSSIM[j][i] = Compute SSIM(i, j) // 0, h; w, h; 0, 2h;
	SSIMInfo = YGJ_Compute_LocalSSIM(C1, C2, 0, &refImg[overlapSize_height], &encImg[overlapSize_height], opix_x, mb_x, win_height, win_width, win_pixels, win_pixels_bias, 3, SSIMInfo.Covariance, SSIMInfo.AbsMeanDiff);
    cur_distortion += LSSIM[3] = SSIMInfo.SSIMScore;

	SSIMInfo = YGJ_Compute_LocalSSIM(C1, C2, overlapSize_width, &refImg[overlapSize_height], &encImg[overlapSize_height], opix_x, mb_x, win_height, win_width, win_pixels, win_pixels_bias, 4, SSIMInfo.Covariance, SSIMInfo.AbsMeanDiff);
    cur_distortion += LSSIM[4] = SSIMInfo.SSIMScore;

	SSIMInfo = YGJ_Compute_LocalSSIM(C1, C2, win_width, &refImg[overlapSize_height], &encImg[overlapSize_height], opix_x, mb_x, win_height, win_width, win_pixels, win_pixels_bias, 5, SSIMInfo.Covariance, SSIMInfo.AbsMeanDiff);
    cur_distortion += LSSIM[5] = SSIMInfo.SSIMScore;
	
	// Third Row - LSSIM[j][i] = Compute SSIM(i, j)  // w, 2h; 2w, h; 2w, 2h;
	SSIMInfo = YGJ_Compute_LocalSSIM(C1, C2, 0, &refImg[win_height], &encImg[win_height], opix_x, mb_x, win_height, win_width, win_pixels, win_pixels_bias, 6, SSIMInfo.Covariance, SSIMInfo.AbsMeanDiff);
    cur_distortion += LSSIM[6] = SSIMInfo.SSIMScore;

	SSIMInfo = YGJ_Compute_LocalSSIM(C1, C2, overlapSize_width, &refImg[win_height], &encImg[win_height], opix_x, mb_x, win_height, win_width, win_pixels, win_pixels_bias, 7, SSIMInfo.Covariance, SSIMInfo.AbsMeanDiff);
    cur_distortion += LSSIM[7] = SSIMInfo.SSIMScore;

	SSIMInfo = YGJ_Compute_LocalSSIM(C1, C2, win_width, &refImg[win_height], &encImg[win_height], opix_x, mb_x, win_height, win_width, win_pixels, win_pixels_bias, 8, SSIMInfo.Covariance, SSIMInfo.AbsMeanDiff);
    cur_distortion += LSSIM[8] = SSIMInfo.SSIMScore;
	

	// YGJ 6th Feb 2012 - Fixed Number of iterations regardless of size of window, used as scaled search windows are used.
	cur_distortion /=  max_SSIM_Overlap;
    SSIMInfo.Covariance /= max_SSIM_Overlap; // YGJ 17th March 2013 - Also average out the Covariance

	SSIMInfo.SSIMScore = cur_distortion = cur_distortion >= 1.0 ? 1.0 : cur_distortion;

	return SSIMInfo;
}

// YGJ 4th May 2012 - Calc Edge Count for Given SSIM Map - Assumes Nine Search Windows (Local SSIMs)
int SSIMMapEdgeCount(double LSSIM[9])
{
	int 	ECount = 0;
	
	ECount += LSSIM[4] > 0.0 ? YGJ_MyoEdgeDetect(LSSIM[4], LSSIM[3], LSSIM[1]) : 0;
	ECount += LSSIM[5] > 0.0 ? YGJ_MyoEdgeDetect(LSSIM[5], LSSIM[4], LSSIM[2]) : 0;
	ECount += LSSIM[7] > 0.0 ? YGJ_MyoEdgeDetect(LSSIM[7], LSSIM[6], LSSIM[4]) : 0;
	ECount += LSSIM[8] > 0.0 ? YGJ_MyoEdgeDetect(LSSIM[8], LSSIM[7], LSSIM[5]) : 0;

	return  ECount;
}

int ManualSSIMC1AndC2Calc(VideoParameters *p_Vid, float *C1, float *C2)
{
    static const float K1 = 0.01f, K2 = 0.03f;
    float max_pix_value_sqd = (float) (p_Vid->max_pel_value_comp[0] * p_Vid->max_pel_value_comp[0]);
    
	*C1 = K1 * K1 * max_pix_value_sqd;
	*C2 = K2 * K2 * max_pix_value_sqd;

    return 0;
}

int LoadSSIMC1AndC2Values(VideoParameters *p_Vid, float *C1, float *C2)
{
    *C1 = (p_Vid->p_Inp->SSIMDist_Light == 0)?
        Get_YGJ_C1()
        :(float)Get_YGJ_C1_int();
            
    *C2 = (p_Vid->p_Inp->SSIMDist_Light == 0)?
        Get_YGJ_C2()
        :(float)Get_YGJ_C2_int();

    return 0;
}

//=========================================
//!<  SSIM then Myo's Sobel (Edge Detection)
//int YGJ_LocalSSIMwMyoEdge (VideoParameters *p_Vid, imgpel **refImg, imgpel **encImg, int opix_x, int opix_y, int mb_x, int mb_y, int height, int width)
int YGJ_LocalSSIMwMyoEdge (VideoParameters *p_Vid, imgpel **refImg, imgpel **encImg, int opix_x, int mb_x, int height, int width)
{
	//static const float K1 = 0.01f, K2 = 0.03f;
	//float max_pix_value_sqd;
	float C1, C2;
            
    //// YGJ 23rd Feb 2013 - tracking respective Covar and AbsMeanDiff for PseudoSSIM and for logging purposes
    //float Covar;
    //int AbsMeanDiff;
    ssiminf SSIMInfo;

	int win_height = YGJ_Calc_WinHeightOrWidth(height);
	int win_width = YGJ_Calc_WinHeightOrWidth(width);
	int win_pixels =  YGJ_Calc_WinPixels(win_height, win_width);
	#ifdef UNBIASED_VARIANCE
	float win_pixels_bias = (float)(win_pixels - 1);
#else
	float win_pixels_bias = (float)win_pixels;
#endif
	double cur_distortion = 0.0;
	int win_cnt = 0;
	int overlapSize_height = YGJ_Calc_OverlapSize(win_height);
	int overlapSize_width= YGJ_Calc_OverlapSize(win_width);
	int ShiftDivByOverlap_height = YGJ_Calc_ShiftDivByOverlap(overlapSize_height);
	int ShiftDivByOverlap_width = YGJ_Calc_ShiftDivByOverlap(overlapSize_width);
	//====================
	// YGJ 31st May 2011	
	double LSSIM[9]; //!<Used to store Local SSIM Values (of a 16x16 block), if overlapsize is 1 then it should be LSSIM 15x15 - Greater Accuracy/Smoother Sliding Window Movement
	double *ptrLSSIM; // ptr to LSSIM
	int EdgeCount=0;
	// Each with a overlap of half the window size so the number of EdgeCount will be the same, a maximum of 4.
	// Block Size -> Number of SSIM Calc -> Number of MyoSobel Calc
	// 4x4 -> 3x3 -> 2x2
	// 8x8 -> 3x3 -> 2x2
	// 16x16 -> 3x3 -> 2x2
	//double CalcLSSIM = 0.0;
	//====================
	
    // YGJ 21st Feb 2013
    (p_Vid->p_Inp->CalcSSIMConst == 0)?
        ManualSSIMC1AndC2Calc(p_Vid, &C1, &C2)
        : LoadSSIMC1AndC2Values(p_Vid, &C1, &C2);


	ptrLSSIM = LSSIM;

	SSIMInfo = YGJ_CalcSSIM_Overlap(ptrLSSIM, C1, C2, overlapSize_width, overlapSize_height, refImg, encImg, opix_x, mb_x, win_height, win_width, win_pixels, win_pixels_bias);

    cur_distortion = SSIMInfo.SSIMScore;

	EdgeCount = SSIMMapEdgeCount(LSSIM);
	
	// EdgeCountCapped based upon SSIM
	// YGJ 19th Oct 2011 - Simplified version of what was done in 20th Sept 2011 - YGJ.
			
	EdgeCount = cur_distortion < 0.05 && EdgeCount > 1 ? EdgeCount = 1 : 
		(cur_distortion < 0.1 && EdgeCount > 2 ? EdgeCount = 2 : EdgeCount);

	return EdgeCount;
}


//===============================================================================
// QP Delta Models

//!< New - 4x4 Specific
//!< Reality of attempting to be gentle on 4x4, preserving more
int DeltaQP4x4(int Pred, int Res)
{
	// from http://publications.gbdirect.co.uk/c_book/chapter6/initialization.html
//  double y[4][3] = {
//      {1, 3, 5},      /* y[0][0], y[0][1], y[0][2] */
//      {2, 4, 6},      /* y[1][0], y[1][1], y[1][2] */
//      {3, 5, 7}       /* y[2][0], y[2][1], y[2][2] */
//};
	int DeltaQPMap[5][5] = {
		{3,3,2,2,1},   /* y[0][0], y[0][1], y[0][2],y[0][3],y[0][4] */
		{3,3,2,1,1},   /* y[1][0], y[1][1], y[1][2],y[1][3],y[1][4] */ 
		{3,2,0,0,-1},  /* y[2][0], y[2][1], y[2][2],y[2][3],y[2][4] */ 
		{0,0,0,-1,-1},  /* y[3][0], y[3][1], y[3][2],y[3][3],y[3][4] */ 
		{0,0,-1,-1,-1} /* y[4][0], y[4][1], y[4][2],y[4][3],y[4][4] */ 
	};
	int DeltaQP=5;
	if (Pred > 4)
		Pred = 4;
	if (Res > 4)
		Res = 4;
	DeltaQP = DeltaQPMap[Res][Pred];
	return DeltaQP;
}

//!< New - 8x8 Specific
//!< Reality of attempting to moderate quantisation on 8x8, preserving only where edges are high
int DeltaQP8x8(int Pred, int Res)
{
	// from http://publications.gbdirect.co.uk/c_book/chapter6/initialization.html
//  double y[4][3] = {
//      {1, 3, 5},      /* y[0][0], y[0][1], y[0][2] */
//      {2, 4, 6},      /* y[1][0], y[1][1], y[1][2] */
//      {3, 5, 7}       /* y[2][0], y[2][1], y[2][2] */
//};
	int DeltaQPMap[5][5] = {
		{4,4,3,2,1},   /* y[0][0], y[0][1], y[0][2],y[0][3],y[0][4] */
		{4,3,3,1,0},   /* y[1][0], y[1][1], y[1][2],y[1][3],y[1][4] */ 
		{4,3,-1,-2,-3},  /* y[2][0], y[2][1], y[2][2],y[2][3],y[2][4] */ 
		{3,-3,-3,-3,-4},  /* y[3][0], y[3][1], y[3][2],y[3][3],y[3][4] */ 
		{-1,-4,-4,-4,-5} /* y[4][0], y[4][1], y[4][2],y[4][3],y[4][4] */ 
	};
	int DeltaQP=5;
	if (Pred > 4)
		Pred = 4;
	if (Res > 4)
		Res = 4;
	DeltaQP = DeltaQPMap[Res][Pred];
	return DeltaQP;
}
	
//!< New - 16x16 Specific
//!< Reality of attempting to make 16x16 competitive by being aggressive in quantisation for 16x16, 
//!< increasing distortion where no or few edges have being found.
int DeltaQP16x16(int Pred, int Res)
{
	// from http://publications.gbdirect.co.uk/c_book/chapter6/initialization.html
//  double y[4][3] = {
//      {1, 3, 5},      /* y[0][0], y[0][1], y[0][2] */
//      {2, 4, 6},      /* y[1][0], y[1][1], y[1][2] */
//      {3, 5, 7}       /* y[2][0], y[2][1], y[2][2] */
//}; 
	int DeltaQPMap[5][5] = {
		{9,6,4,3,0},   /* y[0][0], y[0][1], y[0][2],y[0][3],y[0][4] */
		{7,5,3,2,0},   /* y[1][0], y[1][1], y[1][2],y[1][3],y[1][4] */ 
		{5,0,-1,-2,-3},  /* y[2][0], y[2][1], y[2][2],y[2][3],y[2][4] */ 
		{0,-1,-2,-3,-4},  /* y[3][0], y[3][1], y[3][2],y[3][3],y[3][4] */ 
		{-1,-2,-3,-4,-5} /* y[4][0], y[4][1], y[4][2],y[4][3],y[4][4] */ 
	};
	int DeltaQP=5;
	if (Pred > 4)
		Pred = 4;
	if (Res > 4)
		Res = 4;
	DeltaQP = DeltaQPMap[Res][Pred];
	return DeltaQP;
}

//===============================

// Inter QPSteering - YGJ 10th Feb 2012
// Based upon YGJ_int_SSIM_MVDistMetric, in that is applies non-overlapping search window, thus reducing the search space but without the distortion metric
// It is designed to be an Inter version of LSSIMSobel. Inter Prediced Blocks and Inter Residual Blocks will be asses for Edges prior to Quantisation 
// The edge count will be returned. Then from whereever it is called i.e. luma_residual_coding, the two Edge Counts will be used to set the new QP prior to Quantisation before reverting it back.
int YGJ_NonOverlap_LSSIMwSobel (VideoParameters *p_Vid, imgpel **refImg, imgpel **encImg, int opix_x, int mb_x, int height, int width)
{
	//static const float K1 = 0.01f, K2 = 0.03f;
	//float max_pix_value_sqd;
	float C1, C2;
            
    // YGJ 23rd Feb 2013 - tracking respective Covar and AbsMeanDiff for PseudoSSIM and for logging purposes
    //float Covar;
    //int AbsMeanDiff;

    // YGJ 17th March 2013
    ssiminf SSIMInfo;


	int win_height = YGJ_Calc_WinHeightOrWidth(height);
	int win_width = YGJ_Calc_WinHeightOrWidth(width);
	int win_pixels =  YGJ_Calc_WinPixels(win_height, win_width);
	#ifdef UNBIASED_VARIANCE
	float win_pixels_bias = (float)(win_pixels - 1);
#else
	float win_pixels_bias = (float)win_pixels;
#endif
	double cur_distortion = 0.0;
	double LSSIM[4];
	//------------
	int StartLoc4x4[2] = {0, 2}; // 2x2 Window
	int StartLoc8x8[2] = {0, 4}; // 4x4 Window
	int StartLoc16x16[2] = {0, 8}; // 16x16 Window	
	int *ptrStartLoc = ((height == 4)? StartLoc4x4 : ((height == 8)? StartLoc8x8 : StartLoc16x16));
	//====================
	double CalcLSSIM = 0.0;
	int EdgeCount =0;
	//int PSeudoSSIM = 0;
	//====================	


    // YGJ 21st Feb 2013
    (p_Vid->p_Inp->CalcSSIMConst == 0)?
        ManualSSIMC1AndC2Calc(p_Vid, &C1, &C2)
        : LoadSSIMC1AndC2Values(p_Vid, &C1, &C2);

	//-----------
	// i, j	
	//cur_distortion += LSSIM[0] = 
     
    SSIMInfo = YGJ_Compute_LocalSSIM(C1, C2, ptrStartLoc[0], &refImg[ptrStartLoc[0]], &encImg[ptrStartLoc[0]], opix_x, mb_x, win_height, win_width, win_pixels, win_pixels_bias, 0, 0, 0); // 0, 0
    cur_distortion += LSSIM[0] = SSIMInfo.SSIMScore;
	
    //cur_distortion += LSSIM[1] = 
    SSIMInfo = YGJ_Compute_LocalSSIM(C1, C2, ptrStartLoc[1], &refImg[ptrStartLoc[0]], &encImg[ptrStartLoc[0]], opix_x, mb_x, win_height, win_width, win_pixels, win_pixels_bias, 1, SSIMInfo.Covariance, SSIMInfo.AbsMeanDiff);	// 1, 0
	cur_distortion += LSSIM[1] = SSIMInfo.SSIMScore;
    
    //cur_distortion += LSSIM[2] = 
    SSIMInfo = YGJ_Compute_LocalSSIM(C1, C2, ptrStartLoc[0], &refImg[ptrStartLoc[1]], &encImg[ptrStartLoc[1]], opix_x, mb_x, win_height, win_width, win_pixels, win_pixels_bias, 2, SSIMInfo.Covariance, SSIMInfo.AbsMeanDiff);		// 0, 1
	cur_distortion += LSSIM[2] = SSIMInfo.SSIMScore;
    
    //cur_distortion += LSSIM[3] = 
    SSIMInfo = YGJ_Compute_LocalSSIM(C1, C2, ptrStartLoc[1], &refImg[ptrStartLoc[1]], &encImg[ptrStartLoc[1]], opix_x, mb_x, win_height, win_width, win_pixels, win_pixels_bias, 3, SSIMInfo.Covariance, SSIMInfo.AbsMeanDiff);		// 1, 1
    cur_distortion += LSSIM[3] = SSIMInfo.SSIMScore;


	// YGJ 6th Feb 2012 - For Motion Vector based SSIM no overlapping due to high amount of searching computational resources required. Therefore only four non-overlapping search windows
	//cur_distortion /=  max_SSIM_NoOverlap;	
	//SSIMInfo.Covariance /= max_SSIM_NoOverlap;
        
    //SSIMInfo.SSIMScore = cur_distortion = cur_distortion >= 1.0 ? 1.0 : cur_distortion;
    
	// YGJ 7th Feb 2012 - Edge Count only if SSIM is > 0. To minimise phantom edges and undue processing		
	EdgeCount += LSSIM[3] > 0.0 ? YGJ_MyoEdgeDetect(LSSIM[3], LSSIM[2], LSSIM[1]) : 0;

	return (EdgeCount);	
}

//===============================

void YGJ_WriteBMP(FILE *fEnc, char strEnc[80], unsigned char *imgEnc, int w, int h )
{    	
	// Tuesday 19th April 2011
	// Hijacking compute_ssim code with this piece of code to save the difference between the Source (Ref) and Reconstructed (Enc) as a bitmap, 
	// similar to how I.E Richardson shows in his book

	// using code from the internet 
	// http://stackoverflow.com/questions/2654480/writing-bmp-image-in-pure-c-c-without-other-libraries
	// and guides such as http://www.fortunecity.com/skyscraper/windows/364/bmpffrmt.html

	// From these sites it is possible to gather the following
	// 1) Bitmaps start from the bottom right of an image to the top left
	// This is shown by the code which starts by streaming to file the bottom of the image.
	// 2) Grey is when all the channels as the same colour
	// So the difference calculated will be applied to each channel, R, G and B
	// 3) The rows of data written to file must be multiples of four
	// The source code from stackoverflow forum accounts for this already

	// Yetish Joshi

	int i=0;
			
	int filesize = 54 + 3*w*h;  //w is your image width, h is image height, both int

	unsigned char bmpfileheader[14] = {'B','M', 0,0,0,0, 0,0, 0,0, 54,0,0,0};
	unsigned char bmpinfoheader[40] = {40,0,0,0, 0,0,0,0, 0,0,0,0, 1,0, 24,0};
	unsigned char bmppad[3] = {0,0,0};

	//printf("About to write BMP, setting up the BMP file header \n"); 

	bmpfileheader[ 2] = (unsigned char)(filesize    );
	bmpfileheader[ 3] = (unsigned char)(filesize>> 8);
	bmpfileheader[ 4] = (unsigned char)(filesize>>16);
	bmpfileheader[ 5] = (unsigned char)(filesize>>24);

	bmpinfoheader[ 4] = (unsigned char)(       w    );
	bmpinfoheader[ 5] = (unsigned char)(       w>> 8);
	bmpinfoheader[ 6] = (unsigned char)(       w>>16);
	bmpinfoheader[ 7] = (unsigned char)(       w>>24);
	bmpinfoheader[ 8] = (unsigned char)(       h    );
	bmpinfoheader[ 9] = (unsigned char)(       h>> 8);
	bmpinfoheader[10] = (unsigned char)(       h>>16);
	bmpinfoheader[11] = (unsigned char)(       h>>24);
 
	//// Write Enc Frame as BMP

	//printf("Opening file for writing BMP \n"); 

	fEnc = fopen(strEnc,"wb");
	fwrite(bmpfileheader,1,14,fEnc);
	fwrite(bmpinfoheader,1,40,fEnc);
	for(i=0; i<h; i++)
	//for(i=h-1; i=0; --i)
	{
		//printf("Writing BMP Line: %d of maximum of %d, each containing at least %d elements \n", i, h, w); 
		fwrite(imgEnc+(w*i*3),3,w,fEnc);
		fwrite(bmppad,1,(4-(w*3)%4)%4,fEnc);
	}
	fclose(fEnc);

}


//====================== Distortion Metric ====================================



//// YGJ 21st Feb 2012
//// Used in MV Assessment where Distortion is checked againint Slice_Type,st the min on a rolling basis.
//// So therefore the Scale Factor is predetermined and since this depends on the Distortion, a multiply, shift  and an  addition is performed.



//! < YGJ 22nd July 2012 - PSeudoSSIM for use with SATD
//! < This implementation of SSIM to PseudoSSIM conversion is based upon the analysis of SSIM and SATD pair results for 4x4 and 8x8 blocks.
//! < The results used to first make an overall Cumulative Frequency Graph of SSIM for 4x4 and 8x8.
//! < These Cumulative Graphs were analysed so the curves may be modelled as a series of linear equations.
//! < In order to achieve this the Cumulative Graphs were reproduced with selective SSIM points which represented the majority of the original curves.
//! < These selective SSIM points, represented intervals which would be classed as Bands, with the expectation that each Band will eventually be modelled with a linear equation.  
//! < Before arriving to the final stage several iterative processes of refinement and balance must take place.
//! < The first is to evaluate those SSIM - SATD pairs at those Bands of SSIM (for 4x4 and 8x8), so that a reasonable realistic PSeudoSSIM distortion figure relative to SATD may eventually presented.
//! < Here, a	graph of SATD Score vs Frequency is analysed at each of these Bands to identify a suitable working range. Then that range is applied on that sample to appreciate the level of correlation.
//! < The second stage makes this iterative, as the neighbouring Bands working range for SATD score may overlap with a given Band. 
//! < Therefore, a balance of coverage of the given sample set and fitting closely with adjacent bands called upon.
//! < Once the mapping of SSIM Bands to operating PSeudoSSIM scores (based upon SSIM-SATD pair data) is completed then there is input (x) and output (y) data suitable for determining the linear equations.
//! < Remembering that y=mx+c, with m = gradient (change in y over change in x)  and c = the intercept (crossing the y-axis) it is possible to obtain the linear equations for each Band.
//! < But in reality these values calculated for m and c may not be computer (binary) friendly. So, approximating them closely to the fewest values divisible to the powers of 2 can lead to few bits required.
//! < Additionally, multiplying the initial SSIM value (from 0.XY as float) by 100 (to XY as int) one can conversely reduce the scale of gradient to manageable values (from 1000's to 10's).
//! < Yet, this itself leads to addition re-analysis of Bands as they must now be to 2 significant figures (s.f) and not up to 3 s.f.
//! < Overall this means looking at the size of samples affected by re-defining the bands at the new SSIM values compared to old,
//! < but to look at it in terms of the number of pairs of SSIM-SATD scores that would also fall within the proposed PSeudoSSIM output score range.
//! < So with a simplification of the approximate model the Bands set and the critically the linear equations used along with the implementation, this intends to be a SSIM to PSeudoSSIM output Model.
//! < 
//! < 


//! < Wed 15th August 2012  - YGJ. 
//! < Presented here is a PseudoSSIM that depending upon the band the SSIM value falls into will call particular linear equation.
//! <  The bands/bins for which SSIM value will fall into have been based upon taking SSIM-SATD pairs and looking at SSIM values in both a cumulative frequency curve and in frequency occurrence terms. 
//! < To identify potential bands by SSIM the sample pairs were first separated by their block size, either 4x4 or 8x8.  In terms of 8x8 there were over 23k samples collected with the Foreman QCIF video, encoding of the first three frames. .
//! < Looking at the rate of change on the Frequency-Occurrence graph gave an indication as to where band may be set, applying an additional difference on top accented where it dynamic is occurring, meaning a local minima or maxima happens there. 
//! < Identifying those where only negative values on this 2nd order difference presented the real foundations of where one might consider.
//! < A previous attempt the focus was on the Frequency-Accumulation Curve and applying solely by eye had been done, but felt not thorough.
//! < The use of this technique allowed for less human error and faster. It allowed one to consider if SSIM bands may be affected by changes to QP. 

//! < In order to investigate what if any changes applied by QP on the selection of SSIM bands, the samples were  collected with Quantisation Parameter  set at QP 20 (20 for I and P and 22 for B), QP 28 and QP 36.
//! < Changing QP seemed to make little or no difference to the SSIM boundaries, this allowed for a input in terms of  SSIM to be fixed.
//! < The range of QP used was deemed sufficient as any greater would seem not beneficial  as indicated by VCEG-AJ10_r1 (recommends testing at QP22, 27, 32 and 37) but more so by the fact SSIM in extreme circumstances (good or bad) 
//! < where little movement is available would not be always best suited compared to a true tractable metric like SATD.

//! < So with fixed SSIM bands broadly supporting earlier attempt and with little or no real evidence to alter them by QP the data (SSIM-SATD) was analysed in their respective bands of SSIM. 
//! < Here the distribution of the SATD values within the bands of SSIM (i.e. SSIM 1.0 - 0.96)  would be assessed.
//! <  A graphical plot of the 2nd Order Difference can only illustrate the clumps/clusters of results.  Though as the pairs of SSIM and SATD don't always correlate that well then as the SSIM value drops then the possible SATD range of values expands.
//! < Therefore decisions about the PSeudoSSIM range to impose for for each SSIM band must be taken. Using (inter) Quartile values can be used to understand the spread.
//! < But taking the difference between two points in the cumulative  frequency can more importantly help appreciate the number of samples within the band samples that would typically fall within the imposed PSeudoSSIM output band. 
//! < Eventually the banding structure and the PSeudoSSIM output is determine as a balance of reasonable coverage of existing SATDs within the respective SSIM bands coupled with the efficient use of computing resources to execute them.
//! < The effective coverage is rather poor as the direct correlation between SSIM and SATD is low and also by the fact that the equations associated with the bands are designed not to overlap. 
//! < This results in a figure of 20-25% of all SSIM-SATD pairs samples would fall within the output ranges of of the PseudoSSIM for the respective SSIM band. 
//! < A further 8% would be covered if the respective PSeudoSSIM equations were permitted to overlap to +/-10%, set, this increases by another 12% if +/-25% of PSeudoSSIM min and max values, thus near doubling the effective smaple coverage nearly one in every rwo samples.
//! < However overlapping is not permited as then values of lower SSIM would be given a lower Pseudo distortion than of a higher SSIM, 
//! < but this does illustrate the the fact the PSeudo values are well chosen considering it was designed without overlapping and those SATD that are not already seen within their resepcetive PseudoSSIM output bounds are likely to be within a reasonable degree of the bounds.
//! < This is relationship/distance between SATD and PSeudo-SSIM is important to note as the two values will be averaged out when return to the encoder to decide on the distortion for a gIven block.


// YGJ 27th Oct 2012 - Created reduce the likelihood of Human Error. Bit like a loot up table for Shifting. 
// Basically enter the value you have and the multiple you want 
int YGJ_QCalc(int OneMinSSIM1k, int Value )
{
    int result = 0;
    switch (Value)
    {
        case 1: result = OneMinSSIM1k;
            break;
        case 2: result = (OneMinSSIM1k << 1);
            break;
        case 3: result = (OneMinSSIM1k << 1)  + OneMinSSIM1k;
            break;
        case 4: result = (OneMinSSIM1k << 2);
            break;
        case 5: result = (OneMinSSIM1k << 2)  + OneMinSSIM1k;
            break;
        case 6: result = (OneMinSSIM1k << 2)  + (OneMinSSIM1k << 1);
            break;
        case 7: result = (OneMinSSIM1k << 3)  - OneMinSSIM1k;
            break;
        case 8: result = (OneMinSSIM1k << 3);
            break;
        case 9: result = (OneMinSSIM1k << 3)  + OneMinSSIM1k;
            break;
        //-------------------------------------------------------
            
        case 10: result = (OneMinSSIM1k << 3)  + (OneMinSSIM1k << 1);
            break;
        case 11: result = (OneMinSSIM1k << 3)  + (OneMinSSIM1k << 1)   + OneMinSSIM1k;
            break;
        case 12: result = (OneMinSSIM1k << 3)  + (OneMinSSIM1k << 2);
            break;
        case 13: result = (OneMinSSIM1k << 4)  - (OneMinSSIM1k << 1)  - OneMinSSIM1k;
            break;
        case 14: result = (OneMinSSIM1k << 4)  - (OneMinSSIM1k << 1);
            break;
        case 15: result = (OneMinSSIM1k << 4)  - OneMinSSIM1k;
            break;
        case 16: result = (OneMinSSIM1k << 4);
            break;
        case 17: result = (OneMinSSIM1k << 4)  + OneMinSSIM1k;
            break;                            
        case 18: result = (OneMinSSIM1k << 4)  + (OneMinSSIM1k << 1);
            break;
        case 19: result = (OneMinSSIM1k << 4)  + (OneMinSSIM1k << 1)  + OneMinSSIM1k;
            break;
        // --------------------------------------------------------
        case 20: result = (OneMinSSIM1k << 4)  + (OneMinSSIM1k << 2);
            break;
        case 21: result = (OneMinSSIM1k << 4)  + (OneMinSSIM1k << 2)  + OneMinSSIM1k;
            break;
        case 22: result = (OneMinSSIM1k << 4)  + (OneMinSSIM1k << 2)  + (OneMinSSIM1k << 1);
            break;
        case 23: result = (OneMinSSIM1k << 4)  + (OneMinSSIM1k << 3)  - OneMinSSIM1k;
            break;
        case 24: result = (OneMinSSIM1k << 4)  + (OneMinSSIM1k << 3);
            break;
        case 25: result = (OneMinSSIM1k << 4)  + (OneMinSSIM1k << 3)  + OneMinSSIM1k;
            break;
        case 26: result = (OneMinSSIM1k << 4)  + (OneMinSSIM1k << 3)  + (OneMinSSIM1k << 1);
            break;
        case 27: result = (OneMinSSIM1k << 5)  - (OneMinSSIM1k << 1)   - OneMinSSIM1k;
            break;
        case 28: result = (OneMinSSIM1k << 5)  - (OneMinSSIM1k << 2);
            break;
        case 29: result = (OneMinSSIM1k << 5)  - (OneMinSSIM1k << 1)  - OneMinSSIM1k;
            break;
        //-----------------------------------------------------------
        case 30: result = (OneMinSSIM1k << 5)  - (OneMinSSIM1k << 1);
            break;
        case 31: result = (OneMinSSIM1k << 5)  - OneMinSSIM1k;
            break;
        case 32: result = (OneMinSSIM1k << 5);
            break;
        case 33: result = (OneMinSSIM1k << 5)  + OneMinSSIM1k;
            break;            
        case 34: result = (OneMinSSIM1k << 5)  + (OneMinSSIM1k << 1);
            break;
        case 35: result = (OneMinSSIM1k << 5)  + (OneMinSSIM1k << 1)  + OneMinSSIM1k;
            break;
        case 36: result = (OneMinSSIM1k << 5)  + (OneMinSSIM1k << 2);
            break;
        case 37: result = (OneMinSSIM1k << 5)  + (OneMinSSIM1k << 2)  + OneMinSSIM1k;
            break;                    
        case 38: result = (OneMinSSIM1k << 5)  + (OneMinSSIM1k << 2)  + (OneMinSSIM1k << 1);
            break;
        case 39: result = (OneMinSSIM1k << 5)  + (OneMinSSIM1k << 3)  - OneMinSSIM1k;
            break;
        //-------------------------------------------------------------
        case 40: result = (OneMinSSIM1k << 5)  + (OneMinSSIM1k << 3);
            break;
        case 41: result = (OneMinSSIM1k << 5)  + (OneMinSSIM1k << 3) + OneMinSSIM1k;
            break;                
        case 44: result = (OneMinSSIM1k << 5)  + (OneMinSSIM1k << 4)  - (OneMinSSIM1k << 2);
            break;   
        case 45: result = (OneMinSSIM1k << 5)  + (OneMinSSIM1k << 4)  - (OneMinSSIM1k << 2)  + OneMinSSIM1k;
            break;        
        case 51: result = (OneMinSSIM1k << 6)  - (OneMinSSIM1k << 4)  + (OneMinSSIM1k << 2)  + OneMinSSIM1k;
            break; 
        case 53: result = (OneMinSSIM1k << 6)  - (OneMinSSIM1k << 3)  - (OneMinSSIM1k << 2)  + OneMinSSIM1k;
            break; 
        case 55: result = (OneMinSSIM1k << 6)  - (OneMinSSIM1k << 3)  - OneMinSSIM1k;
            break; 
        case 57: result = (OneMinSSIM1k << 6)  - (OneMinSSIM1k << 3)  + OneMinSSIM1k;
            break; 
        case 59: result = (OneMinSSIM1k << 6)  - (OneMinSSIM1k << 2)  - OneMinSSIM1k;
            break;             
        case 61: result = (OneMinSSIM1k << 6)  - (OneMinSSIM1k << 1)  + OneMinSSIM1k;
            break;
        case 62: result = (OneMinSSIM1k << 6)  - (OneMinSSIM1k << 1);
            break;
        case 67: result = (OneMinSSIM1k << 6)  + (OneMinSSIM1k << 1) + OneMinSSIM1k;
            break;
        case 73: result = (OneMinSSIM1k << 6)  + (OneMinSSIM1k << 3) + OneMinSSIM1k;
            break; 
        case 75: result = (OneMinSSIM1k << 6)  + (OneMinSSIM1k << 3) + (OneMinSSIM1k << 1) + OneMinSSIM1k;
            break; 
        case 77: result = (OneMinSSIM1k << 6)  + (OneMinSSIM1k << 3) + (OneMinSSIM1k << 2) + OneMinSSIM1k;
            break; 
        case 79: result = (OneMinSSIM1k << 6)  + (OneMinSSIM1k << 4) - OneMinSSIM1k;
            break;                      
        case 80: result = (OneMinSSIM1k << 6)  + (OneMinSSIM1k << 4);
            break;                      
        case 83: result = (OneMinSSIM1k << 6)  + (OneMinSSIM1k << 4) + (OneMinSSIM1k << 1) + OneMinSSIM1k;
            break;                                  
        case 85: result = (OneMinSSIM1k << 6)  + (OneMinSSIM1k << 4) + (OneMinSSIM1k << 2) + OneMinSSIM1k;
            break;                                  
        case 99: result = (OneMinSSIM1k << 7)  - (OneMinSSIM1k << 5) + (OneMinSSIM1k << 1) + OneMinSSIM1k;
            break;                
        case 105: result = (OneMinSSIM1k << 7)  - (OneMinSSIM1k << 4) - (OneMinSSIM1k << 3) + OneMinSSIM1k;
            break;
        case 113: result = (OneMinSSIM1k << 7)  - (OneMinSSIM1k << 4) + OneMinSSIM1k;
            break;
        case 117: result = (OneMinSSIM1k << 7)  - (OneMinSSIM1k << 3) - (OneMinSSIM1k << 2) + OneMinSSIM1k;
            break;
        case 420: result = (OneMinSSIM1k <<  8) + (OneMinSSIM1k << 7) + (OneMinSSIM1k <<  5) +  (OneMinSSIM1k <<  2);
            break;  
        //-------------------------------------------------------------------
        default : printf("YGJ_QCalc - Invalid Value setting, %d \n", Value);

    }

    return result;

    //return OneMinSSIM1k;
}

// YGJ 27th Oct 2012 - Created reudce the likelihood of Human Error. Bit like a loot up table for Shifting. 
// Basically enter the value you have and the multiple you want 
// However the Value needs to be an Int, so think of the fraction and multiple by 100. 
// Therefore this is only to 2 decimal places (2dp), even then this will be an approximate calculation only.
// Todo: Implement as calculated, then simplify
int YGJ_QFrac2dp(int OneMinSSIM1k, int Valuex100 )
{
    int result = 0;

    switch (Valuex100) // Used for where one wishes to get 0.33 as an approx. value via a a series of shifts, adds and subtracts, thus avoiding multiply
    {
        case 4: result = ((OneMinSSIM1k << 3) + (OneMinSSIM1k << 2) ) >> 8;  // 10/256
            break;
        case 8: result = ((OneMinSSIM1k << 2) + OneMinSSIM1k) >> 6;  // 5/64
            break;
        case 12: result = ((OneMinSSIM1k << 4) - OneMinSSIM1k ) >> 7;  // 15/128
            break;            
        case 13: result = ((OneMinSSIM1k << 5) + OneMinSSIM1k ) >> 8;  // 33/256
            break;
        case 14: result = ((OneMinSSIM1k << 3) + OneMinSSIM1k ) >> 6;  // 9/64
            break;
        case 17: result = ((OneMinSSIM1k << 3) + (OneMinSSIM1k << 2)  + OneMinSSIM1k ) >> 6;  // 13/64
            break;
        case 19: result = ((OneMinSSIM1k << 5) + (OneMinSSIM1k << 4)  + OneMinSSIM1k ) >> 8;  // 49/256
            break;
        case 23: result = ((OneMinSSIM1k << 6) - (OneMinSSIM1k << 2)  - OneMinSSIM1k ) >> 8;  // 59/256
            break;
        case 25: result = OneMinSSIM1k >> 2;
            break;                  
        case 30: result = ((OneMinSSIM1k << 6) + (OneMinSSIM1k << 4)  - (OneMinSSIM1k << 1) - OneMinSSIM1k ) >> 8;  // 77/256
            break;
        case 31: result = ((OneMinSSIM1k << 6) + (OneMinSSIM1k << 4)  - OneMinSSIM1k ) >> 8;  // 79/256
            break;
        case 33: result = ((OneMinSSIM1k << 4) + (OneMinSSIM1k << 2)  + OneMinSSIM1k ) >> 6;  // 21/64
            break;
        case 35: result = ((OneMinSSIM1k << 6) + (OneMinSSIM1k << 4)  + (OneMinSSIM1k << 3) + OneMinSSIM1k ) >> 8;  // 89/256
            break;
        case 36: result = ((OneMinSSIM1k << 4) + (OneMinSSIM1k << 3)  - OneMinSSIM1k ) >> 6;  // 23/64
            break; 
        case 38: result = ((OneMinSSIM1k << 7) - (OneMinSSIM1k << 5)  + OneMinSSIM1k ) >> 8;  // 97/256
            break;
        case 39: result = ((OneMinSSIM1k << 4) - (OneMinSSIM1k << 3)  + OneMinSSIM1k ) >> 6;  // 25/64
            break;        
        case 41: result = ((OneMinSSIM1k << 3) + (OneMinSSIM1k << 2)  + OneMinSSIM1k ) >> 5;  // 11/32
            break;
        case 43: result = ((OneMinSSIM1k << 6) - (OneMinSSIM1k << 3)  - OneMinSSIM1k ) >> 7;  // 55/128
            break;            
        case 44: result = ((OneMinSSIM1k << 3) - OneMinSSIM1k ) >> 4;  // 7/16
            break;
        case 47: result = ((OneMinSSIM1k << 4) - OneMinSSIM1k ) >> 5;  // 15/32
            break;
        case 50: result = OneMinSSIM1k  >> 1;
            break;
        case 53: result = ((OneMinSSIM1k << 4) + OneMinSSIM1k ) >> 5;  // 17/32
            break;
        case 54: result = ((OneMinSSIM1k << 6) + (OneMinSSIM1k << 2)  + OneMinSSIM1k ) >> 7;  // 69/128
            break;            
        case 56: result = ((OneMinSSIM1k << 7) + (OneMinSSIM1k << 4)  - OneMinSSIM1k ) >> 8;  // 143/256
            break;
        case 57: result = ((OneMinSSIM1k << 7) + (OneMinSSIM1k << 4)  + OneMinSSIM1k ) >> 8;  // 145/256
            break;
        case 58: result = ((OneMinSSIM1k << 5) + (OneMinSSIM1k << 2)  + OneMinSSIM1k ) >> 6;  // 37/64
            break;
        case 60: result = ((OneMinSSIM1k << 7) + (OneMinSSIM1k << 4) + (OneMinSSIM1k << 3) + OneMinSSIM1k ) >> 8;  // 153/256
            break;        
        case 63: result = ((OneMinSSIM1k << 7) + (OneMinSSIM1k << 5) + OneMinSSIM1k ) >> 8;  // 161/256
            break;        
        case 64: result = ((OneMinSSIM1k << 5) + (OneMinSSIM1k << 3) + OneMinSSIM1k ) >> 6;  // 41/64
            break;        
        case 67: result = ((OneMinSSIM1k << 8) + (OneMinSSIM1k << 6)  + (OneMinSSIM1k << 4)  + (OneMinSSIM1k << 3)  - OneMinSSIM1k ) >> 9;  // 343/512
            break;            
        // --------------------------------------------------------
        case 71: result = ((OneMinSSIM1k << 7) - (OneMinSSIM1k << 5)  - (OneMinSSIM1k << 2)  - OneMinSSIM1k ) >> 7;  // 91/128;
            break;
        case 75: result = OneMinSSIM1k - (OneMinSSIM1k << 4);
            break;
        case 78: result = ( (OneMinSSIM1k << 8) + (OneMinSSIM1k << 7) - (OneMinSSIM1k << 4) + OneMinSSIM1k) >> 9;  // 399/512
            break;
        case 81: result = ((OneMinSSIM1k << 8) - (OneMinSSIM1k << 6)  + (OneMinSSIM1k << 4)  - OneMinSSIM1k ) >> 8;  // 207/256;
            break;                            
        case 82: result = ((OneMinSSIM1k << 7) - (OneMinSSIM1k << 5)  + (OneMinSSIM1k << 3)  + OneMinSSIM1k ) >> 7;  // 105/128;
            break;                
        case 83: result = ((OneMinSSIM1k << 6) - (OneMinSSIM1k << 3)  - (OneMinSSIM1k << 1)  - OneMinSSIM1k ) >> 6;  // 53/64;
            break;                            
        case 84: result = ((OneMinSSIM1k << 8) - (OneMinSSIM1k << 5)  - (OneMinSSIM1k << 3)  - OneMinSSIM1k ) >> 8;  // 215/256
            break;
        case 86: result = ((OneMinSSIM1k << 6) - (OneMinSSIM1k << 3)  - OneMinSSIM1k ) >> 6;  // 55/64
            break;
        case 88: result = ((OneMinSSIM1k << 8) - (OneMinSSIM1k << 5)  + OneMinSSIM1k) >> 8;  // 225/256
            break;
        case 89: result = ((OneMinSSIM1k << 6) - (OneMinSSIM1k << 3)  + OneMinSSIM1k ) >> 6;  // 57/64
            break;
        case 90: result = ((OneMinSSIM1k << 7) - (OneMinSSIM1k << 4)  + (OneMinSSIM1k << 1)  + OneMinSSIM1k ) >> 7;  // 115/128;
            break;
        case 91: result = ((OneMinSSIM1k << 8) - (OneMinSSIM1k << 4)  - (OneMinSSIM1k << 3) + OneMinSSIM1k) >> 8;  // 233/256
            break;
        //case 92: result = ((OneMinSSIM1k << 8) - (OneMinSSIM1k << 4)  - (OneMinSSIM1k << 3) + (OneMinSSIM1k << 1) + OneMinSSIM1k) >> 8;  // 235/256
        case 92: result = ((OneMinSSIM1k << 6) - (OneMinSSIM1k << 2)  - OneMinSSIM1k) >> 6;  // 59/64
            break;
        case 93: result = ((OneMinSSIM1k << 7) - (OneMinSSIM1k << 3)  - OneMinSSIM1k ) >> 7; // 119/128
            break;
        case 94: result = ((OneMinSSIM1k << 4)  - OneMinSSIM1k ) >> 4; // 15/16
            break;
        case 95: result = ((OneMinSSIM1k << 8) - (OneMinSSIM1k << 4)  + (OneMinSSIM1k << 1) + OneMinSSIM1k) >> 8;  // 243/256
            break;
        case 96: result = ((OneMinSSIM1k << 7) - (OneMinSSIM1k << 2)  - OneMinSSIM1k ) >> 7; // 123/128
            break;
        //-------------------------------------------------------------------
        default : printf("YGJ_QFrac2dp - Invalid Valuex100 value, %d \n", Valuex100);

    }
    return result;

    //return OneMinSSIM1k;
}

// YGJ 27th Oct 2012 - Part of QScale
int YGJ_QScaleDenum(int OneMinSSIM1k, int denum)
{
    int result = 0;

    switch (denum)
    {
    case 2:  result = OneMinSSIM1k >> 1;
        break;
    case 4:  result = OneMinSSIM1k >> 2;
        break;
    case 8:  result = OneMinSSIM1k >> 3;
        break;
    case 16:  result = OneMinSSIM1k >> 4;
        break;
    case 32:  result = OneMinSSIM1k >> 5;
        break;
    case 64:  result = OneMinSSIM1k >> 6;
        break;
    case 128:  result = OneMinSSIM1k >> 7;
        break;
    case 256:  result = OneMinSSIM1k >> 8;
        break;
    case 512:  result = OneMinSSIM1k >> 9;
        break;
    case 1024: result = OneMinSSIM1k >> 10;
        break;
    case 2048: result = OneMinSSIM1k >> 11;
        break;
    default : printf("YGJ_QScaleDenum - Invalid denum value, %d \n", denum);
    }

    return result;
}

// YGJ 27th Oct 2012 - Part of a means to minimise human error by calling functions 
int YGJ_QScale(int OneMinSSIM1k, int num, int denum)
{
    int result =  0;

    if (denum > 0)
    {
        result = YGJ_QCalc(OneMinSSIM1k, num);

        result = YGJ_QScaleDenum(result, denum);
    }

    return result;

}



// For Where Covar is equal to 0
int YGJ_PseudoSSIM_Base(int OneMinSSIM1k, int SSIMCoVar, int MeanDiff)
{
    int PSeudoSSIM = -1;
    //int MeanDiffx1SSIM = (OneMinSSIM1k*MeanDiff);

    //--------------------
    // YGJ 26th Nov 2012 Covar = 0 (Cv+C2 = 58, looking at 1-SSIM < 0.2, distinct 1-SSIM values averaged out and then modelled.
    PSeudoSSIM = OneMinSSIM1k < 2 ?
    -1 // Use SATD instead 
    //:OneMinSSIM1k < 5 ? 
    //YGJ_QCalc(OneMinSSIM1k, 5) + (OneMinSSIM1k >> 1)  + 30
    :OneMinSSIM1k < 10 ?
    //YGJ_QCalc(OneMinSSIM1k, 3) + (OneMinSSIM1k >> 1)  + 41
    YGJ_QCalc(OneMinSSIM1k, 3) + (OneMinSSIM1k >> 2)  + 42
    :OneMinSSIM1k < 50 ?
    (OneMinSSIM1k << 1) + (OneMinSSIM1k >> 2)  + 46
    :OneMinSSIM1k < 100 ?
    OneMinSSIM1k + (OneMinSSIM1k >> 2)  + 96
    :OneMinSSIM1k < 600 ?
    OneMinSSIM1k + 128
    //--------------------                        
    :OneMinSSIM1k < 750 ?
    (OneMinSSIM1k << 1) - (OneMinSSIM1k >> 2)  -350
    :OneMinSSIM1k < 900 ?
    (OneMinSSIM1k << 2) - (OneMinSSIM1k >> 1)  - 2368
    :OneMinSSIM1k < 975 ?
    YGJ_QCalc(OneMinSSIM1k, 26)  - 22016
    //:OneMinSSIM1k < 480 ?
    //YGJ_QScale(OneMinSSIM1k, 51, 64) + 100
    //:OneMinSSIM1k < 560 ?
    //(OneMinSSIM1k >> 3)  + (OneMinSSIM1k >> 4) + 400 
    //:OneMinSSIM1k < 845 ?
    //OneMinSSIM1k  + (OneMinSSIM1k >> 2) - 200 
    :
    //YGJ_QCalc(OneMinSSIM1k, 12)  + (OneMinSSIM1k >> 2)- 9500 
    -1 // If Beyond scope
    ; 

    // Add Absolute Mean Difference related cost
    PSeudoSSIM += PSeudoSSIM > -1 && MeanDiff > 0? 
        //(YGJ_QScale(OneMinSSIM1k, 3, 128) + 6)  * MeanDiff : 0;
        (SSIMCoVar >> 4) * MeanDiff + MeanDiff
        : 0;
        
    // Now to add any Covariance related score
    PSeudoSSIM += PSeudoSSIM == -1 || SSIMCoVar == 0? 
        // Scaled Covar based 1-SSIM Gradient and Covar based Offset. Since 1-SSIM is actually 1-SSIM x 1k, it must be scaled down by 1k, hence right shift by 10 on the gradient.
        //((YGJ_QScale(SSIMCoVar, 41, 128) * OneMinSSIM1k) >> 10) + YGJ_QScale(SSIMCoVar, 77, 128)
        //((YGJ_QScale(SSIMCoVar, 77, 128) * OneMinSSIM1k) >> 7) + YGJ_QScale(SSIMCoVar, 77, 128)
        //((OneMinSSIM1k * (SSIMCoVar+1)) >> 7)
        0
        :OneMinSSIM1k < 10 ?
        //YGJ_QCalc(OneMinSSIM1k, 3) + (OneMinSSIM1k >> 2)  + 42
        ((OneMinSSIM1k* SSIMCoVar) >> 6) + ((YGJ_QCalc(SSIMCoVar, 5)) >> 3)
        :OneMinSSIM1k < 50 ?
        //(OneMinSSIM1k << 1) + (OneMinSSIM1k >> 2)  + 46
        ((OneMinSSIM1k* SSIMCoVar) >> 6) + ((YGJ_QCalc(SSIMCoVar, 3)) >> 2)
        :OneMinSSIM1k < 100 ?
        //OneMinSSIM1k + (OneMinSSIM1k >> 2)  + 96
        ((OneMinSSIM1k* SSIMCoVar) >> 6) + SSIMCoVar
        :OneMinSSIM1k < 600 ?
        //OneMinSSIM1k + 128
        ((OneMinSSIM1k* SSIMCoVar) >> 7) + ((YGJ_QCalc(SSIMCoVar, 3)) >> 1)
        //--------------------                        
        :OneMinSSIM1k < 750 ?
        //(OneMinSSIM1k << 1) - (OneMinSSIM1k >> 2)  -350
        ((OneMinSSIM1k* SSIMCoVar) >> 6) - YGJ_QCalc(SSIMCoVar, 3) - (SSIMCoVar>> 2)
        :OneMinSSIM1k < 900 ?
        //(OneMinSSIM1k << 2) - (OneMinSSIM1k >> 1)  - 2368
        ((OneMinSSIM1k* SSIMCoVar) >> 7) +  (OneMinSSIM1k << 1)
        :OneMinSSIM1k < 975 ?
        //YGJ_QCalc(OneMinSSIM1k, 26)  - 22016
        ((OneMinSSIM1k* SSIMCoVar) >> 7) +  OneMinSSIM1k

        : 0;

    return PSeudoSSIM;

}

int YGJ_PseudoSSIM_Cv150(int OneMinSSIM1k, int SSIMCoVar, int MeanDiff)
{
    int PSeudoSSIM = 0;
    //int MeanDiffx1SSIM = (OneMinSSIM1k*MeanDiff);

    //--------------------
    // YGJ 26th Nov 2012 Covar = 0 (Cv+C2 = 58, looking at 1-SSIM < 0.2, distinct 1-SSIM values averaged out and then modelled.
    PSeudoSSIM = OneMinSSIM1k < 2?
    -1 // Use SATD instead 
    //--------------------
    :OneMinSSIM1k < 10 ? 
    //(OneMinSSIM1k << 2) - (OneMinSSIM1k >> 1) + 125
    YGJ_QCalc(OneMinSSIM1k, 5) + (OneMinSSIM1k >> 1)  + 152
    :OneMinSSIM1k < 50 ? 
    //OneMinSSIM1k + YGJ_QScale(OneMinSSIM1k, 13, 32)  + 218
    YGJ_QCalc(OneMinSSIM1k, 5) + (OneMinSSIM1k >> 1)  + 152
    :OneMinSSIM1k < 100 ? 
    //OneMinSSIM1k + YGJ_QScale(OneMinSSIM1k, 13, 32)  + 383
    (OneMinSSIM1k << 4)  + 192
    :OneMinSSIM1k < 600 ?
    //OneMinSSIM1k + YGJ_QScale(OneMinSSIM1k, 51, 64) + 150
    (OneMinSSIM1k << 1) + (OneMinSSIM1k >> 1)  + 256
    :OneMinSSIM1k < 900 ?    
    //YGJ_QCalc(OneMinSSIM1k, 6) +  (OneMinSSIM1k >> 2) - 2850
    (OneMinSSIM1k << 2) + (OneMinSSIM1k >> 1)  -1024
    :
    //(OneMinSSIM1k << 1) - (OneMinSSIM1k >> 1) -  (OneMinSSIM1k >> 2) - 10500
    -1
    ;

    // Add Absolute Mean Difference related cost
    PSeudoSSIM += PSeudoSSIM > -1 && MeanDiff > 0? 
        //YGJ_QScale(MeanDiffx1SSIM, (16 - (OneMinSSIM1k >> 6)), 256): 0;
        (SSIMCoVar >> 4) * MeanDiff + MeanDiff
        : 0;

    // Now to add any Covariance related score
    PSeudoSSIM += PSeudoSSIM == -1 || SSIMCoVar == 0?
        // Scaled Covar based 1-SSIM Gradient and Covar based Offset. Since 1-SSIM is actually 1-SSIM x 1k, it must be scaled down by 1k, hence right shift by 10 on the gradient.
        //((YGJ_QScale(SSIMCoVar, 9, 16) * OneMinSSIM1k) >> 7) + YGJ_QScale(SSIMCoVar, 9, 16)
        0
        //--------------------
        :OneMinSSIM1k < 10 ? 
        //(OneMinSSIM1k << 2) - (OneMinSSIM1k >> 1) + 125
        //YGJ_QCalc(OneMinSSIM1k, 5) + (OneMinSSIM1k >> 1)  + 152
        ((OneMinSSIM1k* SSIMCoVar) >> 4) - (SSIMCoVar >> 2)
        :OneMinSSIM1k < 50 ? 
        //OneMinSSIM1k + YGJ_QScale(OneMinSSIM1k, 13, 32)  + 218
        //YGJ_QCalc(OneMinSSIM1k, 5) + (OneMinSSIM1k >> 1)  + 152
        ((OneMinSSIM1k* SSIMCoVar) >> 6) + (SSIMCoVar >> 3)
        :OneMinSSIM1k < 100 ? 
        //OneMinSSIM1k + YGJ_QScale(OneMinSSIM1k, 13, 32)  + 383
        //(OneMinSSIM1k << 4)  + 192
        ((OneMinSSIM1k* SSIMCoVar) >> 9) + SSIMCoVar
        :OneMinSSIM1k < 600 ?
        //OneMinSSIM1k + YGJ_QScale(OneMinSSIM1k, 51, 64) + 150
        //(OneMinSSIM1k << 1) + (OneMinSSIM1k >> 1)  + 256
        ((OneMinSSIM1k* SSIMCoVar) >> 8) + SSIMCoVar
        :OneMinSSIM1k < 900 ?    
        //YGJ_QCalc(OneMinSSIM1k, 6) +  (OneMinSSIM1k >> 2) - 2850
        //(OneMinSSIM1k << 2) + (OneMinSSIM1k >> 1)  -1024
        ((OneMinSSIM1k* SSIMCoVar) >> 7) - SSIMCoVar
        
        //((OneMinSSIM1k * SSIMCoVar) >> 7)
        : 0;

    return PSeudoSSIM;

}

int YGJ_PseudoSSIM_Cv300(int OneMinSSIM1k, int SSIMCoVar, int MeanDiff)
{
    int PSeudoSSIM = 0;
    //int MeanDiffx1SSIM = (OneMinSSIM1k*MeanDiff);

    //--------------------
    //// YGJ 26th Nov 2012 Covar = 0 (Cv+C2 = 58, looking at 1-SSIM < 0.2, distinct 1-SSIM values averaged out and then modelled.
    //PSeudoSSIM = OneMinSSIM1k < 7 ?
    //-1 // Use SATD instead 
    ////--------------------
    //:OneMinSSIM1k < 725 ?
    //(OneMinSSIM1k << 1) + YGJ_QScale(OneMinSSIM1k, 51, 256) + 150
    //:
    //YGJ_QCalc(OneMinSSIM1k, 12) - 7000
    //;

        
    //--------------------
    // YGJ 26th Nov 2012 Covar = 0 (Cv+C2 = 58, looking at 1-SSIM < 0.2, distinct 1-SSIM values averaged out and then modelled.
    PSeudoSSIM = OneMinSSIM1k < 2?
    -1 // Use SATD instead 
    //--------------------
    //:OneMinSSIM1k < 10 ?     
    //YGJ_QCalc(OneMinSSIM1k, 9) + 104
    //:OneMinSSIM1k < 20 ?     
    //YGJ_QCalc(OneMinSSIM1k, 9) + 104
    :OneMinSSIM1k < 50 ? 
    YGJ_QCalc(OneMinSSIM1k, 9) + 104
    :OneMinSSIM1k < 100 ? 
    (OneMinSSIM1k << 2) + 312    
    //:OneMinSSIM1k < 500 ? 
    //(OneMinSSIM1k << 2) + OneMinSSIM1k + 448
    :OneMinSSIM1k < 600 ?
    (OneMinSSIM1k << 2) + OneMinSSIM1k + 448
    :OneMinSSIM1k < 750 ?    
    //YGJ_QCalc(OneMinSSIM1k, 5) +  (OneMinSSIM1k >> 2) - 2850
    (OneMinSSIM1k << 2) + OneMinSSIM1k   -608
    :
    //(OneMinSSIM1k << 1) - (OneMinSSIM1k >> 1) -  (OneMinSSIM1k >> 2) - 10500
    -1
    ;


    // Add Absolute Mean Difference related cost
    PSeudoSSIM += PSeudoSSIM > -1 && MeanDiff > 0? 
        //YGJ_QScale(MeanDiffx1SSIM, (16 - (OneMinSSIM1k >> 6)), 256): 0;
        (YGJ_QScale(SSIMCoVar, 7, 128) - 4) * MeanDiff  + MeanDiff
        : 0; // -- This was for the 8x8 version

    // Now to add any Covariance related score
    PSeudoSSIM += PSeudoSSIM == -1 || SSIMCoVar == 0?
        // Scaled Covar based 1-SSIM Gradient and Covar based Offset. Since 1-SSIM is actually 1-SSIM x 1k, it must be scaled down by 1k, hence right shift by 10 on the gradient.
        //((YGJ_QScale(SSIMCoVar, 5, 8) * OneMinSSIM1k) >> 7) + YGJ_QScale(SSIMCoVar, 5, 8)
        //(15 - YGJ_QScale(OneMinSSIM1k, 3, 64)) * SSIMCoVar // -- This was for the 8x8 version
        //(SSIMCoVar << 3)
        //((OneMinSSIM1k * SSIMCoVar) >> 8)
        0
        :OneMinSSIM1k < 10 ?     
        //YGJ_QCalc(OneMinSSIM1k, 9) + 104
        ((OneMinSSIM1k* SSIMCoVar) >> 5) + (YGJ_QCalc(SSIMCoVar, 3) >> 4)
        :OneMinSSIM1k < 20 ?     
        //YGJ_QCalc(OneMinSSIM1k, 9) + 104
        ((OneMinSSIM1k* SSIMCoVar) >> 5) + (SSIMCoVar >> 3)
        :OneMinSSIM1k < 50 ? 
        //YGJ_QCalc(OneMinSSIM1k, 9) + 104
        (YGJ_QCalc(SSIMCoVar, 5) >> 3)
        :OneMinSSIM1k < 100 ? 
        //(OneMinSSIM1k << 2) + 312    
        ((OneMinSSIM1k* SSIMCoVar) >> 7) + (YGJ_QCalc(SSIMCoVar, 3) >> 3)
        :OneMinSSIM1k < 500 ? 
        //(OneMinSSIM1k << 2) + OneMinSSIM1k + 448
        ((OneMinSSIM1k* SSIMCoVar) >> 8) + (SSIMCoVar >> 1)
        :OneMinSSIM1k < 600 ?
        //(OneMinSSIM1k << 2) + OneMinSSIM1k + 448
        ((OneMinSSIM1k* SSIMCoVar) >> 7) - (YGJ_QCalc(SSIMCoVar, 3) >> 2)
        :OneMinSSIM1k < 750 ?    
        //YGJ_QCalc(OneMinSSIM1k, 5) +  (OneMinSSIM1k >> 2) - 2850
        //(OneMinSSIM1k << 2) + OneMinSSIM1k   -608
        ((OneMinSSIM1k* SSIMCoVar) >> 8) + (SSIMCoVar >> 1)
        : 0;

    return PSeudoSSIM;

}

int YGJ_PseudoSSIM_Cv600(int OneMinSSIM1k, int SSIMCoVar, int MeanDiff)
{
    int PSeudoSSIM = 0;
    //int MeanDiffx1SSIM = (OneMinSSIM1k*MeanDiff);

    //--------------------
    // YGJ 26th Nov 2012 Covar = 0 (Cv+C2 = 58, looking at 1-SSIM < 0.2, distinct 1-SSIM values averaged out and then modelled.
    //PSeudoSSIM = OneMinSSIM1k < 5 ?
    //-1 // Use SATD instead 
    //--------------------        
       
    PSeudoSSIM = OneMinSSIM1k < 10 ?
    //:OneMinSSIM1k < 10 ?     
    //YGJ_QCalc(OneMinSSIM1k, 9) + 104
    (OneMinSSIM1k << 4) + (OneMinSSIM1k >> 1) + 168
    :OneMinSSIM1k < 20 ?     
    YGJ_QCalc(OneMinSSIM1k, 13) + (OneMinSSIM1k >> 1) + 224
    :OneMinSSIM1k < 50 ? 
    //YGJ_QCalc(OneMinSSIM1k, 9) + 104
    (OneMinSSIM1k << 3) - OneMinSSIM1k + 352
    :OneMinSSIM1k < 100 ? 
    (OneMinSSIM1k << 2) + (OneMinSSIM1k << 1) + 448
    :OneMinSSIM1k < 550 ? 
    (OneMinSSIM1k << 2) + OneMinSSIM1k  - (OneMinSSIM1k >> 2) + 552
    //:OneMinSSIM1k < 600 ?
    //(OneMinSSIM1k << 2) + OneMinSSIM1k + 448
    //:OneMinSSIM1k < 750 ?    
    //YGJ_QCalc(OneMinSSIM1k, 5) +  (OneMinSSIM1k >> 2) - 2850
    //(OneMinSSIM1k << 2) + OneMinSSIM1k   -608
    //:
    
    //:OneMinSSIM1k < 625 ?
    //YGJ_QCalc(OneMinSSIM1k, 3)  - (OneMinSSIM1k >> 2) + 300
    :
    //YGJ_QCalc(OneMinSSIM1k, 12) - 5500
    -1
    ;
    
    // Add Absolute Mean Difference related cost
     PSeudoSSIM += PSeudoSSIM > -1 && MeanDiff > 0? 
         //YGJ_QScale(MeanDiffx1SSIM, (16 - (OneMinSSIM1k >> 6)), 512): 0;
         (YGJ_QScale(SSIMCoVar, 3, 512) + 16) * MeanDiff + MeanDiff
         : 0; // -- This was for the 8x8 version

    // Now to add any Covariance related score
    PSeudoSSIM += PSeudoSSIM == -1 || SSIMCoVar == 0?
        //((YGJ_QScale(SSIMCoVar, 23, 64) * OneMinSSIM1k) >> 7) + YGJ_QScale(SSIMCoVar, 23, 64)
        //(16 - YGJ_QScale(OneMinSSIM1k, 15, 1024)) * SSIMCoVar // -- This was for the 8x8 version
        //((OneMinSSIM1k * SSIMCoVar) >> 9)

        0      
        :OneMinSSIM1k < 10 ?     
        //YGJ_QCalc(OneMinSSIM1k, 9) + 104
        ((OneMinSSIM1k* SSIMCoVar) >> 6) + (SSIMCoVar >> 4)
        //:OneMinSSIM1k < 20 ?     
        //YGJ_QCalc(OneMinSSIM1k, 9) + 104
        //((OneMinSSIM1k* SSIMCoVar) >> 7) + (SSIMCoVar >> 3)
        :OneMinSSIM1k < 50 ? 
        //YGJ_QCalc(OneMinSSIM1k, 9) + 104
        ((OneMinSSIM1k* SSIMCoVar) >> 7) + (SSIMCoVar >> 3)
        :OneMinSSIM1k < 100 ? 
        //(OneMinSSIM1k << 2) + 312    
        ((OneMinSSIM1k* SSIMCoVar) >> 10) + (YGJ_QCalc(SSIMCoVar, 3) >> 3)
        :OneMinSSIM1k < 550 ? 
        //(OneMinSSIM1k << 2) + OneMinSSIM1k + 448
        ((OneMinSSIM1k* SSIMCoVar) >> 9) + (SSIMCoVar >> 2)
 

        : 0;

    return PSeudoSSIM;

}


int YGJ_PseudoSSIM_Cv1350(int OneMinSSIM1k, int SSIMCoVar, int MeanDiff)
{
    int PSeudoSSIM = 0;
    //int MeanDiffx1SSIM = (OneMinSSIM1k*MeanDiff);

    //--------------------
    // YGJ 26th Nov 2012 Covar = 0 (Cv+C2 = 58, looking at 1-SSIM < 0.2, distinct 1-SSIM values averaged out and then modelled.
    //PSeudoSSIM = OneMinSSIM1k < 3 ?   
    //-1 // Use SATD instead 
    //--------------------        
        
    PSeudoSSIM = OneMinSSIM1k < 10 ?
    //:OneMinSSIM1k < 10 ?     
    //YGJ_QCalc(OneMinSSIM1k, 9) + 104
        YGJ_QCalc(OneMinSSIM1k, 30) + 244
        //:OneMinSSIM1k < 15 ?     
        //YGJ_QCalc(OneMinSSIM1k, 17) + 368
        :OneMinSSIM1k < 20 ?     
        YGJ_QCalc(OneMinSSIM1k, 17) + 368
        //:OneMinSSIM1k < 50 ? 
        //YGJ_QCalc(OneMinSSIM1k, 9) + 104
        //YGJ_QCalc(OneMinSSIM1k, 12) + 464
        :OneMinSSIM1k < 100 ? 
        YGJ_QCalc(OneMinSSIM1k, 12) + 464
        :OneMinSSIM1k < 275 ? 
        (OneMinSSIM1k << 2) + (OneMinSSIM1k << 1)  + 848
    
    //:OneMinSSIM1k < 425 ?
    //YGJ_QCalc(OneMinSSIM1k, 3) + (OneMinSSIM1k >> 1) + 525
    :
    //YGJ_QCalc(OneMinSSIM1k, 6) - 550
    -1
    ;
            
    PSeudoSSIM += PSeudoSSIM > -1 && MeanDiff > 0? 
        //YGJ_QScale(MeanDiffx1SSIM, (16 - (OneMinSSIM1k >> 6)), 512) : 0;
        (YGJ_QScale(SSIMCoVar, 5, 512) + 2) * MeanDiff  + MeanDiff
        : 0; // -- This was for the 8x8 version

    // Now to add any Covariance related score
    PSeudoSSIM += PSeudoSSIM == -1 || SSIMCoVar == 0?   
        //((YGJ_QScale(SSIMCoVar, 13, 64) * OneMinSSIM1k) >> 7) + YGJ_QScale(SSIMCoVar, 13, 64)
        //(3-(OneMinSSIM1k >> 7)) * SSIMCoVar

        0       
        :OneMinSSIM1k < 10 ?     
        //YGJ_QCalc(OneMinSSIM1k, 9) + 104
        ((OneMinSSIM1k* SSIMCoVar) >> 7) + (SSIMCoVar >> 5)
        :OneMinSSIM1k < 15 ?     
        //YGJ_QCalc(OneMinSSIM1k, 9) + 104
        ((OneMinSSIM1k* SSIMCoVar) >> 7) + (SSIMCoVar >> 6)        
        //:OneMinSSIM1k < 20 ?     
        //YGJ_QCalc(OneMinSSIM1k, 9) + 104
        //((OneMinSSIM1k* SSIMCoVar) >> 8) + (SSIMCoVar >> 4)
        :OneMinSSIM1k < 50 ? 
        //YGJ_QCalc(OneMinSSIM1k, 9) + 104
        ((OneMinSSIM1k* SSIMCoVar) >> 8) + (SSIMCoVar >> 4)
        :OneMinSSIM1k < 100 ? 
        //(OneMinSSIM1k << 2) + 312    
        (YGJ_QCalc(SSIMCoVar, 5) >> 4) - ((OneMinSSIM1k* SSIMCoVar) >> 10) 
        :OneMinSSIM1k < 275 ? 
        //(OneMinSSIM1k << 2) + OneMinSSIM1k + 448
        ((OneMinSSIM1k* SSIMCoVar) >> 8) 

        //((OneMinSSIM1k * SSIMCoVar) >> 10)
        : 0;

    return PSeudoSSIM;

}


int YGJ_PseudoSSIM_Cv3014(int OneMinSSIM1k, int SSIMCoVar, int MeanDiff)
{
    int PSeudoSSIM = 0;
    //int MeanDiffx1SSIM = (OneMinSSIM1k*MeanDiff);

    //--------------------
    //// YGJ 26th Nov 2012 Covar = 0 (Cv+C2 = 58, looking at 1-SSIM < 0.2, distinct 1-SSIM values averaged out and then modelled.
    //PSeudoSSIM = OneMinSSIM1k < 5 ?
    //-1 // Use SATD instead 
    ////--------------------
    //:
    //YGJ_QCalc(OneMinSSIM1k, 5) + (OneMinSSIM1k >> 2)  + 725
    //;

    
    PSeudoSSIM = OneMinSSIM1k < 15 ?
    //:OneMinSSIM1k < 10 ?     
    //YGJ_QCalc(OneMinSSIM1k, 9) + 104
        YGJ_QCalc(OneMinSSIM1k, 44) + 272
        //:OneMinSSIM1k < 15 ?     
        //YGJ_QCalc(OneMinSSIM1k, 17) + 368
        :OneMinSSIM1k < 50 ?     
        YGJ_QCalc(OneMinSSIM1k, 20) + 512
        //:OneMinSSIM1k < 50 ? 
        //YGJ_QCalc(OneMinSSIM1k, 9) + 104
        //YGJ_QCalc(OneMinSSIM1k, 12) + 464
        :OneMinSSIM1k < 200 ? 
        YGJ_QCalc(OneMinSSIM1k, 10) + 952
        //:OneMinSSIM1k < 275 ? 
        //(OneMinSSIM1k << 2) + (OneMinSSIM1k << 1)  + 848
            :
    //YGJ_QCalc(OneMinSSIM1k, 6) - 550
    -1
    ;


    // Add Absolute Mean Difference related cost
    PSeudoSSIM += PSeudoSSIM > -1 && MeanDiff > 0? 
        //YGJ_QScale(MeanDiffx1SSIM, (16 - (OneMinSSIM1k >> 6)), 512): 0;
        //(0-(YGJ_QScale(SSIMCoVar, 5, 512) + 73 )*MeanDiff) : 0;
        //((YGJ_QScale(OneMinSSIM1k, 15, 128) + 6 )*MeanDiff) : 0;
        //((YGJ_QScale(((1000-OneMinSSIM1k) >> 1), 15, 128) + 6 )*MeanDiff) : 0;
        //((79-YGJ_QScale(SSIMCoVar, 5, 512) + YGJ_QScale(OneMinSSIM1k, 15, 128)) >> 1 )*MeanDiff : 0;
        //((YGJ_QScale(OneMinSSIM1k, 15, 128) + 6 )*MeanDiff) : 0;
        //(73 - YGJ_QScale((SSIMCoVar+3014), 5, 512) )*MeanDiff : 0;
        //(43 - YGJ_QScale(SSIMCoVar, 5, 512) )*MeanDiff : 0;
        //((YGJ_QScale((1000-OneMinSSIM1k), 5, 128) + 4 ) - YGJ_QScale(SSIMCoVar, 5, 512) )*MeanDiff : 0;
        //SSIMCoVar < 4500?
        (43 - YGJ_QScale(SSIMCoVar, 5, 512) )*MeanDiff + MeanDiff
        //: MeanDiff
        : 0;

    //// Now to add any Covariance related score
    PSeudoSSIM += PSeudoSSIM == -1 || SSIMCoVar == 0?
        //YGJ_QCalc(SSIMCoVar, 3)		
        //(((((0 - YGJ_QCalc(OneMinSSIM1k, 5)) >> 2) - 1) * (SSIMCoVar)) >> 8)
                    
        0       
        //:OneMinSSIM1k < 10 ?     
        //YGJ_QCalc(OneMinSSIM1k, 9) + 104
        //((OneMinSSIM1k* SSIMCoVar) >> 7) + (SSIMCoVar >> 5)
        :OneMinSSIM1k < 15 ?     
        //YGJ_QCalc(OneMinSSIM1k, 9) + 104
        ((OneMinSSIM1k* SSIMCoVar) >> 10) + (SSIMCoVar >> 7)        
        //:OneMinSSIM1k < 20 ?     
        //YGJ_QCalc(OneMinSSIM1k, 9) + 104
        //((OneMinSSIM1k* SSIMCoVar) >> 8) + (SSIMCoVar >> 4)
        :OneMinSSIM1k < 50 ? 
        //YGJ_QCalc(OneMinSSIM1k, 9) + 104
        ((OneMinSSIM1k* SSIMCoVar) >> 9) + (SSIMCoVar >> 6)
        :OneMinSSIM1k < 200 ? 
        //(OneMinSSIM1k << 2) + 312    
        ((OneMinSSIM1k* SSIMCoVar) >> 10) + (SSIMCoVar >> 4)
        //:OneMinSSIM1k < 275 ? 
        //(OneMinSSIM1k << 2) + OneMinSSIM1k + 448
        //((OneMinSSIM1k* SSIMCoVar) >> 8) 


		: 0;

    return PSeudoSSIM;

}


//int YGJ_GenCovZoneCalc(int OneMinSSIM1k, int Grad_num, int Grad_denum, int OffSet, int CoVarDelta, int GradDelta_num, int GradDelta_denum, int OffSetDelta_num, int OffSetDelta_denum, int MeanDiff )
//{
//    // Scaled Covar based 1-SSIM Gradient and Covar based Offset. Since 1-SSIM is actually 1-SSIM x 1k, it must be scaled down by 1k, hence right shift by 10 on the gradient.
//    int result =  YGJ_QScale(OneMinSSIM1k, Grad_num, Grad_denum) + OffSet 
//        + ((YGJ_QScale(CoVarDelta, GradDelta_num, GradDelta_denum) * OneMinSSIM1k) >> 10) 
//        + YGJ_QScale(CoVarDelta, OffSetDelta_num, OffSetDelta_denum);
//    
//    return result;
//}

/// !<  YGJ 30th Nov 2012 - A new simplified understanding and mini-model
/// !< Takes in the pre-calculated integer 1-SSIM x 1000, which will mean a three decimal accuracy of SSIM is now in integer form.
/// !< Also the Covariance is noted, it is expected to be Covariance + C2 where C2 for 8 bit video works out to be a constant of ~58.
/// !< Therefore each zone is subtracts C2 first.
/// !< The base zone is the most accurate model, since most samples were available.
/// !< Subsequent zones had fewer available samples and thus left as approximations
/// !< The fact that fewer samples where available is to down to the fact samples were taken where zero mean difference was measured between Original and Encoded blocks
/// !< This does not say they are absolutely identical but merely across the block in question they variations either cancel out or are minimum.
/// !< With SATD the variations in difference are accounted for while in SSIM they are amalgamated to as part of a relative difference.
/// !<  So, in order to keep in tune with the principles of SSIM, I've restricted myself to work with SSIM and the calculations to form it.
/// !< Overall this is to provide a Pseudo Distortion Metric based upon SSIM but also on the Covariance value associated with it and the Absolute Difference in Mean between the Original and Encoded blocks.
/// !< To keep the model simple only the base is accurately modelled by averaging sample values such that a coherent trend could be traced.
/// !<  For the other higher covariance differentiated 'zones', the lack of samples meant that a line of best fit would be only be available and thus this was noted.
/// !< Plotting the trend lines seemed to reflect what was occurring, suggesting the choice to limit by zero mean difference was wise.
/// !< The earlier zones have low changes in gradients, < 1. The middle and its adjacent zones share the same gradient but different offset, mimicking the static middle core observed in earlier data gathering modelling attempts.
/// !< The higher covariance zones have changes in gradient of less than 1 between them, including large ranges of covariance, suggesting more tightly packed samples as again illustrated in the graphs of earlier work.
/// !< The linear equations were made to be integer/processer friendly where possible. 
/// !< To allow for the movement between zones to be more gradual, a rate of change based upon the Covariance needed to be determined.
/// !<  These rates of change are based upon the relative covariance change within the zone it falls within, allowing for the sample to have some distinction for similar rated blocks in question.
/// !<  Similarly the purpose of Abs-Diff of Means to factor in that into the result and add a another level of dimensionality, favouring those which exhibit relative close values than those with large differences.
int YGJ_PseudoSSIM_Zones_8x8(int OneMinSSIM1k, int SSIMCoVar, int MeanDiff)
{
    int PSeudoSSIMValue = -1; //if -1 use SATD
    
    PSeudoSSIMValue = SSIMCoVar < 150? // Base
        YGJ_PseudoSSIM_Base(OneMinSSIM1k, SSIMCoVar, MeanDiff)
        : SSIMCoVar < 300? // Zone 150
        YGJ_PseudoSSIM_Cv150(OneMinSSIM1k, (SSIMCoVar-150), MeanDiff)
        : SSIMCoVar < 600? // Zone 300
        YGJ_PseudoSSIM_Cv300(OneMinSSIM1k, (SSIMCoVar-300), MeanDiff)
        : SSIMCoVar < 1350? // Zone 600
        YGJ_PseudoSSIM_Cv600(OneMinSSIM1k, (SSIMCoVar-600), MeanDiff)
        : SSIMCoVar < 3014? // Zone 1350
        YGJ_PseudoSSIM_Cv1350(OneMinSSIM1k, (SSIMCoVar-1350), MeanDiff)
        : SSIMCoVar < 8000? // Zone 3014
        YGJ_PseudoSSIM_Cv3014(OneMinSSIM1k, (SSIMCoVar-3014), MeanDiff)
        : -1;    

    return PSeudoSSIMValue;
}

int YGJ_PSeudoSSIM_8x8(int OneMinSSIM1k, int Covar, int AbsMeanDiff)
{
	//int PSeudoSSIMValue = -1;
	//int SSIMCoVar = Get_YGJ_SSIMCoVar(); // Assumes always positive
	//int MeanDiff = Get_AbsDiffMean();

	//// Check to ensure to use PseudoSSIM model only when OneMinSSIM1k is less than or equal to 1000,
	//// (when SSIM is >= 0, 1-SSIM is <=1) and that Covariance is positive.

 //   PSeudoSSIMValue = !(OneMinSSIM1k < 1000)|| SSIMCoVar < 0 ? -1 
 //       :  YGJ_PseudoSSIM_Zones(OneMinSSIM1k, SSIMCoVar, MeanDiff);

 //   return PSeudoSSIMValue;

     // YGJ 13th March 2013 - Conditional and passing of values.
    return( !(OneMinSSIM1k < 1000) || Covar < 0 || Covar > 8000 ? -1 
        :  YGJ_PseudoSSIM_Zones_8x8(OneMinSSIM1k, Covar, AbsMeanDiff));

}

//! <  Now for PSeudoSSIM_4x4
//! <  Here coverage as a percentage of samples with the use of SSIM bands is less ~ 87% verse ~95% achieved with 8x8 but the volume of samples is far greater, 80k out of 91k. However the SSIM value and SATD correlation with smaller block sizes is far less. 
//! < The effective number of samples that were already with in the PSeudo bands is lower, resulting in approximately 11, 13 and 15 % (QP 20, 28 and 36) out of all samples. 
//! <  There need to have SSIM Bands going down to 0.34 is to ensure suitable coverage of possible samples, more precisely it was the illustrated in the Accumulated frequency graph that at 0.34 towards lower values of SSIM the there was dramatic drop in number of samples covered. 
//! < Analysis to create the PSeudo ranges was more diffificult than in 8x8 and the values have been chosen to with the intension to offer some level of coverage relative to SATD at every SSIM Band.
//! < Whilst PseudoSSIM_8x8 was reliant initially on the (inter) quartile figures, this was foregone due to the spread was wide in the larger bands that needed to be covered and the fact overall the score required it to be low.
//! <  As a result a live/updated summary of coverage was primary used, where values were adjusted to find suitable coverage alongside adjacent bands.
//! <  Below is the proposed PSeudo SSIM bands and linear equations to be used. In order to reduce the complexity/magnitude of the gradient, this will be reduced by a factor of 1000, whilst SSIM will be multiplied by a 1000 and converted to an integer so bit-shift multiplication can occur.


// Note Grad is in Hundreds, it will be divided by 100 and SSIM will be multiplied by 100

// Chooses the appropriate function for SSIM band 4x4 based upon the SSIM times 1000 value
// YGJ 24th Aug - Correction it is 1-SSIM and SSIM x 100 (hundred), not a thousand.
// With 1-SSIM it keeps the gradients as positive numbers, making it easier to understand when reading and calculating.
// For times one hundred for SSIM is so that the gradient values are a bit easier to represent in terms of bit shifts.

// For Where Covar is equal to 0
int YGJ_PseudoSSIM_Base_4x4(int OneMinSSIM1k, int SSIMCoVar, int MeanDiff)
{
    int PSeudoSSIM = -1;

    //--------------------
    // YGJ 26th Nov 2012 Covar = 0 (Cv+C2 = 58, looking at 1-SSIM < 0.2, distinct 1-SSIM values averaged out and then modelled.
    PSeudoSSIM = OneMinSSIM1k < 2 ?
    -1 // Use SATD instead     
    :OneMinSSIM1k < 10 ?
    OneMinSSIM1k + (OneMinSSIM1k >> 3) + 8
    :OneMinSSIM1k < 20 ?
    OneMinSSIM1k - (OneMinSSIM1k >> 2) + 12
    :OneMinSSIM1k < 50 ?
    YGJ_QScale(OneMinSSIM1k, 5, 8) + 14
    //:OneMinSSIM1k < 100 ?
    //(OneMinSSIM1k >> 2) + 30
    :OneMinSSIM1k < 600 ?
    (OneMinSSIM1k >> 2) + 32        
    :OneMinSSIM1k < 800 ?
    OneMinSSIM1k - (OneMinSSIM1k >> 2) -300        
    :OneMinSSIM1k < 900 ?
    (OneMinSSIM1k << 1 ) + (OneMinSSIM1k >> 1) - 1688
    //:OneMinSSIM1k < 1000 ?
    //(OneMinSSIM1k << 2 ) + OneMinSSIM1k - (OneMinSSIM1k >> 2) - 3700   
    :
    -1 //(OneMinSSIM1k << 3) - 7000
    ;

    //// Add Absolute Mean Difference related cost
    //PSeudoSSIM += PSeudoSSIM > -1 && MeanDiff > 0? 
    //    //YGJ_QCalc(MeanDiff, 11)	
    //    // YGJ 22nd Dec 2012
    //    // mu_Diff (Abs Mean  Diff) is a product of Covariance. y= 11-CV/64
    //    YGJ_QCalc(MeanDiff, (11 - (SSIMCoVar >> 6)))	
    //    : 0;
            
    //// Add Absolute Mean Difference related cost
    PSeudoSSIM += PSeudoSSIM > -1 && MeanDiff > 0? 
    //    YGJ_QScale(MeanDiffx1SSIM, (16 - (OneMinSSIM1k >> 6)), 512) : 0;
        (MeanDiff << 3) : 0;

    // Now to add any Covariance related score
    PSeudoSSIM += PSeudoSSIM == -1 || SSIMCoVar == 0? 
        //(((YGJ_QScale(OneMinSSIM1k, 7, 1024) + 1) * SSIMCoVar) >> 1) //+ YGJ_QScale(SSIMCoVar, 5, 256)
        //((((OneMinSSIM1k * SSIMCoVar) >> 7) - SSIMCoVar) >> 1)
        0

        :OneMinSSIM1k < 10 ?
        //OneMinSSIM1k + (OneMinSSIM1k >> 3) + 9
        ((OneMinSSIM1k * SSIMCoVar) >> 6) +  (SSIMCoVar >> 5)
        :OneMinSSIM1k < 20 ?
        //OneMinSSIM1k - (OneMinSSIM1k >> 2) + 11
        ((OneMinSSIM1k * SSIMCoVar) >> 7) +  (SSIMCoVar >> 3)        
        :OneMinSSIM1k < 50 ?
        ((OneMinSSIM1k * SSIMCoVar) >> 8) +  (SSIMCoVar >> 2) - (SSIMCoVar >> 4)  //+ YGJ_QScale(SSIMCoVar, 3, 16)
        :OneMinSSIM1k < 100 ?
        //(OneMinSSIM1k >> 2) + 30
        ((OneMinSSIM1k * SSIMCoVar) >> 8) +  (SSIMCoVar >> 2)        
        :OneMinSSIM1k < 200 ?
        //(OneMinSSIM1k >> 2) + 30
        ((YGJ_QCalc(OneMinSSIM1k, 3) * SSIMCoVar) >> 10) +  (SSIMCoVar >> 2) + (SSIMCoVar >> 4)  //+  YGJ_QScale(SSIMCoVar, 5, 16)
        :OneMinSSIM1k < 600 ?
        ((OneMinSSIM1k * SSIMCoVar) >> 9) +  (SSIMCoVar >> 1)        
        //(OneMinSSIM1k >> 2) + 32        
        :OneMinSSIM1k < 800 ?
        //OneMinSSIM1k - (OneMinSSIM1k >> 2) -272        
        ((OneMinSSIM1k * SSIMCoVar) >> 8) -  (SSIMCoVar >> 1)        
        :OneMinSSIM1k < 900 ?
        //(OneMinSSIM1k << 1 ) - (OneMinSSIM1k >> 1) - 1688
        ((OneMinSSIM1k * SSIMCoVar) >> 6) -  YGJ_QCalc(SSIMCoVar, 10)      

        : 0;
            

    return PSeudoSSIM;

}

int YGJ_PseudoSSIM_Cv150_4x4(int OneMinSSIM1k, int SSIMCoVar, int MeanDiff)
{
    int PSeudoSSIM = 0;
    //int MeanDiffx1SSIM = (OneMinSSIM1k*MeanDiff);

    //--------------------
    // YGJ 26th Nov 2012 Covar = 0 (Cv+C2 = 58, looking at 1-SSIM < 0.2, distinct 1-SSIM values averaged out and then modelled.
    PSeudoSSIM = OneMinSSIM1k < 3 ?
    -1 // Use SATD instead 
    //--------------------
    //:OneMinSSIM1k < 80 ? 
    //(OneMinSSIM1k << 2) - (OneMinSSIM1k >> 1) + 125
    //:OneMinSSIM1k < 110 ? 
    //OneMinSSIM1k + YGJ_QScale(OneMinSSIM1k, 13, 32)  + 218
    //:OneMinSSIM1k < 130 ? 
    //OneMinSSIM1k + YGJ_QScale(OneMinSSIM1k, 13, 32)  + 383
    //:OneMinSSIM1k < 650 ?
    //OneMinSSIM1k + YGJ_QScale(OneMinSSIM1k, 51, 64) + 150
    //:OneMinSSIM1k < 875 ?    
    //YGJ_QCalc(OneMinSSIM1k, 6) +  (OneMinSSIM1k >> 2) - 2850
    //:
    //(OneMinSSIM1k << 1) - (OneMinSSIM1k >> 1) -  (OneMinSSIM1k >> 2) - 10500
    //;
     
       
    :OneMinSSIM1k < 10 ?
    //YGJ_QScale(OneMinSSIM1k, 29, 8) + 12
    (OneMinSSIM1k << 2) + OneMinSSIM1k + (OneMinSSIM1k >> 1) + (OneMinSSIM1k >> 3) + 12
    :OneMinSSIM1k < 20 ?
    (OneMinSSIM1k << 1 ) - (OneMinSSIM1k >> 4) + 28
    :OneMinSSIM1k < 50 ?
    OneMinSSIM1k + (OneMinSSIM1k >> 2) + 42
    :OneMinSSIM1k < 100 ?
    OneMinSSIM1k - (OneMinSSIM1k >> 4) + 60    
    :OneMinSSIM1k < 200 ?
    YGJ_QScale(OneMinSSIM1k, 11, 16) + 80
    :OneMinSSIM1k < 600 ?
    YGJ_QScale(OneMinSSIM1k, 5, 8) + 88        
    :OneMinSSIM1k < 800 ?
    OneMinSSIM1k - 142

    //:OneMinSSIM1k < 55 ?
    //OneMinSSIM1k + 15 //+ MeanDiff
    //:OneMinSSIM1k < 400 ?
    //YGJ_QScale(OneMinSSIM1k, 3, 8) + 50 //+ MeanDiff
    :
    //OneMinSSIM1k - 200 //+ MeanDiff
    -1
    ;
    
    // Add Absolute Mean Difference related cost
    //PSeudoSSIM += PSeudoSSIM > -1 && MeanDiff > 0? 
    //    YGJ_QScale(MeanDiffx1SSIM, (16 - (OneMinSSIM1k >> 6)), 256): 0;

    //    // Add Absolute Mean Difference related cost
    //PSeudoSSIM += PSeudoSSIM > -1 && MeanDiff > 0? 
    //    // YGJ 22nd Dec 2012
    //    //YGJ_QCalc(MeanDiff, 9) - (MeanDiff >> 2)         
    //    // mu_Diff (Abs Mean  Diff) is a product of Covariance. y= 11-CV/64
    //    YGJ_QCalc(MeanDiff, (11 - ((150+SSIMCoVar) >> 6)))	
    //    : 0;

        
    //// Add Absolute Mean Difference related cost
    PSeudoSSIM += PSeudoSSIM > -1 && MeanDiff > 0? 
    //    YGJ_QScale(MeanDiffx1SSIM, (16 - (OneMinSSIM1k >> 6)), 512) : 0;
        (MeanDiff << 3) : 0;

    // Now to add any Covariance related score
    PSeudoSSIM += PSeudoSSIM == -1 || SSIMCoVar == 0?
        // Scaled Covar based 1-SSIM Gradient and Covar based Offset. Since 1-SSIM is actually 1-SSIM x 1k, it must be scaled down by 1k, hence right shift by 10 on the gradient.
        //((YGJ_QScale(SSIMCoVar, 9, 16) * OneMinSSIM1k) >> 7) + YGJ_QScale(SSIMCoVar, 9, 16)
        //((SSIMCoVar * OneMinSSIM1k ) >> 8) +  (SSIMCoVar >> 2)
        //((YGJ_QScale(SSIMCoVar, 25, 16) * OneMinSSIM1k) >> 8) +  (YGJ_QScale(SSIMCoVar, 25, 16) >> 2)
        //((YGJ_QScale(SSIMCoVar, 3, 2) * OneMinSSIM1k) >> 8) +  (YGJ_QScale(SSIMCoVar, 3, 2) >> 2)
        //((((OneMinSSIM1k >> 9) + 1) * SSIMCoVar) >> 1)
        //(((YGJ_QCalc((OneMinSSIM1k * SSIMCoVar), 3) >>6) + YGJ_QCalc(SSIMCoVar, 3)) >> 5)
        0

        //:OneMinSSIM1k < 10 ?
        //((OneMinSSIM1k * SSIMCoVar )>> 8) + (SSIMCoVar >> 4)
        //:OneMinSSIM1k < 20 ?
        //OneMinSSIM1k + ((OneMinSSIM1k * SSIMCoVar )>> 8) + 28
        //((OneMinSSIM1k * SSIMCoVar )>> 8) + (SSIMCoVar >> 4
        :OneMinSSIM1k < 50 ?
        //OneMinSSIM1k + (OneMinSSIM1k >> 2) + 42
        ((OneMinSSIM1k * SSIMCoVar )>> 8) + (SSIMCoVar >> 4)
        //:OneMinSSIM1k < 100 ?
        //OneMinSSIM1k - (OneMinSSIM1k >> 4) + 60    
        //:OneMinSSIM1k < 200 ?
        //YGJ_QScale(OneMinSSIM1k, 11, 16) + 80
        //:OneMinSSIM1k < 600 ?
        //YGJ_QScale(OneMinSSIM1k, 5, 8) + 88        
        :OneMinSSIM1k < 800 ?
        //OneMinSSIM1k - 142
        ((OneMinSSIM1k * SSIMCoVar) >> 9) + (SSIMCoVar >> 3)

        : 0;
           
    //Temp will need to lift this band aid as and when the 4x4 version is tailor made.
    //PSeudoSSIM  = (PSeudoSSIM >> 2);

    return PSeudoSSIM;

}

int YGJ_PseudoSSIM_Cv300_4x4(int OneMinSSIM1k, int SSIMCoVar, int MeanDiff)
{
    int PSeudoSSIM = 0;
    //int MeanDiffx1SSIM = (OneMinSSIM1k*MeanDiff);

    //--------------------
    // YGJ 26th Nov 2012 Covar = 0 (Cv+C2 = 58, looking at 1-SSIM < 0.2, distinct 1-SSIM values averaged out and then modelled.
    PSeudoSSIM = //OneMinSSIM1k < 2 ?
    //-1 // Use SATD instead 
    //--------------------        
    //YGJ_QScale(OneMinSSIM1k, 29, 8) + 32       
    //:
    OneMinSSIM1k < 10 ?
    //YGJ_QScale(OneMinSSIM1k, 29, 8) + 12
    //YGJ_QScale(OneMinSSIM1k, 29, 8) + 32
    (OneMinSSIM1k << 2) + OneMinSSIM1k + (OneMinSSIM1k >> 1) + (OneMinSSIM1k >> 3) + 32
    :OneMinSSIM1k < 20 ?
    (OneMinSSIM1k << 1) + (OneMinSSIM1k >> 1) + 40
    :OneMinSSIM1k < 50 ?
    (OneMinSSIM1k << 1) - (OneMinSSIM1k >> 2) + 56
    :OneMinSSIM1k < 100 ?
    OneMinSSIM1k + (OneMinSSIM1k >> 3) + 86    
    :OneMinSSIM1k < 200 ?
    OneMinSSIM1k - (OneMinSSIM1k >> 4) + 102
    :OneMinSSIM1k < 600 ?
    OneMinSSIM1k - (OneMinSSIM1k >> 3) + 108       
    :OneMinSSIM1k < 800 ?
    OneMinSSIM1k + (OneMinSSIM1k >> 2) - 120

    //:OneMinSSIM1k < 60 ?
    //OneMinSSIM1k + (OneMinSSIM1k >> 1) + 25 + MeanDiff
    //:OneMinSSIM1k < 480 ?
    //(OneMinSSIM1k >> 1) + 85 + MeanDiff
    :
    //OneMinSSIM1k + (OneMinSSIM1k >> 2) - 275 + MeanDiff
    -1
    ;

    // Add Absolute Mean Difference related cost
    PSeudoSSIM += PSeudoSSIM > -1 && MeanDiff > 0? 
    //    YGJ_QScale(MeanDiffx1SSIM, (16 - (OneMinSSIM1k >> 6)), 256)
        // YGJ 22nd Dec 2012
        //YGJ_QCalc(MeanDiff, 9) - (MeanDiff >> 2)         
        // mu_Diff (Abs Mean  Diff) is a product of Covariance. y= 11-CV/64
        //YGJ_QCalc(MeanDiff, (11 - ((300+SSIMCoVar) >> 6)))	    
        //YGJ_QCalc(MeanDiff, 40)	    
        //YGJ_QCalc(MeanDiff, 6) + (MeanDiff >> 1)
        (MeanDiff << 3)
        : 0;

    // Now to add any Covariance related score
    PSeudoSSIM += PSeudoSSIM == -1 || SSIMCoVar == 0?
        // Scaled Covar based 1-SSIM Gradient and Covar based Offset. Since 1-SSIM is actually 1-SSIM x 1k, it must be scaled down by 1k, hence right shift by 10 on the gradient.
        //((YGJ_QScale(SSIMCoVar, 5, 8) * OneMinSSIM1k) >> 7) + YGJ_QScale(SSIMCoVar, 5, 8)
        //((YGJ_QScale(SSIMCoVar, 13, 16) * OneMinSSIM1k) >> 9) +  (YGJ_QScale(SSIMCoVar, 13, 16) >> 3)
        //((SSIMCoVar * OneMinSSIM1k ) >> 8) +  (SSIMCoVar >> 2)
        //(((YGJ_QScale(OneMinSSIM1k, 3, 2048) + 1) * SSIMCoVar) >> 1)

        0
        :OneMinSSIM1k < 2 ?
        ((OneMinSSIM1k * SSIMCoVar) >> 8) + (SSIMCoVar >> 6)              
        //:OneMinSSIM1k < 10 ?
        //((OneMinSSIM1k * SSIMCoVar) >> 8) + (SSIMCoVar >> 6)
        :OneMinSSIM1k < 20 ?
        ((OneMinSSIM1k * SSIMCoVar) >> 8) + (SSIMCoVar >> 5)
        :OneMinSSIM1k < 50 ?
        ((OneMinSSIM1k * SSIMCoVar) >> 10) + (SSIMCoVar >> 5)
        :OneMinSSIM1k < 100 ?
        ((OneMinSSIM1k * SSIMCoVar) >> 10) + (SSIMCoVar >> 3)
        :OneMinSSIM1k < 200 ?
        ((OneMinSSIM1k * SSIMCoVar) >> 11) +  (SSIMCoVar >> 2) - (SSIMCoVar >> 4)  //+ YGJ_QScale(SSIMCoVar, 3, 16)
        :OneMinSSIM1k < 600 ?
        ((OneMinSSIM1k * SSIMCoVar) >> 10) +  (SSIMCoVar >> 3) - (SSIMCoVar >> 5)  //+ YGJ_QScale(SSIMCoVar, 3, 32)
        :OneMinSSIM1k < 800 ?
        ((OneMinSSIM1k * SSIMCoVar) >> 7) - (SSIMCoVar >> 2)

        : 0;
            
    //Temp will need to lift this band aid as and when the 4x4 version is tailor made.
    //PSeudoSSIM  = (PSeudoSSIM >> 2);

    return PSeudoSSIM;

}

int YGJ_PseudoSSIM_Cv600_4x4(int OneMinSSIM1k, int SSIMCoVar, int MeanDiff)
{
    int PSeudoSSIM = 0;
    //int MeanDiffx1SSIM = (OneMinSSIM1k*MeanDiff);

    //--------------------
    // YGJ 26th Nov 2012 Covar = 0 (Cv+C2 = 58, looking at 1-SSIM < 0.2, distinct 1-SSIM values averaged out and then modelled.
    PSeudoSSIM = //OneMinSSIM1k < 5 ?
    //-1 // Use SATD instead 
    ////--------------------        
    //:OneMinSSIM1k < 100 ?
    //OneMinSSIM1k + (OneMinSSIM1k >> 1) + 50 + MeanDiff
    //:OneMinSSIM1k < 200 ?
    //(OneMinSSIM1k >> 1)  + 150 + MeanDiff
            
    OneMinSSIM1k < 10 ?
    //YGJ_QScale(OneMinSSIM1k, 29, 8) + 12
    (OneMinSSIM1k << 2) + OneMinSSIM1k + (OneMinSSIM1k >> 1) - (OneMinSSIM1k >> 3) + 36
    :OneMinSSIM1k < 20 ?
    (OneMinSSIM1k << 2) - (OneMinSSIM1k >> 1) - (OneMinSSIM1k >> 3) + 56
    :OneMinSSIM1k < 50 ?
    (OneMinSSIM1k << 1) + (OneMinSSIM1k >> 2) + 80
    :OneMinSSIM1k < 100 ?
    //YGJ_QScale(OneMinSSIM1k, 11, 8) + 124    
    OneMinSSIM1k + (OneMinSSIM1k >> 1) - (OneMinSSIM1k >> 3) + 124
    :OneMinSSIM1k < 200 ?
    OneMinSSIM1k + (OneMinSSIM1k >> 3) + 160
    :OneMinSSIM1k < 600 ?
    OneMinSSIM1k + (OneMinSSIM1k >> 4) + 160       
    //:OneMinSSIM1k < 800 ?
    //OneMinSSIM1k + (OneMinSSIM1k >> 2) - 120

    :
    //OneMinSSIM1k  + 50 + MeanDiff
    -1
    ;
    
    //// Add Absolute Mean Difference related cost
    // PSeudoSSIM += PSeudoSSIM > -1 && MeanDiff > 0? 
    //     //YGJ_QScale(MeanDiffx1SSIM, (16 - (OneMinSSIM1k >> 6)), 512)                 
    //     // YGJ 22nd Dec 2012
    //    //YGJ_QCalc(MeanDiff, 9) - (MeanDiff >> 2)         
    //    // mu_Diff (Abs Mean  Diff) is a product of Covariance. y= 11-CV/64
    //    // Note For Covar>704 , the formula goes negative, therefore, simply add MeanDiff value to score. (704-600 = 104)
    //    SSIMCoVar < 104?
    //        YGJ_QCalc(MeanDiff, (11 - ((600+SSIMCoVar) >> 6)))	    
    //        : YGJ_QCalc(MeanDiff, (((YGJ_QCalc((SSIMCoVar), 3)) >> 8)))	 
    //        // After which it is (CV*3/256  - 8)  * MeanDiff. Starts at 1 at 704 and works its way to  8  by 1349. In the band it is fixed at 8.
    //    : 0;
        
    //// Add Absolute Mean Difference related cost
    PSeudoSSIM += PSeudoSSIM > -1 && MeanDiff > 0? 
    //    YGJ_QScale(MeanDiffx1SSIM, (16 - (OneMinSSIM1k >> 6)), 512) : 0;
       (MeanDiff << 3) : 0;
       //(YGJ_QScale(SSIMCoVar, 3, 512) + 16) * MeanDiff: 0; // -- This was for the 8x8 version



    // Now to add any Covariance related score
    //PSeudoSSIM += PSeudoSSIM > -1 && SSIMCoVar > 0?
    PSeudoSSIM += PSeudoSSIM == -1 || SSIMCoVar == 0?
        0
        :
        //((YGJ_QScale(SSIMCoVar, 13, 16) * OneMinSSIM1k) >> 10) + 
        //((YGJ_QScale(SSIMCoVar, 11, 16) * OneMinSSIM1k) >> 10) + YGJ_QScale(SSIMCoVar, 13, 256)    
        //((YGJ_QScale(SSIMCoVar, 13, 16) * OneMinSSIM1k) >> 9) +  (YGJ_QScale(SSIMCoVar, 13, 16) >> 3)
        //((YGJ_QScale(SSIMCoVar, 11, 16) * OneMinSSIM1k) >> 10) +  (YGJ_QScale(SSIMCoVar, 11, 16) >> 3)
                
        //(((YGJ_QScale(OneMinSSIM1k, 3, 2048) + 1) * SSIMCoVar) >> 1)    
        //((YGJ_QScale(SSIMCoVar, 11, 16) * OneMinSSIM1k) >> 8) + YGJ_QScale((SSIMCoVar+600), 13, 64)        
        //(YGJ_QScale(OneMinSSIM1k, 11, 128) * SSIMCoVar) + YGJ_QScale((SSIMCoVar+600), 13, 64)        
        //(YGJ_QScale(OneMinSSIM1k, 5, 128) + 1) * SSIMCoVar        
        //((YGJ_QScale(SSIMCoVar, 11, 16) * OneMinSSIM1k) >> 10) + YGJ_QScale(SSIMCoVar, 13, 256)    
        //((YGJ_QScale(SSIMCoVar, 11, 16) * OneMinSSIM1k) >> 9) + YGJ_QScale(SSIMCoVar, 13, 128)    
        //((YGJ_QScale(SSIMCoVar, 11, 16) * OneMinSSIM1k) >> 10) + YGJ_QScale(SSIMCoVar, 11, 256)    
        //(16 - YGJ_QScale(OneMinSSIM1k, 15, 1024)) * SSIMCoVar // -- This was for the 8x8 version
        
        OneMinSSIM1k < 2 ?
        ((OneMinSSIM1k * SSIMCoVar) >> 6) + (SSIMCoVar >> 8)               

        :OneMinSSIM1k < 10 ?
        //YGJ_QScale(OneMinSSIM1k, 29, 8) + 12
        ((OneMinSSIM1k * SSIMCoVar) >> 8) +  (SSIMCoVar >> 5) - (SSIMCoVar >> 7) //+ YGJ_QScale(SSIMCoVar, 3, 128)
        :OneMinSSIM1k < 20 ?
        ((OneMinSSIM1k * SSIMCoVar) >> 9) +  (SSIMCoVar >> 5) + (SSIMCoVar >> 7) //+ YGJ_QScale(SSIMCoVar, 5, 128)
        :OneMinSSIM1k < 50 ?
        ((OneMinSSIM1k * SSIMCoVar) >> 10) + (SSIMCoVar >> 4)               
        :OneMinSSIM1k < 100 ?
        //YGJ_QScale(OneMinSSIM1k, 11, 8) + 124    
        ((OneMinSSIM1k * SSIMCoVar) >> 10) +  (SSIMCoVar >> 4) - (SSIMCoVar >> 6)  //+ YGJ_QScale(SSIMCoVar, 3, 64)
        //:OneMinSSIM1k < 200 ?
        //OneMinSSIM1k + (OneMinSSIM1k >> 3) + 160
        :OneMinSSIM1k < 600 ?
        ((OneMinSSIM1k * SSIMCoVar) >> 11) +  (SSIMCoVar >> 3) - (SSIMCoVar >> 5)  //+ YGJ_QScale(SSIMCoVar, 3, 32)
        :  0 ;

    return PSeudoSSIM;

}

int YGJ_PseudoSSIM_Cv1350_4x4(int OneMinSSIM1k, int SSIMCoVar, int MeanDiff)
{
    int PSeudoSSIM = 0;
    //int MeanDiffx1SSIM = (OneMinSSIM1k*MeanDiff);

    //--------------------
    // YGJ 26th Nov 2012 Covar = 0 (Cv+C2 = 58, looking at 1-SSIM < 0.2, distinct 1-SSIM values averaged out and then modelled.
    PSeudoSSIM = //OneMinSSIM1k < 3 ?   
    //-1 // Use SATD instead 
    //--------------------        
    //:OneMinSSIM1k < 42 ?
    //:OneMinSSIM1k < 45 ?
    //(OneMinSSIM1k << 2) + 25 //+ MeanDiff
        
    //:OneMinSSIM1k < 130 ?
    //OneMinSSIM1k + 150 + MeanDiff

       
    OneMinSSIM1k < 10 ?
    //YGJ_QScale(OneMinSSIM1k, 29, 8) + 12
    (OneMinSSIM1k << 3) + (OneMinSSIM1k >> 1)  + 48
    :OneMinSSIM1k < 20 ?
    (OneMinSSIM1k << 2) + OneMinSSIM1k - (OneMinSSIM1k >> 2) + 84
    :OneMinSSIM1k < 50 ?
    (OneMinSSIM1k << 1) + OneMinSSIM1k + 120
    :OneMinSSIM1k < 100 ?
    //YGJ_QScale(OneMinSSIM1k, 11, 8) + 124    
    (OneMinSSIM1k << 1) - (OneMinSSIM1k >> 3) + 176
    :OneMinSSIM1k < 200 ?
    OneMinSSIM1k + (OneMinSSIM1k >> 1) + 216
    :OneMinSSIM1k < 250 ?
    OneMinSSIM1k + (OneMinSSIM1k >> 2) + 284

    :
    //(OneMinSSIM1k << 1) - (OneMinSSIM1k >> 2)  + 50 + MeanDiff
    //OneMinSSIM1k + (OneMinSSIM1k >> 2)  + 150 // + MeanDiff    
    -1
    ;
            
    //// Add Absolute Mean Difference related cost
    PSeudoSSIM += PSeudoSSIM > -1 && MeanDiff > 0? 
    //    YGJ_QScale(MeanDiffx1SSIM, (16 - (OneMinSSIM1k >> 6)), 512) : 0;
        (MeanDiff << 3) : 0;
        //(YGJ_QScale(SSIMCoVar, 5, 512) + 2) * MeanDiff: 0; // -- This was for the 8x8 version

    // Now to add any Covariance related score
    PSeudoSSIM += PSeudoSSIM == -1 || SSIMCoVar == 0?
        //((YGJ_QScale(SSIMCoVar, 13, 64) * OneMinSSIM1k) >> 7) + YGJ_QScale(SSIMCoVar, 13, 64)
        //((YGJ_QScale(SSIMCoVar, 83, 128)) >> 10) * OneMinSSIM1k +  (YGJ_QScale(SSIMCoVar, 83, 128) >> 3)
        //((YGJ_QScale(SSIMCoVar, 27, 64)) >> 10) * OneMinSSIM1k +  (YGJ_QScale(SSIMCoVar, 27, 64) >> 3)
        //((YGJ_QScale(SSIMCoVar, 83, 128) * OneMinSSIM1k) >> 10) +  (YGJ_QScale(SSIMCoVar, 83, 128) >> 3)
        //OneMinSSIM1k < 45 ?
        //((YGJ_QScale(SSIMCoVar, 5, 8) * OneMinSSIM1k) >> 10) +  (YGJ_QScale(SSIMCoVar, 5, 8) >> 4)
        //:
        //((YGJ_QScale(SSIMCoVar, 5, 8) * OneMinSSIM1k) >> 10) +  (YGJ_QScale(SSIMCoVar, 5, 8) >> 3)
        //YGJ_QScale(SSIMCoVar, 3, 32)
        //((YGJ_QScale(SSIMCoVar, 8, 16) * OneMinSSIM1k) >> 10) + YGJ_QScale(SSIMCoVar, 3, 32)
        //(((SSIMCoVar >> 1) * OneMinSSIM1k) >> 10) + YGJ_QScale(SSIMCoVar, 3, 32)
        //(3-(OneMinSSIM1k >> 7)) * SSIMCoVar // -- This was for the 8x8 version
        0:               
        OneMinSSIM1k < 2 ?
        (OneMinSSIM1k * (YGJ_QCalc(SSIMCoVar, 3)) >> 8) - (SSIMCoVar >> 6)               
        :OneMinSSIM1k < 10 ?
        //YGJ_QScale(OneMinSSIM1k, 29, 8) + 12
        //(OneMinSSIM1k << 3) + (OneMinSSIM1k >> 1)  + 48
        ((OneMinSSIM1k * SSIMCoVar) >> 9) + (SSIMCoVar >> 6)               
        :OneMinSSIM1k < 20 ?
        ((OneMinSSIM1k * SSIMCoVar) >> 10) +  (SSIMCoVar >> 5) - (SSIMCoVar >> 8)  //YGJ_QScale(SSIMCoVar, 7, 256)
        //(OneMinSSIM1k << 2) + OneMinSSIM1k - (OneMinSSIM1k >> 2) + 84
        :OneMinSSIM1k < 50 ?
        ((OneMinSSIM1k * SSIMCoVar) >> 10) + (SSIMCoVar >> 5)               
        //(OneMinSSIM1k << 1) + OneMinSSIM1k + 120
        :OneMinSSIM1k < 100 ?
        ((OneMinSSIM1k * SSIMCoVar) >> 10) +  (SSIMCoVar >> 5) - (SSIMCoVar >> 7) //+ YGJ_QScale(SSIMCoVar, 3, 128)
        //YGJ_QScale(OneMinSSIM1k, 11, 8) + 124    
        //(OneMinSSIM1k << 1) - (OneMinSSIM1k >> 3) + 176
        :OneMinSSIM1k < 200 ?
        //OneMinSSIM1k + (OneMinSSIM1k >> 1) + 216
        ((OneMinSSIM1k * (SSIMCoVar >> 3)) >> 11) +  (SSIMCoVar >> 3) - (SSIMCoVar >> 6)  //+ YGJ_QScale(SSIMCoVar, 7, 64)
        :OneMinSSIM1k < 250 ?
        //OneMinSSIM1k + (OneMinSSIM1k >> 2) + 284
        ((OneMinSSIM1k * (SSIMCoVar >> 3)) >> 11) +  (SSIMCoVar >> 3) - (SSIMCoVar >> 5)  //+ YGJ_QScale(SSIMCoVar, 3, 32)


        : 0;

    //Temp will need to lift this band aid as and when the 4x4 version is tailor made.
    //PSeudoSSIM  = (PSeudoSSIM >> 2);

    return PSeudoSSIM;

}

int YGJ_PseudoSSIM_Cv3014_4x4(int OneMinSSIM1k, int SSIMCoVar, int MeanDiff)
{
    int PSeudoSSIM = -1;
    //int MeanDiffx1SSIM = (OneMinSSIM1k*MeanDiff);

    //--------------------
    // YGJ 26th Nov 2012 Covar = 0 (Cv+C2 = 58, looking at 1-SSIM < 0.2, distinct 1-SSIM values averaged out and then modelled.
    PSeudoSSIM = //OneMinSSIM1k < 5 ?
    //-1 // Use SATD instead 
    //--------------------
    //:OneMinSSIM1k < 80 ?
    //(OneMinSSIM1k << 2) + (OneMinSSIM1k >> 2) + 100// + MeanDiff
    
      
    OneMinSSIM1k < 10 ?
    //YGJ_QScale(OneMinSSIM1k, 29, 8) + 12
    (OneMinSSIM1k << 3) + (OneMinSSIM1k << 2)  + 68
    :OneMinSSIM1k < 20 ?
    (OneMinSSIM1k << 3) - OneMinSSIM1k - (OneMinSSIM1k >> 2) + 124
    :OneMinSSIM1k < 50 ?
    (OneMinSSIM1k << 2) + (OneMinSSIM1k >> 2) + 186
    :OneMinSSIM1k < 100 ?
    //YGJ_QScale(OneMinSSIM1k, 11, 8) + 124    
    (OneMinSSIM1k << 1) + OneMinSSIM1k + 256
    
    :
    //OneMinSSIM1k + (OneMinSSIM1k >> 1)  + 300// + MeanDiff
    -1
    ;

    // Add Absolute Mean Difference related cost
    //PSeudoSSIM += PSeudoSSIM > -1 && MeanDiff > 0? 
    //    YGJ_QScale(MeanDiffx1SSIM, (16 - (OneMinSSIM1k >> 6)), 512): 0;
        //// Add Absolute Mean Difference related cost
    PSeudoSSIM += PSeudoSSIM > -1 && MeanDiff > 0? 
    //    YGJ_QScale(MeanDiffx1SSIM, (16 - (OneMinSSIM1k >> 6)), 512) : 0;
        (MeanDiff << 2) : 0;


    //// Now to add any Covariance related score
    PSeudoSSIM += PSeudoSSIM == -1 || SSIMCoVar == 0?
        //YGJ_QCalc(SSIMCoVar, 3)		
        //(YGJ_QScale((SSIMCoVar*OneMinSSIM1k), 3, 4) >> 10)
        //((YGJ_QScale(SSIMCoVar, 3, 4)) >> 10) * OneMinSSIM1k +  (YGJ_QScale(SSIMCoVar, 83, 128) >> 3)
        //OneMinSSIM1k < 80 ?
        //((YGJ_QScale(SSIMCoVar, 7, 16)) >> 10) * OneMinSSIM1k +  (YGJ_QScale(SSIMCoVar, 7, 16) >> 4)
        //:
        //        ((YGJ_QScale(SSIMCoVar, 3, 8)) >> 10) * OneMinSSIM1k +  (YGJ_QScale(SSIMCoVar, 3, 8) >> 3)
        //(SSIMCoVar >> 4) //- ((YGJ_QScale(SSIMCoVar, 13, 32) * OneMinSSIM1k) >> 10)
		0:               
        OneMinSSIM1k < 2 ?
        (OneMinSSIM1k * (YGJ_QCalc(SSIMCoVar, 3)) >> 9) - (SSIMCoVar >> 8)               
        :OneMinSSIM1k < 10 ?
        //YGJ_QScale(OneMinSSIM1k, 29, 8) + 12
        //(OneMinSSIM1k << 3) + (OneMinSSIM1k >> 1)  + 48
        ((OneMinSSIM1k * SSIMCoVar) >> 9) + (SSIMCoVar >> 9)               
        :OneMinSSIM1k < 20 ?
        ((OneMinSSIM1k * (SSIMCoVar >> 4)) >> 9) +  (SSIMCoVar >> 6)
        //((OneMinSSIM1k * SSIMCoVar) >> 10) +  (SSIMCoVar >> 5) - (SSIMCoVar >> 8)  //YGJ_QScale(SSIMCoVar, 7, 256)
        //(OneMinSSIM1k << 2) + OneMinSSIM1k - (OneMinSSIM1k >> 2) + 84
        :OneMinSSIM1k < 50 ?
        //((OneMinSSIM1k * SSIMCoVar) >> 10) + (SSIMCoVar >> 5)               
        ((OneMinSSIM1k * (SSIMCoVar >> 2)) >> 9) +  (SSIMCoVar >> 7)
        //(OneMinSSIM1k << 1) + OneMinSSIM1k + 120
        :OneMinSSIM1k < 100 ?
        //((OneMinSSIM1k * SSIMCoVar) >> 10) +  (SSIMCoVar >> 5) - (SSIMCoVar >> 7) //+ YGJ_QScale(SSIMCoVar, 3, 128)
        ((OneMinSSIM1k * (SSIMCoVar >> 2)) >> 9) +  (SSIMCoVar >> 8)
        
        : 0;

    return PSeudoSSIM;

}




/// !<  YGJ 30th Nov 2012 - A new simplified understanding and mini-model
/// !< Takes in the pre-calculated integer 1-SSIM x 1000, which will mean a three decimal accuracy of SSIM is now in integer form.
/// !< Also the Covariance is noted, it is expected to be Covariance + C2 where C2 for 8 bit video works out to be a constant of ~58.
/// !< Therefore each zone is subtracts C2 first.
/// !< The base zone is the most accurate model, since most samples were available.
/// !< Subsequent zones had fewer available samples and thus left as approximations
/// !< The fact that fewer samples where available is to down to the fact samples were taken where zero mean difference was measured between Original and Encoded blocks
/// !< This does not say they are absolutely identical but merely across the block in question they variations either cancel out or are minimum.
/// !< With SATD the variations in difference are accounted for while in SSIM they are amalgamated to as part of a relative difference.
/// !<  So, in order to keep in tune with the principles of SSIM, I've restricted myself to work with SSIM and the calculations to form it.
/// !< Overall this is to provide a Pseudo Distortion Metric based upon SSIM but also on the Covariance value associated with it and the Absolute Difference in Mean between the Original and Encoded blocks.
/// !< To keep the model simple only the base is accurately modelled by averaging sample values such that a coherent trend could be traced.
/// !<  For the other higher covariance differentiated 'zones', the lack of samples meant that a line of best fit would be only be available and thus this was noted.
/// !< Plotting the trend lines seemed to reflect what was occurring, suggesting the choice to limit by zero mean difference was wise.
/// !< The earlier zones have low changes in gradients, < 1. The middle and its adjacent zones share the same gradient but different offset, mimicking the static middle core observed in earlier data gathering modelling attempts.
/// !< The higher covariance zones have changes in gradient of less than 1 between them, including large ranges of covariance, suggesting more tightly packed samples as again illustrated in the graphs of earlier work.
/// !< The linear equations were made to be integer/processer friendly where possible. 
/// !< To allow for the movement between zones to be more gradual, a rate of change based upon the Covariance needed to be determined.
/// !<  These rates of change are based upon the relative covariance change within the zone it falls within, allowing for the sample to have some distinction for similar rated blocks in question.
/// !<  Similarly the purpose of Abs-Diff of Means to factor in that into the result and add a another level of dimensionality, favouring those which exhibit relative close values than those with large differences.
int YGJ_PseudoSSIM_Zones_4x4(int OneMinSSIM1k, int SSIMCoVar, int MeanDiff)
{
    int PSeudoSSIMValue = -1; //if -1 use SATD
    
    PSeudoSSIMValue = SSIMCoVar < 150? // Base
        YGJ_PseudoSSIM_Base_4x4(OneMinSSIM1k, SSIMCoVar, MeanDiff)
        : SSIMCoVar < 300? // Zone 150
        YGJ_PseudoSSIM_Cv150_4x4(OneMinSSIM1k, (SSIMCoVar-150), MeanDiff)
        : SSIMCoVar < 600? // Zone 300
        YGJ_PseudoSSIM_Cv300_4x4(OneMinSSIM1k, (SSIMCoVar-300), MeanDiff)
        : SSIMCoVar < 1350? // Zone 600
        YGJ_PseudoSSIM_Cv600_4x4(OneMinSSIM1k, (SSIMCoVar-600), MeanDiff)
        : SSIMCoVar < 3014? // Zone 1350
        YGJ_PseudoSSIM_Cv1350_4x4(OneMinSSIM1k, (SSIMCoVar-1350), MeanDiff)
        : SSIMCoVar < 8000? // Zone 3014
        YGJ_PseudoSSIM_Cv3014_4x4(OneMinSSIM1k, (SSIMCoVar-3014), MeanDiff)
        : -1;    

    return PSeudoSSIMValue;
}

int YGJ_PSeudoSSIM_4x4(int OneMinSSIM1k, int Covar, int AbsMeanDiff)
{

    // YGJ 13th March 2013 - Conditional and passing of values.
    return( !(OneMinSSIM1k < 1000) || Covar < 0 || Covar > 8000 ? -1 
        :  YGJ_PseudoSSIM_Zones_4x4(OneMinSSIM1k, Covar, AbsMeanDiff));

}


int YGJ_SSIMBasedDistortion(VideoParameters *p_Vid, ssiminf SSIMInfo, int blksize, int TradDist, int IsIntra)
{ 
    int OneMinSSIM1k = (int)((1-SSIMInfo.SSIMScore)*1000);
    int PseudoSSIMDist = -1;

    switch (blksize)
    {
    case 4 : PseudoSSIMDist = YGJ_PSeudoSSIM_4x4(OneMinSSIM1k, (int) SSIMInfo.Covariance, SSIMInfo.AbsMeanDiff);
        break;

    case 8 : PseudoSSIMDist = YGJ_PSeudoSSIM_8x8(OneMinSSIM1k, (int) SSIMInfo.Covariance, SSIMInfo.AbsMeanDiff);
        break;
    }
       

    // YGJ Sun 17th Feb 2013
    // Log if within specified range, see Configuration File
    p_Vid->p_Inp->LogDistSamples?
        
        ((p_Vid->p_Inp->Log8x8Samples == FALSE && blksize == 4) && ((p_Vid->p_Inp->LogIntraSamples == TRUE && IsIntra == TRUE) || (p_Vid->p_Inp->LogIntraSamples == FALSE && IsIntra == FALSE)))
        ||  ((p_Vid->p_Inp->Log8x8Samples == TRUE && blksize == 8) && ((p_Vid->p_Inp->LogIntraSamples == TRUE && IsIntra == TRUE) || (p_Vid->p_Inp->LogIntraSamples == FALSE && IsIntra == FALSE))) ? 
        
            OneMinSSIM1k >= p_Vid->p_Inp->LogMin1SSIM1k && OneMinSSIM1k <= p_Vid->p_Inp->LogMax1SSIM1k?
        
                SSIMInfo.Covariance >= p_Vid->p_Inp->LogMinCovar && SSIMInfo.Covariance <= p_Vid->p_Inp->LogMaxCovar?
        
                    SSIMInfo.AbsMeanDiff >= p_Vid->p_Inp->LogMinAbsMuDff && SSIMInfo.AbsMeanDiff <= p_Vid->p_Inp->LogMaxAbsMuDff?
                        
                        SSIMSample_add_to_list(TRUE, blksize, SSIMInfo.AbsMeanDiff, SSIMInfo.Covariance, SSIMInfo.SSIMScore, OneMinSSIM1k, PseudoSSIMDist, TradDist) 
                                                                    
                        :0
                    :0
                :0
            :0
        :0;
    

    // YGJ 13th March 2013 - Ensure that if TradDist is > -1 and PseudoSSIM == -1 then set to TradDist value instead
    // Otherwise SATD would be called twice under logging mode.
    //// YGJ 16th March 2013 - Using the Diff that was passed through from Motion Estimation - will do at a ME specific point to avoid being called inadvertently.
    PseudoSSIMDist = (PseudoSSIMDist > -1)?
        PseudoSSIMDist
        : TradDist;


    return PseudoSSIMDist;

}

//======================================================================



int GetDiffAndCalcSATD4x4(imgpel **refImg, imgpel **encImg)    
{
	int j; //, i, index;	    
    short diff16[16];
    short *tmp16 = diff16; 

	//===== get displaced frame difference ======
	for (j = 0; j < 4; j++)
	{
		*tmp16++ = (short) (refImg[j][0] - encImg[j][0]);
        *tmp16++ = (short) (refImg[j][1] - encImg[j][1]);
        *tmp16++ = (short) (refImg[j][2] - encImg[j][2]);
        *tmp16++ = (short) (refImg[j][3] - encImg[j][3]);	    
	}

	return (HadamardSAD4x4(diff16));
}


int GetDiffAndCalcSATD8x8(imgpel **refImg, imgpel **encImg)    
{
	int j; //, i, index;	    
    short diff64[64];
    short *tmp64 = diff64; 

	//===== get displaced frame difference ======
	for (j = 0; j < 8; j++)
	{
		*tmp64++ = (short) (refImg[j][0] - encImg[j][0]);
        *tmp64++ = (short) (refImg[j][1] - encImg[j][1]);
        *tmp64++ = (short) (refImg[j][2] - encImg[j][2]);
        *tmp64++ = (short) (refImg[j][3] - encImg[j][3]);	
        //----
        *tmp64++ = (short) (refImg[j][4] - encImg[j][4]);
        *tmp64++ = (short) (refImg[j][5] - encImg[j][5]);
        *tmp64++ = (short) (refImg[j][6] - encImg[j][6]);
        *tmp64++ = (short) (refImg[j][7] - encImg[j][7]);	    
    }

	return (HadamardSAD8x8(diff64));
}

// YGJ 27th Feb 2013
// SATD Calc Diff
// From Macroblock.c > transform decision. Need to seperate as two functions and use in-line if to call respective function.
//distblk GetDiffAndCalcSATD(int width, int mb_y, int mb_x, VideoParameters *p_Vid, int pic_pix_y, int pic_pix_x, imgpel **mb_pred)
// Assume width = height, therefore 4x4 or 8x8
int GetDiffAndCalcSATD(imgpel **refImg, imgpel **encImg, int height) {return ((height == 4)? GetDiffAndCalcSATD4x4(refImg, encImg) : GetDiffAndCalcSATD8x8(refImg, encImg));}



// SSIM Distortion Metric
// YGJ 21st Oct 2011
// The current post Quantisation Distion Metrics are SSE and not suitable for a Perceptual based encoding 
// where the residual may  be told to be ignored only then later the Distion check post reconstruction 
// leads it say otherwise. Not helpful, there I have decided to make my own base own SSIM

//=========================================
//!<  SSIM then Sobel with set Threshold based on height, 4x4 0.15, 8x8 0 and 16x16 -0.15. Based on trial and error. 
//!<  Saves time on using Std Dev to apply a relative threshold but not ideal.
//!<  Historical with a bit of refinement, not actually used except for demonstration or simplification of idea.
int YGJ_SSIMDistMetric (VideoParameters *p_Vid, imgpel **refImg, imgpel **encImg, int opix_x, int mb_x, int height, int TradDist)
{

	float C1, C2;

    ssiminf SSIMInfo;

	// YGJ 1st Sept 2012 - Only scale Window Size if 8x8 or greater
	int win_height = height; 
	int win_width = height; 
	int win_pixels =  YGJ_Calc_WinPixels(win_height, win_width);
	#ifdef UNBIASED_VARIANCE
	float win_pixels_bias = (float)(win_pixels - 1);
#else
	float win_pixels_bias = (float)win_pixels;
#endif
	double cur_distortion = 0.0;

	int PSeudoSSIM=-1;

    // YGJ 21st Feb 2013
    (p_Vid->p_Inp->CalcSSIMConst == 0)?
        ManualSSIMC1AndC2Calc(p_Vid, &C1, &C2)
        : LoadSSIMC1AndC2Values(p_Vid, &C1, &C2);

	////====================	
        
    SSIMInfo = YGJ_Compute_LocalSSIM(C1, C2, 0, refImg, encImg, opix_x, mb_x, win_height, win_width, win_pixels, win_pixels_bias, 0, 0, 0);

    PSeudoSSIM = YGJ_SSIMBasedDistortion(p_Vid, SSIMInfo, height, TradDist, TRUE);
    
    // YGJ 6th Mar 2013 - Conditional Fall Back if out of range.
    // If PseudoSSIM than -1 then use it. Else if TradDist > -1 use it. Else Calc Diff and use SATD.
    PSeudoSSIM = (PSeudoSSIM > -1)? PSeudoSSIM 
        : (TradDist > -1 )? TradDist 
        : GetDiffAndCalcSATD(refImg, encImg, height);

        
    p_Vid->p_Inp->LogDistSamples?

        p_Vid->p_Inp->LogIntraBlkLuma?
        
            (p_Vid->p_Inp->Log8x8Samples == 0 && win_height == 4) ||  (p_Vid->p_Inp->Log8x8Samples == 1 && win_height == 8)? 
        
                (int)((1-SSIMInfo.SSIMScore)*1000) >= p_Vid->p_Inp->LogMin1SSIM1k && (int)((1-SSIMInfo.SSIMScore)*1000) <= p_Vid->p_Inp->LogMax1SSIM1k?
        
                    SSIMInfo.Covariance >= p_Vid->p_Inp->LogMinCovar && SSIMInfo.Covariance <= p_Vid->p_Inp->LogMaxCovar?
        
                        SSIMInfo.AbsMeanDiff >= p_Vid->p_Inp->LogMinAbsMuDff && SSIMInfo.AbsMeanDiff <= p_Vid->p_Inp->LogMaxAbsMuDff?
                                                    
                            YGJ_printBlkValues_Intra(refImg, opix_x, encImg, mb_x, win_height)
                            
                            :0
                         :0
                     :0
                 :0
             :0            
        :0;



	return PSeudoSSIM;
}


distblk YGJ_SSIMDistMetric_dstblk (VideoParameters *p_Vid, imgpel **refImg, imgpel **encImg, int opix_x, int mb_x, int height, int TradDist)
{
    return dist_scale((distblk) YGJ_SSIMDistMetric (p_Vid, refImg, encImg, opix_x, mb_x, height, TradDist));
}



//===========================================

int YGJ_SSIMDistMetric_1D_ME_NoOverlap (VideoParameters *p_Vid, short *refImg, short *encImg, int SSIMSqBlkWidth, int TradDist)
{	    
	float C1, C2;

    // YGJ 23rd Feb 2013 - tracking respective Covar and AbsMeanDiff for PseudoSSIM and for logging purposes       

    ssiminf SSIMInfo;

	//------------
	//int SSIM_win_width = SSIMSqBlkWidth;
	//int win_pixels =  16; 
    int win_pixels =  (SSIMSqBlkWidth == 4)? 16 : 64; //width will either be 4x4 or 8x8, therefore win_pixels will be either 4x4 or 8x8, 16 or 64. 
	#ifdef UNBIASED_VARIANCE
	float win_pixels_bias = (float)(win_pixels - 1);
	#else
	float win_pixels_bias = (float)win_pixels;
	#endif
	double cur_distortion = 0.0;
	//====================	
	//int EdgeCount=0;
	int PSeudoSSIM = -1;
	//--------------

    // YGJ 21st Feb 2013
    (p_Vid->p_Inp->CalcSSIMConst == 0)?
        ManualSSIMC1AndC2Calc(p_Vid, &C1, &C2)
        : LoadSSIMC1AndC2Values(p_Vid, &C1, &C2);    
    
    ////====================	


    SSIMInfo = YGJ_OneDimSSIM_ME_Single(C1, C2, refImg, encImg, SSIMSqBlkWidth, win_pixels, win_pixels_bias, 0, 0, 0); 
    cur_distortion = SSIMInfo.SSIMScore;

	SSIMInfo.SSIMScore = cur_distortion = cur_distortion >= 1.0 ? 1.0 : cur_distortion;		    
	
	// YGJ Tue 16th Oct 2012 - Added to restrict use of PSeudoSSIM Model to postive SSIM (SSIM > 0, 1-SSIM < 1) 
	// and positive covariance.

    // YGJ 20th Feb 2013 - Checks happen within this function call.
    PSeudoSSIM = YGJ_SSIMBasedDistortion(p_Vid, SSIMInfo, SSIMSqBlkWidth, TradDist, FALSE);


            // YGJ Sun 17th Feb 2013
    // Log if within specified range, see Configuration File
    p_Vid->p_Inp->LogDistSamples?

        p_Vid->p_Inp->LogMEBlockLuma?
        
            (p_Vid->p_Inp->Log8x8Samples == 0 && SSIMSqBlkWidth == 4) ||  (p_Vid->p_Inp->Log8x8Samples == 1 && SSIMSqBlkWidth == 8)? 
        
                (int)((1-SSIMInfo.SSIMScore)*1000) >= p_Vid->p_Inp->LogMin1SSIM1k && (int)((1-SSIMInfo.SSIMScore)*1000) <= p_Vid->p_Inp->LogMax1SSIM1k?
        
                    SSIMInfo.Covariance >= p_Vid->p_Inp->LogMinCovar && SSIMInfo.Covariance <= p_Vid->p_Inp->LogMaxCovar?
        
                        SSIMInfo.AbsMeanDiff >= p_Vid->p_Inp->LogMinAbsMuDff && SSIMInfo.AbsMeanDiff <= p_Vid->p_Inp->LogMaxAbsMuDff?
                                                    
                            YGJ_printBlkValues_ME_short( refImg,  encImg, SSIMSqBlkWidth)
                                       
                            :0
                         :0
                     :0
                 :0
             :0            
        :0;
    

	return PSeudoSSIM;
	}

int YGJ_SSIMDistMetric_1D_ME_withOverlap (VideoParameters *p_Vid, short *refImg, short *encImg, int SSIMSqBlkWidth, int TradDist)
{	    

	float C1, C2;
            
    // YGJ 23rd Feb 2013 - tracking respective Covar and AbsMeanDiff for PseudoSSIM and for logging purposes       


    ssiminf SSIMInfo;
	//------------

	int SSIM_win_width = YGJ_Calc_WinHeightOrWidth(SSIMSqBlkWidth);
	int win_pixels =  (SSIMSqBlkWidth == 4)? 4 : 16; //width will either be 4x4 or 8x8, therefore win_pixels will be either 2x2 or 4x4, 4 or 16. 
	#ifdef UNBIASED_VARIANCE
	float win_pixels_bias = (float)(win_pixels - 1);
	#else
	float win_pixels_bias = (float)win_pixels;
	#endif
	double cur_distortion = 0.0;
	//====================	
	double LSSIM[max_SSIM_Overlap]; // Will accommodate a 4x4, 8x8 and 16x16;
	int EdgeCount=0;
	int PSeudoSSIM = -1;
	//--------------
	// Pick the points which will be assessed with a Non-Overlapping Scaled SSIM Search Window
	int OneDim4x4[max_SSIM_Overlap] = {0, 1, 2, 4, 5, 6, 8, 9, 10}; // 2x2 Window with overlap
	int OneDim8x8[max_SSIM_Overlap] = {0, 2, 4, 16, 18, 20, 32, 34, 36}; // 4x4 Window with overlap

	int *pLocal = (SSIMSqBlkWidth == 4)? OneDim4x4 : OneDim8x8;
       
    // YGJ 21st Feb 2013
    (p_Vid->p_Inp->CalcSSIMConst == 0)?
        ManualSSIMC1AndC2Calc(p_Vid, &C1, &C2)
        : LoadSSIMC1AndC2Values(p_Vid, &C1, &C2);

	////====================	
////--------------

	//cur_distortion += LSSIM[0] = 
    SSIMInfo = YGJ_OneDimSSIM_ME(C1, C2, refImg, encImg, SSIMSqBlkWidth, SSIM_win_width, win_pixels, win_pixels_bias, 0, 0, 0); // 0
	cur_distortion += LSSIM[0] = SSIMInfo.SSIMScore;
    *pLocal++;

	//cur_distortion += LSSIM[1] = 
    SSIMInfo = YGJ_OneDimSSIM_ME(C1, C2, &refImg[*pLocal], &encImg[*pLocal], SSIMSqBlkWidth, SSIM_win_width, win_pixels, win_pixels_bias, 1, SSIMInfo.Covariance, SSIMInfo.AbsMeanDiff); // 1
	cur_distortion += LSSIM[1] = SSIMInfo.SSIMScore;
    *pLocal++;

	//cur_distortion += LSSIM[2] = 
    SSIMInfo = YGJ_OneDimSSIM_ME(C1, C2, &refImg[*pLocal], &encImg[*pLocal], SSIMSqBlkWidth, SSIM_win_width, win_pixels, win_pixels_bias, 2, SSIMInfo.Covariance, SSIMInfo.AbsMeanDiff); // 2
	cur_distortion += LSSIM[2] = SSIMInfo.SSIMScore;
    *pLocal++;
	
	//cur_distortion += LSSIM[3] = 
    SSIMInfo = YGJ_OneDimSSIM_ME(C1, C2, &refImg[*pLocal], &encImg[*pLocal], SSIMSqBlkWidth, SSIM_win_width, win_pixels, win_pixels_bias, 3, SSIMInfo.Covariance, SSIMInfo.AbsMeanDiff); //3
	cur_distortion += LSSIM[3] = SSIMInfo.SSIMScore;
    *pLocal++;

	//cur_distortion += LSSIM[4] = 
    SSIMInfo = YGJ_OneDimSSIM_ME(C1, C2, &refImg[*pLocal], &encImg[*pLocal], SSIMSqBlkWidth, SSIM_win_width, win_pixels, win_pixels_bias, 4, SSIMInfo.Covariance, SSIMInfo.AbsMeanDiff); // 4
	cur_distortion += LSSIM[4] = SSIMInfo.SSIMScore;
    *pLocal++;

	//cur_distortion += LSSIM[5] = 
    SSIMInfo = YGJ_OneDimSSIM_ME(C1, C2, &refImg[*pLocal], &encImg[*pLocal], SSIMSqBlkWidth, SSIM_win_width, win_pixels, win_pixels_bias, 5, SSIMInfo.Covariance, SSIMInfo.AbsMeanDiff); // 5
	cur_distortion += LSSIM[5] = SSIMInfo.SSIMScore;
    *pLocal++;
    
	//cur_distortion += LSSIM[6] = 
    SSIMInfo = YGJ_OneDimSSIM_ME(C1, C2, &refImg[*pLocal], &encImg[*pLocal], SSIMSqBlkWidth, SSIM_win_width, win_pixels, win_pixels_bias, 6, SSIMInfo.Covariance, SSIMInfo.AbsMeanDiff); //6
	cur_distortion += LSSIM[6] = SSIMInfo.SSIMScore;
    *pLocal++;

	//cur_distortion += LSSIM[7] = 
    SSIMInfo = YGJ_OneDimSSIM_ME(C1, C2, &refImg[*pLocal], &encImg[*pLocal], SSIMSqBlkWidth, SSIM_win_width, win_pixels, win_pixels_bias, 7, SSIMInfo.Covariance, SSIMInfo.AbsMeanDiff); // 7
	cur_distortion += LSSIM[7] = SSIMInfo.SSIMScore;
    *pLocal++;

	//cur_distortion += LSSIM[8] = 
    SSIMInfo = YGJ_OneDimSSIM_ME(C1, C2, &refImg[*pLocal], &encImg[*pLocal], SSIMSqBlkWidth, SSIM_win_width, win_pixels, win_pixels_bias, 8, SSIMInfo.Covariance, SSIMInfo.AbsMeanDiff); // 8
	cur_distortion += LSSIM[8] = SSIMInfo.SSIMScore;

	//--------------
	// Again Non-Overlapping search window therefore this is set to 4.
	cur_distortion /=  max_SSIM_Overlap;	
	cur_distortion = cur_distortion >= 1.0 ? 1.0 : cur_distortion;

	EdgeCount +=  LSSIM[4] > 0.0 ? YGJ_MyoEdgeDetect(LSSIM[4], LSSIM[3], LSSIM[1]) : 0;
	EdgeCount +=  LSSIM[5] > 0.0 ? YGJ_MyoEdgeDetect(LSSIM[5], LSSIM[4], LSSIM[2]) : 0;
	EdgeCount +=  LSSIM[7] > 0.0 ? YGJ_MyoEdgeDetect(LSSIM[7], LSSIM[6], LSSIM[4]) : 0;
	EdgeCount +=  LSSIM[8] > 0.0 ? YGJ_MyoEdgeDetect(LSSIM[8], LSSIM[7], LSSIM[5]) : 0;
	
	// YGJ Tue 16th Oct 2012 - Added to restrict use of PSeudoSSIM Model to postive SSIM (SSIM > 0, 1-SSIM < 1) 
	// and positive covariance.
	
    // YGJ 20th Feb 2013 - Checks happen within this function call.
    PSeudoSSIM = YGJ_SSIMBasedDistortion(p_Vid, SSIMInfo, SSIMSqBlkWidth, TradDist, FALSE);
	
    // Add 0.625% of Cur Dist. to the Existing Value. In Binary a tenth's of a fraction is a recurring number, best to keep with a Binary Friendly number of 1/16, 0.0625 instead
	//PSeudoSSIM +=  PSeudoSSIM > 0 && EdgeCount == 1 ? (PSeudoSSIM >> 4) : 0;
	// Ignores in -1, scenario which is more a case of < 0.5 in SSIM terms. YGJ 15th Aug 2012	

	// YGJ 31st Aug 2012 - Only affect 4x4 - Adds a fraction more to the distortion figure depending upon the number edges detected
	PSeudoSSIM += (SSIMSqBlkWidth == 4) && (EdgeCount > 0)? 
		EdgeCount*(PSeudoSSIM >> 4)
		: -(PSeudoSSIM >> 6); 


	return PSeudoSSIM;
	}


// Applies SSIM on the Motion Estimation (reconstructed)
// Since this is aimed at applying on te SATD which moves in (sub-)blocks of 4x4 or 8x8 this means that the respective (sub-)block needs to be assessed.
// This means determining which sector or quadrant it is expected to assess.
// This function, YGJ_SSIMDistMetric_1D_ME, operates a one dimensional array and so the  correct starting position must be calculated.
// Assuming that in a 4x4 Transform  will be 16 values, 2^4 and 8x8 is  64, 2^6, 
// then multiplying the current sector/quadrant value with the respective value for the given transform used will give the start position along the 1D array.
// Minor issue to remember to either calc SecOrQuadNo starting from 0 or minus one when in it arrives here (Update - done here), otherwise risk of wrong sub-block being assessed.

//  YGJ 14th May 2012 - In order to determine the actual array location the block width and height needs to be known to then calc Local SSIM at set points.
// In this case they will be scaled non-overlapping. However the block may be non-square/rectangular but the SSIM being applied will be operate in a Square Block manor.
// Therefore the smaller of the two sides will need to be used set the SSIM Scaled Window.
// Assumes that when this function is called that the current working location for the ref image block and encoded Image block is updated when called.
//int YGJ_SSIMDistMetric_1D_ME (VideoParameters *p_Vid, short *refImg, short *encImg, int width, int height, int SSIMSqBlkWidth)
// YGJ 16th March 2013 - Since under ME in SSIMwSATD, SSIMwSSE and SSIMwSAD the Diff is calculated it makes sense to pass this across and use this to perform SATD, SSE or SAD as required
int YGJ_SSIMDistMetric_1D_ME (VideoParameters *p_Vid, short *refImg, short *encImg, int SSIMSqBlkWidth, int TradDist, short *Diff)
{	    

	int PSeudoSSIM = -1;

	PSeudoSSIM = p_Vid -> p_Inp-> ME_PseudoSSIM_wOverlap ? 
		YGJ_SSIMDistMetric_1D_ME_withOverlap(p_Vid, refImg, encImg, SSIMSqBlkWidth, TradDist) // Takes longer to process
		: 
        YGJ_SSIMDistMetric_1D_ME_NoOverlap(p_Vid, refImg, encImg, SSIMSqBlkWidth, TradDist);

        
    // YGJ 16th March 2013 - Using the Diff that was passed through from Motion Estimation
    PSeudoSSIM = (PSeudoSSIM > -1)?
        PSeudoSSIM
        : (PSeudoSSIM == -1 && TradDist == -1 && SSIMSqBlkWidth == 4)?
        HadamardSAD4x4(Diff)
        : HadamardSAD8x8(Diff);

	return PSeudoSSIM;
	}


// Fri 4th Jan 2013 - Actually Non-Overlapping
// YGJ 17th Mar 2013 - No longer actually used. SSIM is called directly, as this method was cumbersome and error prone.
// The difference was worked out only to be used to reconstruct the original. Hence a direct method is now in place.
// Therefore the following route is now redundant., but kept for historical sense and because main code still links here,
// albeit there is an If-Then-Else statement to catch it before it is called.
// Redundant Route:
//  distortionAxASSIMwXXXX -> YGJ_SSIMOverlapDistMetricFactor - >  OneDimSSIM.
// Please note that the If Then check for the Pixel values do still exist should by chance these functions get called.
distblk YGJ_SSIMOverlapDistMetricFactor (VideoParameters *p_Vid, short* diff, int height, int width, int TradDist)
{	    

	float C1, C2;
            
    // YGJ 23rd Feb 2013 - tracking respective Covar and AbsMeanDiff for PseudoSSIM and for logging purposes       

    ssiminf SSIMInfo;

	//------------
	int win_height = height;
	int win_width = width;
	int win_pixels =  YGJ_Calc_WinPixels(win_height, win_width);
	#ifdef UNBIASED_VARIANCE
	float win_pixels_bias = (float)(win_pixels - 1);
	#else
	float win_pixels_bias = (float)win_pixels;
	#endif
	double cur_distortion = 0.0;
	imgpel **curr_Img = p_Vid->pCurImg;
	//====================	
	int EdgeCount=0;
	int PSeudoSSIM = -1;

    // YGJ 21st Feb 2013
    (p_Vid->p_Inp->CalcSSIMConst == 0)?
        ManualSSIMC1AndC2Calc(p_Vid, &C1, &C2)
        : LoadSSIMC1AndC2Values(p_Vid, &C1, &C2);
    
    ////====================	

    SSIMInfo =  YGJ_OneDimSSIM(C1, C2, 0, curr_Img, diff, height, win_width, win_height, win_pixels, win_pixels_bias, 0, 0, 0);

    cur_distortion = SSIMInfo.SSIMScore;

	SSIMInfo.SSIMScore = cur_distortion = cur_distortion >= 1.0 ? 1.0 : cur_distortion;


	// YGJ Tue 16th Oct 2012 - Added to restrict use of PSeudoSSIM Model to postive SSIM (SSIM > 0, 1-SSIM < 1) 
	// and positive covariance.
	
   // YGJ 20th Feb 2013 - Checks happen within this function call.
    PSeudoSSIM = YGJ_SSIMBasedDistortion(p_Vid, SSIMInfo, width, TradDist, FALSE);

	// Note tempSATD is used to recover the SATD for the same block which has also been assessed in terms of SSIM
	//printf("YGJ_SSIMOverlapDistMetricFactor, Logging Accumulated SSIM and other values, Total_SSIM_dist, %f, cur_distortion, %f, SATD, %d, PSeudoSSIM, %d, EdgeCount, %d, height, %d, width, %d \n",Total_SSIM_dist, cur_distortion, tempSATD, PSeudoSSIM, EdgeCount, height, width);

	return PSeudoSSIM;
	}

// Designed to assess Residual and modifiy it if no edge is detected and average is < 60 or > 192
void YGJ_SSIMResAssess (VideoParameters *p_Vid, imgpel **refImg, int **encImg, int opix_x, int mb_x, int height, int width)
{
	//static const float K1 = 0.01f, K2 = 0.03f;
	//float max_pix_value_sqd;
	float C1, C2;
            
    // YGJ 23rd Feb 2013 - tracking respective Covar and AbsMeanDiff for PseudoSSIM and for logging purposes       
    //float Covar;
    //int AbsMeanDiff;
    ssiminf SSIMInfo;

	int win_height = YGJ_Calc_WinHeightOrWidth(height);
	int win_width = YGJ_Calc_WinHeightOrWidth(width);
	int win_pixels =  YGJ_Calc_WinPixels(win_height, win_width);
	#ifdef UNBIASED_VARIANCE
	float win_pixels_bias = (float)(win_pixels - 1);
#else
	float win_pixels_bias = (float)win_pixels;
#endif
	double cur_distortion = 0.0;
	int overlapSize_height = YGJ_Calc_OverlapSize(win_height);
	int overlapSize_width= YGJ_Calc_OverlapSize(win_width);
	int ShiftDivByOverlap_height = YGJ_Calc_ShiftDivByOverlap(overlapSize_height);
	int ShiftDivByOverlap_width = YGJ_Calc_ShiftDivByOverlap(overlapSize_width);
	//====================
	// YGJ 31st May 2011	
	// Block Size -> Number of SSIM Calc -> Number of MyoSobel Calc
	// 4x4 -> 3x3 -> 2x2
	// 8x8 -> 3x3 -> 2x2
	// 16x16 -> 3x3 -> 2x2
	double LSSIM[9]; // Will accommodate a 4x4, 8x8 and 16x16;
	double* ptrLSSIM;
	int EdgeCount=0;
	int PSeudoSSIM=0;
	//int BlkCorners = 0;

    // YGJ 21st Feb 2013
    (p_Vid->p_Inp->CalcSSIMConst == 0)?
        ManualSSIMC1AndC2Calc(p_Vid, &C1, &C2)
        : LoadSSIMC1AndC2Values(p_Vid, &C1, &C2);

    
    ////====================	
		
	ptrLSSIM = LSSIM;

	//cur_distortion = 
    SSIMInfo = YGJ_CalcSSIM_Overlap(ptrLSSIM, C1, C2, overlapSize_width, overlapSize_height, refImg, (imgpel**)encImg, opix_x, mb_x, win_height, win_width, win_pixels, win_pixels_bias);
		

	EdgeCount = SSIMMapEdgeCount(LSSIM);

	if (EdgeCount == 0)
	{
		// Where Edges are not detected calculate the local Average and if < 60 or > 192 then apply the new average.
		YGJ_SetQuadResidualAverage(encImg, mb_x, win_height, win_width, overlapSize_width, overlapSize_height, 0, 1);
		YGJ_SetQuadResidualAverage(encImg, mb_x, win_height, win_width, overlapSize_width, overlapSize_height, 1, 1);
		YGJ_SetQuadResidualAverage(encImg, mb_x, win_height, win_width, overlapSize_width, overlapSize_height, 2, 1);
		YGJ_SetQuadResidualAverage(encImg, mb_x, win_height, win_width, overlapSize_width, overlapSize_height, 3, 1);
	}

	return;
}


/*!
***********************************************************************
* \brief
*    Calculate SSIM 4x4 - 
// Fri 4th Jan 2013 - Actually Non-Overlapping
***********************************************************************
// YGJ 17th Mar 2013 - No longer actually used. SSIM is called directly, as this method was cumbersome and error prone.
// The difference was worked out only to be used to reconstruct the original. Hence a direct method is now in place.
// Therefore the following route is now redundant., but kept for historical sense and because main code still links here,
// albeit there is an If-Then-Else statement to catch it before it is called.
// Redundant Route:
//  distortionAxASSIMwXXXX -> YGJ_SSIMOverlapDistMetricFactor - >  OneDimSSIM.
// Please note that the If Then check for the Pixel values do still exist should by chance these functions get called.
*/
distblk distortion4x4SSIM(short* diff, distblk min_dist) { return dist_scale(YGJ_SSIMOverlapDistMetricFactor(p_Enc->p_Vid, diff, 4, 4, -1));}

/*!
***********************************************************************
* \brief
*   Calculate SSIM for 8x8
// Fri 4th Jan 2013 - Actually Non-Overlapping
***********************************************************************
// YGJ 17th Mar 2013 - No longer actually used. SSIM is called directly, as this method was cumbersome and error prone.
// The difference was worked out only to be used to reconstruct the original. Hence a direct method is now in place.
// Therefore the following route is now redundant., but kept for historical sense and because main code still links here,
// albeit there is an If-Then-Else statement to catch it before it is called.
// Redundant Route:
//  distortionAxASSIMwXXXX -> YGJ_SSIMOverlapDistMetricFactor - >  OneDimSSIM.
// Please note that the If Then check for the Pixel values do still exist should by chance these functions get called.
*/
distblk distortion8x8SSIM(short* diff, distblk min_dist) { return dist_scale(YGJ_SSIMOverlapDistMetricFactor(p_Enc->p_Vid, diff, 8, 8, -1));}


// YGJ 17th Mar 2013 - No longer actually used. SSIM is called directly, as this method was cumbersome and error prone.
// The difference was worked out only to be used to reconstruct the original. Hence a direct method is now in place.
// Therefore the following route is now redundant., but kept for historical sense and because main code still links here,
// albeit there is an If-Then-Else statement to catch it before it is called.
// Redundant Route:
//  distortionAxASSIMwXXXX -> YGJ_SSIMOverlapDistMetricFactor - >  OneDimSSIM.
// Please note that the If Then check for the Pixel values do still exist should by chance these functions get called.
distblk distortion4x4SSIMwSATD(short* diff, distblk min_dist)
{
	distblk i64Ret = 0;
	distblk iHadRet = HadamardSAD4x4( diff );
	distblk iSSIMRet = 0;
	VideoParameters *p_Vid = p_Enc->p_Vid;
	// YGJ 21st Feb 2012

    // Fri 4th Jan 2013 - Actually Non-Overlapping
	iSSIMRet = YGJ_SSIMOverlapDistMetricFactor(p_Enc->p_Vid, diff, 4, 4, dist_down(iHadRet));
			

    // YGJ 18th Oct 2012 - iSSIMRet will be less than 0 if Covariance is < than 0 or SSIM < 0 (1-SSIM > 1).
    // PSeudoSSIM to be used only in positive Covariance and when SSIM is also positive.
    
    // YGJ 4th Jan 2013 - Keep it Simple
    i64Ret = ((iSSIMRet < 0) || (iHadRet < YGJ_MIN4x4 || iHadRet > YGJ_MAX4x4))? 
        iHadRet : iSSIMRet; 


	return dist_scale(i64Ret);
	}

/*!
***********************************************************************
* \brief
*    Based upon distortion8x8SATD. Calculate SATD for 8x8 and SSIM and take Average of the two
// YGJ 7th Feb 2012
***********************************************************************
// YGJ 17th Mar 2013 - No longer actually used. SSIM is called directly, as this method was cumbersome and error prone.
// The difference was worked out only to be used to reconstruct the original. Hence a direct method is now in place.
// Therefore the following route is now redundant., but kept for historical sense and because main code still links here,
// albeit there is an If-Then-Else statement to catch it before it is called.
// Redundant Route:
//  distortionAxASSIMwXXXX -> YGJ_SSIMOverlapDistMetricFactor - >  OneDimSSIM.
// Please note that the If Then check for the Pixel values do still exist should by chance these functions get called.
*/
distblk distortion8x8SSIMwSATD(short* diff, distblk min_dist)
{
	distblk i64Ret = 0;
	distblk iHadRet = HadamardSAD8x8( diff );
	distblk iSSIMRet = 0;
	VideoParameters *p_Vid = p_Enc->p_Vid;
	// YGJ 21st Feb 2012
		

    // Fri 4th Jan 2013 - Actually Non-Overlapping
	iSSIMRet = YGJ_SSIMOverlapDistMetricFactor(p_Enc->p_Vid, diff, 8, 8, dist_down(iHadRet));
	
    // YGJ 18th Oct 2012 - iSSIMRet will be less than 0 if Covariance is < than 0 or SSIM < 0 (1-SSIM > 1).
    // PSeudoSSIM to be used only in positive Covariance and when SSIM is also positive.
    
    // YGJ 4th Jan 2013 - Keep it Simple
    i64Ret = ((iSSIMRet < 0) || (iHadRet < YGJ_MIN8x8 || iHadRet > YGJ_MAX8x8))? 
        iHadRet : iSSIMRet; 


	return dist_scale(i64Ret);
}

//--------------------------------------------------
//*****************************************************
//*****************************************************
//--------------------------------------------------
//Added by YGJ 4th Jan 2013		
// YGJ 4th Jan 2013 - Need to gather data to compare
// YGJ 17th Mar 2013 - No longer actually used. SSIM is called directly, as this method was cumbersome and error prone.
// The difference was worked out only to be used to reconstruct the original. Hence a direct method is now in place.
// Therefore the following route is now redundant., but kept for historical sense and because main code still links here,
// albeit there is an If-Then-Else statement to catch it before it is called.
// Redundant Route:
//  distortionAxASSIMwXXXX -> YGJ_SSIMOverlapDistMetricFactor - >  OneDimSSIM.
// Please note that the If Then check for the Pixel values do still exist should by chance these functions get called.
distblk distortion4x4SSIMwSSE(short* diff, distblk min_dist)
{
	distblk i64Ret = 0;
	distblk iSSERet = distortion4x4SSE( diff, min_dist );
	distblk iSSIMRet = 0;
	VideoParameters *p_Vid = p_Enc->p_Vid;
	// YGJ 21st Feb 2012

	if (iSSERet < YGJ_MIN4x4 || iSSERet > YGJ_MAX4x4)
		return dist_scale(iSSERet);

    // Fri 4th Jan 2013 - Actually Non-Overlapping
	iSSIMRet = YGJ_SSIMOverlapDistMetricFactor(p_Enc->p_Vid, diff, 4, 4, dist_down(iSSERet) );
    
    // YGJ 4th Jan 2013 - Keep it Simple
    i64Ret = iSSIMRet < 0 ? iSSERet : iSSIMRet; 

	return dist_scale(i64Ret);
	}

/*!
***********************************************************************
* \brief
*     Based upon distortion8x8SSIMwSATD. Calculate SATD for 8x8 and SSIM and take Average of the two
// YGJ 4th Jan 2013
***********************************************************************
// YGJ 17th Mar 2013 - No longer actually used. SSIM is called directly, as this method was cumbersome and error prone.
// The difference was worked out only to be used to reconstruct the original. Hence a direct method is now in place.
// Therefore the following route is now redundant., but kept for historical sense and because main code still links here,
// albeit there is an If-Then-Else statement to catch it before it is called.
// Redundant Route:
//  distortionAxASSIMwXXXX -> YGJ_SSIMOverlapDistMetricFactor - >  OneDimSSIM.
// Please note that the If Then check for the Pixel values do still exist should by chance these functions get called.
*/
distblk distortion8x8SSIMwSSE(short* diff, distblk min_dist)
{
	distblk i64Ret = 0;
	distblk iSSERet = distortion8x8SSE( diff, min_dist );
	distblk iSSIMRet = 0;
	VideoParameters *p_Vid = p_Enc->p_Vid;
	// YGJ 21st Feb 2012
		
	if (iSSERet < YGJ_MIN8x8 || iSSERet > YGJ_MAX8x8)
		return dist_scale(iSSERet);

    // Fri 4th Jan 2013 - Actually Non-Overlapping
	iSSIMRet = YGJ_SSIMOverlapDistMetricFactor(p_Enc->p_Vid, diff, 8, 8, dist_down(iSSERet));

    // YGJ 4th Jan 2013 - Keep it Simple
    i64Ret = iSSIMRet < 0 ? iSSERet : iSSIMRet;

	return dist_scale(i64Ret);
}
//--------------------------------------------------
//*****************************************************
//*****************************************************
//--------------------------------------------------
//Added by YGJ 4th Jan 2013		
// YGJ 4th Jan 2013 - Need to gather data to compare
// YGJ 17th Mar 2013 - No longer actually used. SSIM is called directly, as this method was cumbersome and error prone.
// The difference was worked out only to be used to reconstruct the original. Hence a direct method is now in place.
// Therefore the following route is now redundant., but kept for historical sense and because main code still links here,
// albeit there is an If-Then-Else statement to catch it before it is called.
// Redundant Route:
//  distortionAxASSIMwXXXX -> YGJ_SSIMOverlapDistMetricFactor - >  OneDimSSIM.
// Please note that the If Then check for the Pixel values do still exist should by chance these functions get called.
distblk distortion4x4SSIMwSAD(short* diff, distblk min_dist)
{
	distblk i64Ret = 0;
	distblk iSADRet = distortion4x4SAD( diff, min_dist );
	distblk iSSIMRet = 0;
	VideoParameters *p_Vid = p_Enc->p_Vid;
	// YGJ 21st Feb 2012

	if (iSADRet < YGJ_MIN4x4 || iSADRet > YGJ_MAX4x4)
		return dist_scale(iSADRet);

    // Fri 4th Jan 2013 - Actually Non-Overlapping
	iSSIMRet = YGJ_SSIMOverlapDistMetricFactor(p_Enc->p_Vid, diff, 4, 4, dist_down(iSADRet));

    // YGJ 4th Jan 2013 - Keep it Simple
    i64Ret = iSSIMRet < 0 ? iSADRet : iSSIMRet; 

	return dist_scale(i64Ret);
	}

/*!
***********************************************************************
* \brief
*    Based upon distortion8x8SSIMwSATD. Calculate SATD for 8x8 and SSIM and take Average of the two
// YGJ 4th Jan 2013
***********************************************************************
// YGJ 17th Mar 2013 - No longer actually used. SSIM is called directly, as this method was cumbersome and error prone.
// The difference was worked out only to be used to reconstruct the original. Hence a direct method is now in place.
// Therefore the following route is now redundant., but kept for historical sense and because main code still links here,
// albeit there is an If-Then-Else statement to catch it before it is called.
// Redundant Route:
//  distortionAxASSIMwXXXX -> YGJ_SSIMOverlapDistMetricFactor - >  OneDimSSIM.
// Please note that the If Then check for the Pixel values do still exist should by chance these functions get called.
*/
distblk distortion8x8SSIMwSAD(short* diff, distblk min_dist)
{
	distblk i64Ret = 0;
	distblk iSADRet = distortion8x8SAD( diff, min_dist );
	distblk iSSIMRet = 0;
	VideoParameters *p_Vid = p_Enc->p_Vid;
	// YGJ 21st Feb 2012
		
	if (iSADRet < YGJ_MIN8x8 || iSADRet > YGJ_MAX8x8)
		return dist_scale(iSADRet);

    // Fri 4th Jan 2013 - Actually Non-Overlapping
	iSSIMRet = YGJ_SSIMOverlapDistMetricFactor(p_Enc->p_Vid, diff, 8, 8, dist_down(iSADRet));

    // YGJ 4th Jan 2013 - Keep it Simple
    i64Ret = iSSIMRet < 0 ? iSADRet : iSSIMRet;

	return dist_scale(i64Ret);
}
//--------------------------------------------------



//=====================================
// Fri 17th June 2011
// The YGJ QP Adjustment Scale
// 1) Take Input Config File QP for type of frame, default is 28
// 2) Use the EdgeCount[1] result as guideline

// double lambda_md = p_Vid->lambda_md[p_Vid->type][p_Vid->masterQP];  - I want to adjust QP
// int masterQP;                //!< Master quantization parameter
// int qp;                      //!< quant for the current frame
// p_Vid->SumFrameQP += currMB->qp;
// Need to copy MasterQP elsewhere (for a while), set masterQP to a new value based on calc
// Then replace it with orig. Master QP after Quant.
// A quick shuffle :)

// Now Use the Edge Count from the Residual to skew the QP
// thus it can increase or decrease
// If EdgeCount is high, then QPnew should be set to a lower value
// if intra-predicted has more lines detected than residual then increase QP by the difference of Master and MacroblockQP
// else steer residual QP 
// Since EdgeCount[0] is the Edge Count, Sobel Mask on the LSSIM of the Interpredicted block 
// and EdgeCount[1] is the Edge Count Sobel Mask on the Residual (preQuantised), NOT the LSSIM of the  Residual (preQuant)

//=============================================================

// YGJ 13th Feb 2012
int YGJ_Intra_QPSteering(int masterQP, int currMBqp, VideoParameters *p_Vid, InputParameters *p_Inp, imgpel **cur_img, imgpel **res_img, imgpel **prd_img, int opix_x, int mb_x, int IntraBlockSize )
{	
	// Only interested if residual  and intra-predicted edges/lines detected. 
	int EdgeCount[2] = {0,0};  //!< Store the number edges detected in the 3x3 SSIM Map
	int QPnew = currMBqp;
	int QPcurrMB = currMBqp;
	
	int QPold = (p_Vid->type == I_SLICE)? masterQP : QPcurrMB;
												
	if ((QPcurrMB > 5 && QPold > 5) && (QPcurrMB < 45 && QPold < 45))                  
	{            
		EdgeCount[1] = YGJ_LocalSSIMwMyoEdge(p_Vid, cur_img, res_img, opix_x, mb_x, IntraBlockSize, IntraBlockSize);
		
		EdgeCount[0] = YGJ_LocalSSIMwMyoEdge(p_Vid,  cur_img, (imgpel **)prd_img,  opix_x,  mb_x, IntraBlockSize, IntraBlockSize);
									
		// Figures out the Change in QP that needs to be applied
		//	// If more Predicted EdgeCount then increase QP, if more Residual EdgeCount lower QP								
		switch (IntraBlockSize)
		{
		case 4: QPnew += (p_Vid->type == I_SLICE)?
			DeltaQP4x4(EdgeCount[0],EdgeCount[1]): 
			((p_Vid->type == P_SLICE)?
				DeltaQP8x8(EdgeCount[0],EdgeCount[1]):  
				DeltaQP16x16(EdgeCount[0],EdgeCount[1]));
			break;
		case 8:	QPnew += (p_Vid->type == I_SLICE)?
				DeltaQP8x8(EdgeCount[0],EdgeCount[1]):  
				DeltaQP16x16(EdgeCount[0],EdgeCount[1]); 
			break;
		case 16:
		default:
			QPnew += DeltaQP16x16(EdgeCount[0],EdgeCount[1]);
			break;
		}
			 
	}             
	//------------
	// Return to the Main part - Transform & Quantisation
	return QPnew;	
}

int YGJ_Inter_QPSteering(int masterQP, int currMBqp, VideoParameters *p_Vid, InputParameters *p_Inp, Macroblock *currMB, imgpel **cur_img, imgpel **res_img, imgpel **prd_img, int opix_x, int mb_x, int InterBlockSize )
{	
	// Only interested if residual  and intra-predicted edges/lines detected. 
	int EdgeCount[2] = {0,0};  //!< Store the number edges detected in the 2x2 SSIM Map
	int QPnew = currMBqp;
	int QPcurrMB = currMBqp;
	
	int QPold = (p_Vid->type == I_SLICE)? masterQP : QPcurrMB;
	
	// Should only affect Inter frames	
	if ((QPcurrMB > 5 && QPold > 5) && (QPcurrMB < 45 && QPold < 45) && (p_Vid->type < I_SLICE))                           
	{  
		
		// Residual
		EdgeCount[1] = YGJ_LocalSSIMwMyoEdge(p_Vid, cur_img, res_img, opix_x, mb_x, InterBlockSize, InterBlockSize);
		// Predicted
		EdgeCount[0] = YGJ_LocalSSIMwMyoEdge(p_Vid, cur_img, prd_img, opix_x, mb_x,  InterBlockSize, InterBlockSize);
		
		// Predicted x2 + Residual - 1.
		QPnew += (EdgeCount[0] << 1) + EdgeCount[1] - 1;

		//Update QP
		currMB->qp = QPnew;
		update_qp(currMB);
	}             
	//------------
	// Return to the Main part - Transform & Quantisation
	return QPnew;	
}
