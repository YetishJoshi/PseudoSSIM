
/*!
 *************************************************************************************
 * \file img_dist_ssim.c
 *
 * \brief
 *    Compute structural similarity (SSIM) index using the encoded image and the reference image
 *
 * \author
 *    Main contributors (see contributors.h for copyright, address and affiliation details)
 *     - Woo-Shik Kim                    <wooshik.kim@usc.edu>
 *     - Zhen Li                         <zli@dolby.com> 
 *     - Alexis Michael Tourapis         <alexismt@ieee.org>
 *	Changes
 *    - Yetish Joshi	<y dot joshi at mdx dot ac dot uk>   Printed out Local SSIM Value     (22-Nov-2010)
 *    - Yetish Joshi	<y dot joshi at mdx dot ac dot uk>   Part of feature in config file OutputLocalSSIM     (28-Nov-2010)
 *    - Yetish Joshi	<y dot joshi at mdx dot ac dot uk>   Output results to a seperate file     (6-Dec-2010)
 *************************************************************************************
 */
#include "contributors.h"
#include "global.h"
#include "img_distortion.h"
#include "enc_statistics.h"

// Added by YGJ 25th July 2011 - In order Print out Bitmaps
#include <ygj_functions.h>

//#define UNBIASED_VARIANCE // unbiased estimation of the variance

float compute_ssim (VideoParameters *p_Vid, InputParameters *p_Inp, imgpel **refImg, imgpel **encImg, int height, int width, int win_height, int win_width, int comp)
{

	static const float K1 = 0.01f, K2 = 0.03f;
	float max_pix_value_sqd;
	float C1, C2;
	float win_pixels = (float) (win_width * win_height);
#ifdef UNBIASED_VARIANCE
	float win_pixels_bias = win_pixels - 1;
#else
	float win_pixels_bias = win_pixels;
#endif
	float mb_ssim, meanOrg, meanEnc;
	float varOrg, varEnc, covOrgEnc;
	int imeanOrg, imeanEnc, ivarOrg, ivarEnc, icovOrgEnc;
	float cur_distortion = 0.0;
	int i, j, n, m, win_cnt = 0;
	int overlapSize = p_Inp->SSIMOverlapSize;

	
    // Declare variable at the start before any C code.
	FILE *outfileLSSIM = NULL;

	//===========================
	// Tue 19th Apr 2011
	// Calc Difference (Diff) between Source (Ref) and Reconstructed (enc) then saving result as a greyscale bitmap
	//
	// Why not save the Ref and Enc as BMP as well? (YGJ 27th April 2011)
	
	FILE *fDiff  = NULL, *fRef = NULL, *fEnc = NULL, *fDiffTxt = NULL, *fRefTxt = NULL, *fEncTxt = NULL; //, //*fMyoFix = NULL; //, *fMyoZscore;
	unsigned char *imgDiff = NULL, *imgRef = NULL, *imgEnc = NULL; //, *imgMyoFix = NULL, *imgMyoZscore = NULL;
	int w = width;
	int h = height;
//	int filesize = 54 + 3*w*h;  //w is your image width, h is image height, both int

	//Difference
	int Diff;
		
	// http://www.cplusplus.com/reference/clibrary/cstring/strcat/
	char buffer[50], strDiff[80], strRef[80], strEnc[80]; //, strMyoFix[80]; //, strMyoZscore[80];
	//=======================

	//FILE *fPred, *fRes, *fLSSIM, *fLSSIMSobel, *fResSobel;

	// Bitmaps for 1) Prediction, 2) Residual (Uncompressed), 3) Prediction after LSSIM, 4) Prediction After LSSIM and Sobel Mask, 5) Residual after Sobel Mask
	//unsigned char *imgPred = NULL, *imgRes = NULL, *imgLSSIM = NULL, *imgLSSIMSobel = NULL, *imgResSobel = NULL;

	//char strPred[80], strRes[80], strLSSIM[80], strLSSIMSobel[80], strResSobel[80];

	//==========

	// Part of extracting and showing Macroblock info on Bitmap
	unsigned int mb_x = 0;
	unsigned int mb_y = 0;
	unsigned int mb_curr = 0;
	Macroblock* WorkingMB = NULL;
	int QPDiff;
	int ii; // for loop
	int b8x8mode[4];

        
    //------------------
    // YGJ 19th Jan 2013
    // from macroblock.c
        	
    Slice *currSlice = WorkingMB->p_Slice;
	int slice_type = currSlice->slice_type;
    
    //-----------------

	//int MyoSobel_Thres = 204;
	//int MyoSobel_Thres = 64;
	//int MyoSobel_Thres = 32;
	//int MyoSobel_Thres = 16;
	//int MyoSobel_Thres = p_Inp->MyoSobelThresh;
		
	//int iStdDev=0;
	//int mean=0;	
	//int SumofxSq=0; //(Total  of x)^2
	//int xSqSummed=0; //Total  of (x^2)
	//int Count = 0;
	//float variance=0;

	// It is a bit difficult to verify EdgeCount. This is because EdgeCount is first calculated in the Prediction and Residual Blocks separately. 
	// Whilst at this stage when working with the Reconstructed Frame (Post Quantisation) we are looking at the final product.
	// No point in using as it will need to stay in an array equivalent to the number of Macroblocks.
	// What information will this provide in txt format?
	//int postEdgeCount;


      //(p_Inp->LogDistSamples == TRUE)?
  //    SSIMSample_print_list()
  //    : 0;

    
    if (p_Vid->p_Inp->LogDistSamples)
    {
        SSIMSample_print_list();
        SSIMSample_head = NULL;
    }
	

	//===========================

	// Save the Local SSIM Values to Txt file
	
		// YGJ 6th Dec 2010 - Write to file instead of console
	// 1) Open file, 2) Write/Append Data 3) Close File
	if (p_Inp->OutputLocalSSIM)
	{
		outfileLSSIM = fopen( "LSSIM.txt", "a" );  // open "LSSIM.txt" (append mode)
		fprintf( outfileLSSIM, "About to begin outputting Local SSIM values\n" );
		// YGJ 17th Nov 2010
		// Print the local SSIM value 
		// Prints the Sliding Window (8x8)
		//if (p_Inp->OutputLocalSSIM)
		fprintf(outfileLSSIM, "Image Height:	%d	Image Width:	%d	Window Height:	%d	Window Width:	%d	Comp:	%d\n", height, width, win_height, win_width, comp );
	}

	
	//===========================
	
	
	
	
	max_pix_value_sqd = (float) (p_Vid->max_pel_value_comp[comp] * p_Vid->max_pel_value_comp[comp]);
	C1 = K1 * K1 * max_pix_value_sqd;
	C2 = K2 * K2 * max_pix_value_sqd;

	for (j = 0; j <= height - win_height; j += overlapSize)
	{
		for (i = 0; i <= width - win_width; i += overlapSize)
		{
			imeanOrg = 0;
			imeanEnc = 0; 
			ivarOrg  = 0;
			ivarEnc  = 0;
			icovOrgEnc = 0;

			for ( n = j;n < j + win_height;n ++)
			{
				for (m = i;m < i + win_width;m ++)
				{
					imeanOrg   += refImg[n][m];
					imeanEnc   += encImg[n][m];
					ivarOrg    += refImg[n][m] * refImg[n][m];
					ivarEnc    += encImg[n][m] * encImg[n][m];
					icovOrgEnc += refImg[n][m] * encImg[n][m];
				}
			}

			meanOrg = (float) imeanOrg / win_pixels;
			meanEnc = (float) imeanEnc / win_pixels;

			varOrg    = ((float) ivarOrg - ((float) imeanOrg) * meanOrg) / win_pixels_bias;
			varEnc    = ((float) ivarEnc - ((float) imeanEnc) * meanEnc) / win_pixels_bias;
			covOrgEnc = ((float) icovOrgEnc - ((float) imeanOrg) * meanEnc) / win_pixels_bias;

			mb_ssim  = (float) ((2.0 * meanOrg * meanEnc + C1) * (2.0 * covOrgEnc + C2));
			mb_ssim /= (float) (meanOrg * meanOrg + meanEnc * meanEnc + C1) * (varOrg + varEnc + C2);

			cur_distortion += mb_ssim;
			win_cnt++;
		// YGJ 17th Nov 2010
		// Print the local SSIM value 
		// Prints the local SSIM value from the Sliding Window (8x8)
		if (p_Inp->OutputLocalSSIM)
			fprintf(outfileLSSIM, "%1.5f	", mb_ssim);
		}
	// YGJ 17th Nov 2010
	// Print the local SSIM value
	// New line for the next row of local values to be printed out.
	if (p_Inp->OutputLocalSSIM)
		fprintf(outfileLSSIM, "\n");
	}

	cur_distortion /= (float) win_cnt;

	if (cur_distortion >= 1.0 && cur_distortion < 1.01) // avoid float accuracy problem at very low QP(e.g.2)
		cur_distortion = 1.0;

	//================================
	// YGJ 1st Dec 2010
	// Print the SSIM value for the given frame
	if (p_Inp->OutputLocalSSIM)
	{
		fprintf(outfileLSSIM,"The overall (average) SSIM value is	%1.5f\n\n", cur_distortion);
		fclose( outfileLSSIM );
	}

	//================================

	// For now stick with Luma only
	// where comp=0

	if ((comp==0) && (p_Inp->LumaDiffFrameBMP  == 1 || p_Inp->LumaDiffFrameTXT == 1))
	{


		// Tuesday 19th April 2011
		// Hijacking compute_ssim code with this piece of code to save the difference between the Source (Ref) and Reconstructed (Enc) as a bitmap, 
		// similar to how I.E Richardson shows in his book

		// using code from the internet 
		// http://stackoverflow.com/questions/2654480/writing-bmp-image-in-pure-c-c-without-other-libraries
		// and guides such as http://www.fortunecity.com/skyscraper/windows/364/bmpffrmt.html

		// From these sites it is possible to gather the following
		// 1) Bitmaps start from the bottom right of an image to the top left
		// This is shown by the code which starts by streaming to file the bottom of the image.
		// 2) Grey is when all the channels as the same colour
		// So the difference calculated will be applied to each channel, R, G and B
		// 3) The rows of data written to file must be multiples of four
		// The source code from stackoverflow forum accounts for this already

		// Yetish Joshi

		if( imgDiff )
			free( imgDiff );

		if( imgRef )
			free( imgRef );

		if( imgEnc )
			free( imgEnc );
	
		//if( imgMyoFix )
		//	free( imgMyoFix );
	
		//if( imgMyoZscore )
		//	free( imgMyoZscore );
	

		imgDiff = (unsigned char *)malloc(3*w*h);
		memset(imgDiff,0,sizeof(imgDiff));

		imgRef = (unsigned char *)malloc(3*w*h);
		memset(imgRef,0,sizeof(imgRef));

		imgEnc = (unsigned char *)malloc(3*w*h);
		memset(imgEnc,0,sizeof(imgEnc));
						
		//imgMyoFix = (unsigned char *)malloc(3*w*h);
		//memset(imgMyoFix,0,sizeof(imgMyoFix));

		//imgMyoZscore = (unsigned char *)malloc(3*w*h);
		//memset(imgMyoZscore,0,sizeof(imgMyoZscore));

		//--------

		if (p_Inp->LumaDiffFrameTXT  == 1 )
		{

			fDiffTxt = fopen( "LumaDiff.txt", "a" );  // open "LSSIM.txt" (append mode)
			fprintf( fDiffTxt, "Start of Diff Frame \n\n");
			fprintf( fDiffTxt, "Dimensions of Video Frame are %d (width) by %d (height)\n\n", width, height);

			fRefTxt = fopen( "LumaRef.txt", "a" );  // open "LSSIM.txt" (append mode)
			fprintf( fRefTxt, "Start of Ref Frame \n\n");
			fprintf( fRefTxt, "Dimensions of Video Frame are %d (width) by %d (height)\n\n", width, height);
		
			fEncTxt = fopen( "LumaEnc.txt", "a" );  // open "LSSIM.txt" (append mode)
			fprintf( fEncTxt, "Start of Enc Frame \n\n");
			fprintf( fEncTxt, "Dimensions of Video Frame are %d (width) by %d (height)\n\n", width, height);
		
		}

		//--------


		//Try to write/capture the rows in reverse as the BMP comes out inverted
		//no joy, shame
		for(i=0; i<w; i++)
		//for(i=w-1; i=0; --i)
		{
			for(j=0; j<h; j++)
			//for(j=h-1; j=0; --j)
			{
	
				Diff = (int)abs((refImg[j][i] - encImg[j][i]));

				//printf("When i = %d and j = %d the Difference between the Source (Ref) and Reconstructed (Enc) is %d \n", i, j, Diff);

				
				if (p_Inp->LumaDiffFrameTXT  == 1 )
				{
					fprintf( fDiffTxt, "%d ", Diff);
					fprintf( fRefTxt, "%d ", refImg[j][i]);
					fprintf( fEncTxt, "%d ", encImg[j][i]);
				}


		
				p_Vid->PicWidthInMbs;
				p_Vid->FrameHeightInMbs;
				p_Vid->FrameSizeInMbs;

				//if (((unsigned int)i/16) <= (p_Vid->PicWidthInMbs))
					mb_x = i/MB_BLOCK_SIZE;
				//else
				//  mb_x = 0;
												
				//if (((unsigned int)i/16) <= (p_Vid->FrameHeightInMbs))
					mb_y = j/MB_BLOCK_SIZE;
				//else
				//  mb_y = 0;

				//if (mb_y > 0)
					//mb_curr = ((mb_y-1) * (p_Vid->PicWidthInMbs)) + mb_x;
					mb_curr = mb_x + ((((p_Vid->FrameHeightInMbs) -1) - mb_y) * (p_Vid->PicWidthInMbs));
							
			
				if (mb_curr <= (p_Vid->FrameSizeInMbs))
				{
					WorkingMB  = &p_Vid->mb_data[mb_curr];          
				}
				else
					printf("MB Calc (%d) greater than FrameSizeInMBs (%d), img_dist_ssim.c", mb_curr, p_Vid->FrameSizeInMbs);

				//Difference compared to Frame Level QP not MasterQP.
				QPDiff = 16*(WorkingMB->qp - p_Vid->qp);

				////----------------
    //            // YGJ 19th Jan 2013


    //            // Based upon macroblock.c

    //            if (slice_type != I_SLICE)
	   //         {
		  //          if (WorkingMB->mb_type == P8x8)
		  //          {
			 //           for(i=0;i<4;++i)
			 //           {
				//            if (WorkingMB->b8x8[i].mode > 0)
				//	            ++cur_stats->mode_use[slice_type][(short) currMB->b8x8[i].mode];
				//            else
				//	            ++cur_stats->b8_mode_0_use[slice_type][currMB->luma_transform_size_8x8_flag];

				//            if (WorkingMB->b8x8[i].mode ==4)
				//            {
				//	            if ((currMB->luma_transform_size_8x8_flag && (currMB->cbp&15) != 0) || p_Inp->Transform8x8Mode == 2)
				//		            ++cur_stats->mode_use_transform[slice_type][4][1];
				//	            else
				//		            ++cur_stats->mode_use_transform[slice_type][4][0];
				//            }
			 //           }
		  //          }
		  //          else if (currMB->mb_type >= 0 && currMB->mb_type <=3 && ((currMB->cbp&15) != 0))
		  //          {
			 //           ++cur_stats->mode_use_transform[slice_type][currMB->mb_type][currMB->luma_transform_size_8x8_flag];
		  //          }
	   //         }
    //            
    //            
    //            
    //            
    //            //---------------
                
                // Unsure why these are unused?

				WorkingMB->subblock_x;
				WorkingMB->subblock_y;

                // Previous

				ii = (i%16)/8 + (j%16)/8;
				
				if (ii < 4 && ii > -1)
				{
					b8x8mode[ii]=WorkingMB->b8x8[ii].mode;
					////---
					//if (b8x8mode[ii] == IBLOCK)  //4x4 Red
					//	imgDiff[(i+((h-1)-j)*w)*3+2] = (unsigned char)Diff+128 + QPDiff;
					//else
					//	imgDiff[(i+((h-1)-j)*w)*3+2] = (unsigned char)(Diff*16);//+96;
					////---
					//if (b8x8mode[ii] == I8MB)	//8x8 Green
					//	imgDiff[(i+((h-1)-j)*w)*3+1] = (unsigned char)Diff+128 + QPDiff;
					//else
					//	imgDiff[(i+((h-1)-j)*w)*3+1] = (unsigned char)(Diff*16);//+96;
					////---
					//if ((b8x8mode[ii] == 0) && (WorkingMB->mb_type == I16MB) )	//16x16 Blue
					//	imgDiff[(i+((h-1)-j)*w)*3+0] = (unsigned char)Diff+128 + QPDiff;
					//else
					//	imgDiff[(i+((h-1)-j)*w)*3+0] = (unsigned char)(Diff*16);//+96;
					////---
					//------------------------------
					// Non-Intra
					if (b8x8mode[ii] == P8x8)  // Red - P8x8 
						imgDiff[(i+((h-1)-j)*w)*3+2] = (unsigned char)Diff+64 + QPDiff;
					else
						imgDiff[(i+((h-1)-j)*w)*3+2] = (unsigned char)(Diff*16);//+96;
					//---
					if (b8x8mode[ii] == P8x8)	//and  Green - - P8x8 
						imgDiff[(i+((h-1)-j)*w)*3+1] = (unsigned char)Diff+64 + QPDiff;
					else
						imgDiff[(i+((h-1)-j)*w)*3+1] = (unsigned char)(Diff*16);//+96;

										
					//------------------------------
					//Other P8x16
					if (b8x8mode[ii] == P8x16)  // Green 
						imgDiff[(i+((h-1)-j)*w)*3+1] = (unsigned char)Diff+96 + QPDiff;
					else
						imgDiff[(i+((h-1)-j)*w)*3+1] = (unsigned char)(Diff*16);//+96;
					//---
					if (b8x8mode[ii] == P8x16)	// and Blue
						imgDiff[(i+((h-1)-j)*w)*3+0] = (unsigned char)Diff+96 + QPDiff;
					else
						imgDiff[(i+((h-1)-j)*w)*3+0] = (unsigned char)(Diff*16);//+96;

                    					
                    //------------------------------
					//Other P16x8
					if (b8x8mode[ii] == P16x8)  // Green 
						imgDiff[(i+((h-1)-j)*w)*3+1] = (unsigned char)Diff+80 + QPDiff;
					else
						imgDiff[(i+((h-1)-j)*w)*3+1] = (unsigned char)(Diff*16);//+96;
					//---
					if (b8x8mode[ii] == P16x8)	// and Blue
						imgDiff[(i+((h-1)-j)*w)*3+0] = (unsigned char)Diff+80 + QPDiff;
					else
						imgDiff[(i+((h-1)-j)*w)*3+0] = (unsigned char)(Diff*16);//+96;
					

                                        
                    //------------------------------
					//Other P16x16
					if (b8x8mode[ii] == P16x16)  // Red 
						imgDiff[(i+((h-1)-j)*w)*3+2] = (unsigned char)Diff+112 + QPDiff;
					else
						imgDiff[(i+((h-1)-j)*w)*3+2] = (unsigned char)(Diff*16);//+96;
					//---
					if (b8x8mode[ii] == P16x16)	// and Blue
						imgDiff[(i+((h-1)-j)*w)*3+0] = (unsigned char)Diff+112 + QPDiff;
					else
						imgDiff[(i+((h-1)-j)*w)*3+0] = (unsigned char)(Diff*16);//+96;


					////------------------------------
                    //Sub MB
					if (b8x8mode[ii] > 3 && b8x8mode[ii] < 8)  // Red
						imgDiff[(i+((h-1)-j)*w)*3+0] = (unsigned char)Diff+160 + QPDiff;
					else
						imgDiff[(i+((h-1)-j)*w)*3+0] = (unsigned char)(Diff*16);//+96;
					//---
					if (b8x8mode[ii] > 3 && b8x8mode[ii] < 8)	// and Blue
						imgDiff[(i+((h-1)-j)*w)*3+2] = (unsigned char)Diff+160 + QPDiff;
					else
						imgDiff[(i+((h-1)-j)*w)*3+2] = (unsigned char)(Diff*16);//+96;

                    //======================================
                    //======================================
                    //======================================
                    //======================================
                    

                    // Non-Intra
					if (b8x8mode[ii] == P8x8)  // Red - P8x8 
						imgEnc[(i+((h-1)-j)*w)*3+2] = (unsigned char)encImg[j][i]+QPDiff;
					else
						imgEnc[(i+((h-1)-j)*w)*3+2] = (unsigned char)(encImg[j][i]/2);  
					//---
					if (b8x8mode[ii] == P8x8)	//and  Green - - P8x8 
						imgEnc[(i+((h-1)-j)*w)*3+1] = (unsigned char)encImg[j][i]+QPDiff;
					else
						imgEnc[(i+((h-1)-j)*w)*3+1] = (unsigned char)(encImg[j][i]/2);  

										
					//------------------------------
					//Other P8x16
					if (b8x8mode[ii] == P8x16)  // Green 
						imgEnc[(i+((h-1)-j)*w)*3+1] = (unsigned char)encImg[j][i]+QPDiff;
					else
						imgEnc[(i+((h-1)-j)*w)*3+1] = (unsigned char)(encImg[j][i]/2);  
					//---
					if (b8x8mode[ii] == P8x16)	// and Blue
						imgEnc[(i+((h-1)-j)*w)*3+0] = (unsigned char)encImg[j][i]+QPDiff;
					else
						imgEnc[(i+((h-1)-j)*w)*3+0] = (unsigned char)(encImg[j][i]/2);  

                    					
                    //------------------------------
					//Other P16x8
					if (b8x8mode[ii] == P16x8)  // Green 
						imgEnc[(i+((h-1)-j)*w)*3+1] = (unsigned char)encImg[j][i]+QPDiff;
					else
						imgEnc[(i+((h-1)-j)*w)*3+1] = (unsigned char)(encImg[j][i]/2);  
					//---
					if (b8x8mode[ii] == P16x8)	// and Blue
						imgEnc[(i+((h-1)-j)*w)*3+0] = (unsigned char)encImg[j][i]+QPDiff;
					else
						imgEnc[(i+((h-1)-j)*w)*3+0] = (unsigned char)(encImg[j][i]/2);  
					

                                        
                    //------------------------------
					//Other P16x16
					if (b8x8mode[ii] == P16x16)  // Red 
						imgEnc[(i+((h-1)-j)*w)*3+2] = (unsigned char)encImg[j][i]+QPDiff;
					else
						imgEnc[(i+((h-1)-j)*w)*3+2] = (unsigned char)(encImg[j][i]/2);  
					//---
					if (b8x8mode[ii] == P16x16)	// and Blue
						imgEnc[(i+((h-1)-j)*w)*3+0] = (unsigned char)encImg[j][i]+QPDiff;
					else
						imgEnc[(i+((h-1)-j)*w)*3+0] = (unsigned char)(encImg[j][i]/2);  


					////------------------------------
                    //Sub MB
					if (b8x8mode[ii] > 3 && b8x8mode[ii] < 8)  // Red
						imgEnc[(i+((h-1)-j)*w)*3+0] = (unsigned char)encImg[j][i]+QPDiff;
					else
						imgEnc[(i+((h-1)-j)*w)*3+0] = (unsigned char)(encImg[j][i]/2);  
					//---
					if (b8x8mode[ii] > 3 && b8x8mode[ii] < 8)	// and Blue
						imgEnc[(i+((h-1)-j)*w)*3+2] = (unsigned char)encImg[j][i]+QPDiff;
					else
						imgEnc[(i+((h-1)-j)*w)*3+2] = (unsigned char)(encImg[j][i]/2);  

				}
				else
					printf("Error: BMP with Mode type, ii Calculated to be %d \n", ii); 


				imgRef[(i+((h-1)-j)*w)*3+2] = (unsigned char)refImg[j][i];
				imgRef[(i+((h-1)-j)*w)*3+1] = (unsigned char)refImg[j][i];
				imgRef[(i+((h-1)-j)*w)*3+0] = (unsigned char)refImg[j][i];
												
				if (WorkingMB->mb_type == I4MB)
					imgEnc[(i+((h-1)-j)*w)*3+2] = (unsigned char)encImg[j][i]+QPDiff;
				else
					imgEnc[(i+((h-1)-j)*w)*3+2] = (unsigned char)(encImg[j][i]/2);

				if (WorkingMB->mb_type == I8MB)
					imgEnc[(i+((h-1)-j)*w)*3+1] = (unsigned char)encImg[j][i]+QPDiff;
				else
					imgEnc[(i+((h-1)-j)*w)*3+1] = (unsigned char)(encImg[j][i]/2);

				if (WorkingMB->mb_type == I16MB)
					imgEnc[(i+((h-1)-j)*w)*3+0] = (unsigned char)encImg[j][i]+QPDiff;   
				else
					imgEnc[(i+((h-1)-j)*w)*3+0] = (unsigned char)(encImg[j][i]/2);  

				////=========================================
				//// MyoSobel Fix with Threshold at 204

				//if (i > 0 && j > 0)
				//{
				//	if (4 * encImg[j][i] - 2*(encImg[j-1][i] + encImg[j][i-1]) > MyoSobel_Thres)			
				//	//EdgeCount++;
				//	{
				//		imgMyoFix[(i+((h-1)-j)*w)*3+2] = (unsigned char)encImg[j][i];
				//		imgMyoFix[(i+((h-1)-j)*w)*3+1] = (unsigned char)encImg[j][i];
				//		imgMyoFix[(i+((h-1)-j)*w)*3+0] = (unsigned char)encImg[j][i];   
				//	}
				//	else
				//	{
				//		imgMyoFix[(i+((h-1)-j)*w)*3+2] = (unsigned char)(encImg[j][i]/2);					
				//		imgMyoFix[(i+((h-1)-j)*w)*3+1] = (unsigned char)(encImg[j][i]/2);
				//		imgMyoFix[(i+((h-1)-j)*w)*3+0] = (unsigned char)(encImg[j][i]/2);  
				//	}
				//	
				//}
			}
		
			if (p_Inp->LumaDiffFrameTXT  == 1 )
			{
				fprintf( fDiffTxt, "\n");
				fprintf( fRefTxt, "\n");
				fprintf( fEncTxt, "\n");
			}
		}

		if (p_Inp->LumaDiffFrameTXT  == 1)
		{
			fprintf( fDiffTxt, "\n\nEnd of Diff Frame\n\n");
			fclose( fDiffTxt );

			fprintf( fRefTxt, "\n\nEnd of Ref Frame\n\n");
			fclose( fRefTxt );

			fprintf( fEncTxt, "\n\nEnd of Enc Frame\n\n");
			fclose( fEncTxt );
		}

		if (p_Inp->LumaDiffFrameBMP  == 1)
		{
	
			// http://www.cplusplus.com/reference/clibrary/cstring/strcat/

			//printf("About to write BMP, setting up the BMP file name \n"); 

			// From http://www.cplusplus.com/reference/clibrary/cstdio/sprintf/

			sprintf(buffer, "%d", (p_Vid->frame_num));

			strcpy (strDiff,"Luma_Diff_Frame_");
			strcat (strDiff, buffer);
			strcat (strDiff,".bmp");
	
			strcpy (strRef,"Luma_Ref_Frame_");
			strcat (strRef, buffer);
			strcat (strRef,".bmp");
	
			strcpy (strEnc,"Luma_Enc_Frame_");
			strcat (strEnc, buffer);
			strcat (strEnc,".bmp");
									
			//strcpy (strMyoFix,"Luma_MyoFix_Frame_");
			//strcat (strMyoFix, buffer);
			//strcat (strMyoFix,".bmp");

			//==================
					 	
			//// Write Diff Frame as BMP
			YGJ_WriteBMP(fDiff, strDiff, imgDiff, w, h);

			//// Write Ref Frame as BMP
			YGJ_WriteBMP(fRef, strRef, imgRef, w, h);
	
			//// Write Enc Frame as BMP
			YGJ_WriteBMP(fEnc, strEnc, imgEnc, w, h);
									
			////// Write Enc Frame as BMP
			//YGJ_WriteBMP(fMyoFix, strMyoFix, imgMyoFix, w, h);

		}
		//end of print/saving luma diff YGJ 27th April 2011
	} //end of if (comp=0)
		
	//================================	
	return cur_distortion;
}

/*!
 ************************************************************************
 * \brief
 *    Find SSIM for all three components
 ************************************************************************
 */
void find_ssim (VideoParameters *p_Vid, InputParameters *p_Inp, ImageStructure *ref, ImageStructure *src, DistMetric *metricSSIM)
{
	DistortionParams *p_Dist = p_Vid->p_Dist;
	FrameFormat *format = &ref->format;

	metricSSIM->value[0] = compute_ssim (p_Vid, p_Inp, ref->data[0], src->data[0], format->height[0], format->width[0], BLOCK_SIZE_8x8, BLOCK_SIZE_8x8, 0);
	// Chroma.
	if (format->yuv_format != YUV400)
	{     
		metricSSIM->value[1]  = compute_ssim (p_Vid, p_Inp, ref->data[1], src->data[1], format->height[1], format->width[1], p_Vid->mb_cr_size_y, p_Vid->mb_cr_size_x, 1);
		metricSSIM->value[2]  = compute_ssim (p_Vid, p_Inp, ref->data[2], src->data[2], format->height[1], format->width[1], p_Vid->mb_cr_size_y, p_Vid->mb_cr_size_x, 2);
	}

	{
		accumulate_average(metricSSIM,  p_Dist->frame_ctr);
		accumulate_avslice(metricSSIM,  p_Vid->type, p_Vid->p_Stats->frame_ctr[p_Vid->type]);
	}
}

