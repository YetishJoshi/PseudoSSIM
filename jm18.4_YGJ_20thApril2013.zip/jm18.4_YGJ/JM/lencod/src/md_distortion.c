
/*!
 ***************************************************************************
 * \file md_distortion.c
 *
 * \brief
 *    Main macroblock mode decision functions and helpers
 *
 **************************************************************************
 */

#include <math.h>
#include <limits.h>
#include <float.h>

#include "global.h"
#include "rdopt_coding_state.h"
#include "mb_access.h"
#include "intrarefresh.h"
#include "image.h"
#include "transform8x8.h"
#include "ratectl.h"
#include "mode_decision.h"
#include "fmo.h"
#include "me_umhex.h"
#include "me_umhexsmp.h"
#include "macroblock.h"
#include "mv_search.h"
#include "md_distortion.h"

// Added by YGJ 1st Nov 2011 - In order to have a SSIM Distortion Metric. SSE was becoming annoying.
#include <ygj_functions.h>
#include "me_distortion.h"

void setupDistortion(Slice *currSlice)
{
  currSlice->getDistortion = distortionSSE;
}

/*!
 ***********************************************************************
 * \brief
 *    compute generic SSE
 ***********************************************************************
 */
int64 compute_SSE(imgpel **imgRef, imgpel **imgSrc, int xRef, int xSrc, int ySize, int xSize)
{
  int i, j;
  imgpel *lineRef, *lineSrc;
  int64 distortion = 0;

  for (j = 0; j < ySize; j++)
  {
    lineRef = &imgRef[j][xRef];    
    lineSrc = &imgSrc[j][xSrc];

    for (i = 0; i < xSize; i++)
      distortion += iabs2( *lineRef++ - *lineSrc++ );
  }
  return distortion;
}

distblk compute_SSE_cr(imgpel **imgRef, imgpel **imgSrc, int xRef, int xSrc, int ySize, int xSize)
{
  int i, j;
  imgpel *lineRef, *lineSrc;
  distblk distortion = 0;

  for (j = 0; j < ySize; j++)
  {
    lineRef = &imgRef[j][xRef];    
    lineSrc = &imgSrc[j][xSrc];

    for (i = 0; i < xSize; i++)
      distortion += iabs2( *lineRef++ - *lineSrc++ );
  }

  return dist_scale(distortion);
}

/*!
 ***********************************************************************
 * \brief
 *    compute 16x16 SSE
 ***********************************************************************
 */
distblk compute_SSE16x16(imgpel **imgRef, imgpel **imgSrc, int xRef, int xSrc)
{
  int i, j;
  imgpel *lineRef, *lineSrc;
  distblk distortion = 0;

  for (j = 0; j < MB_BLOCK_SIZE; j++)
  {
    lineRef = &imgRef[j][xRef];    
    lineSrc = &imgSrc[j][xSrc];

    for (i = 0; i < MB_BLOCK_SIZE; i++)
      distortion += iabs2( *lineRef++ - *lineSrc++ );
  }

  return dist_scale(distortion);
}

distblk compute_SSE16x16_thres(imgpel **imgRef, imgpel **imgSrc, int xRef, int xSrc, distblk min_cost)
{
  int i, j;
  imgpel *lineRef, *lineSrc;
  distblk distortion = 0;
  int imin_cost = dist_down(min_cost);

  for (j = 0; j < MB_BLOCK_SIZE; j++)
  {
    lineRef = &imgRef[j][xRef];    
    lineSrc = &imgSrc[j][xSrc];

    for (i = 0; i < MB_BLOCK_SIZE; i++)
      distortion += iabs2( *lineRef++ - *lineSrc++ );
    if (distortion > imin_cost)
      return (min_cost);
  }

  return dist_scale(distortion);
}
/*!
 ***********************************************************************
 * \brief
 *    compute 8x8 SSE
 ***********************************************************************
 */
distblk compute_SSE8x8(imgpel **imgRef, imgpel **imgSrc, int xRef, int xSrc)
{
  int i, j;
  imgpel *lineRef, *lineSrc;
  distblk distortion = 0;

  for (j = 0; j < BLOCK_SIZE_8x8; j++)
  {
    lineRef = &imgRef[j][xRef];    
    lineSrc = &imgSrc[j][xSrc];

    for (i = 0; i < BLOCK_SIZE_8x8; i++)
      distortion += iabs2( *lineRef++ - *lineSrc++ );
  }

  return dist_scale(distortion);
}


/*!
 ***********************************************************************
 * \brief
 *    compute 4x4 SSE
 ***********************************************************************
 */
distblk compute_SSE4x4(imgpel **imgRef, imgpel **imgSrc, int xRef, int xSrc)
{
  int i, j;
  imgpel *lineRef, *lineSrc;
  distblk distortion = 0;

  for (j = 0; j < BLOCK_SIZE; j++)
  {
    lineRef = &imgRef[j][xRef];    
    lineSrc = &imgSrc[j][xSrc];

    for (i = 0; i < BLOCK_SIZE; i++)
      distortion += iabs2( *lineRef++ - *lineSrc++ );
  }

  return dist_scale(distortion);
}


//====================================================

//==========================================================================
// Based upon md_distotion.c

//
///*!
// ***********************************************************************
// * \brief
// *    compute 16x16 SSE
// ***********************************************************************
// */
// YGJ 27th Feb 2012 - Despite Distortion being a type distblk, the function chosen determine PSeudoSSIM is returning type int.
//distblk compute_SSIM16x16(imgpel **imgRef, imgpel **imgSrc, int xRef, int xSrc) 

// YGJ 23rd April 2012 - Updated to support y co-ordinates
distblk compute_SSIM16x16(imgpel **imgRef, imgpel **imgSrc, int xRef, int yRef, int xSrc, int ySrc)
{ 		
	int i, j;
	imgpel *lineRef, *lineSrc;
	distblk distortion = 0;
	distblk distortion_SSE = 0;
	distblk distortion_SSIM = 0;
	//int imin_cost = dist_down(min_cost);
	//----
	VideoParameters *p_Vid = p_Enc->p_Vid;
	
	//distblk dist_SSE = 0; 
	//distblk dist_SSIM = 1;

	for (j = 0; j < MB_BLOCK_SIZE; j++)
	{
		lineRef = &imgRef[j+yRef][xRef];    
		lineSrc = &imgSrc[j+ySrc][xSrc];

		for (i = 0; i < MB_BLOCK_SIZE; i++)
			distortion_SSE += iabs2( *lineRef++ - *lineSrc++ );
	}

	distortion = ((distortion_SSE < YGJ_MIN16x16) || (distortion_SSE > YGJ_MAX16x16 ))?
	distortion_SSE
	: // YGJ 12th Sept 2012 - Only substitute 1/8th of SSE for PseudoSSIM and only when within bounds.		
	distortion_SSE - (distortion_SSE >> YGJ_SSIMSub) + ((YGJ_SSIMDistMetric_dstblk(p_Vid, &imgRef[yRef], &imgSrc[ySrc], xRef, xSrc, MB_BLOCK_SIZE, dist_down(distortion_SSE))) >> YGJ_SSIMSub) ;
		
	return dist_scale(distortion);
}


// YGJ 27th Feb 2012 - Despite Distortion being a type distblk, the function chosen determine PSeudoSSIM is returning type int.
//distblk compute_SSIM16x16_thres(imgpel **imgRef, imgpel **imgSrc, int xRef, int xSrc, distblk min_cost) 

// YGJ 23rd April 2012 - Updated to support y coord
distblk compute_SSIM16x16_thres(imgpel **imgRef, imgpel **imgSrc, int xRef, int yRef, int xSrc, int ySrc, distblk min_cost)
{		
	int i, j;
	imgpel *lineRef, *lineSrc;
	distblk distortion = 0;
	distblk distortion_SSE = 0;
	distblk distortion_SSIM = 0;
	int imin_cost = dist_down(min_cost);
	//----
	VideoParameters *p_Vid = p_Enc->p_Vid;

	for (j = 0; j < MB_BLOCK_SIZE; j++)
	{
		lineRef = &imgRef[j+yRef][xRef];    
		lineSrc = &imgSrc[j+ySrc][xSrc];

		for (i = 0; i < MB_BLOCK_SIZE; i++)
			distortion_SSE += iabs2( *lineRef++ - *lineSrc++ );
	}
		
	distortion = ((distortion_SSE < YGJ_MIN16x16) || (distortion_SSE > YGJ_MAX16x16 ))?
		distortion_SSE
		: // YGJ 12th Sept 2012 - Only substitute 1/8th of SSE for PseudoSSIM and only when within bounds.		
		distortion_SSE - (distortion_SSE >> YGJ_SSIMSub) + ((YGJ_SSIMDistMetric_dstblk(p_Vid, &imgRef[yRef], &imgSrc[ySrc], xRef, xSrc, MB_BLOCK_SIZE, dist_down(distortion_SSE))) >> YGJ_SSIMSub) ;

	//// Avoid SSIM if no errors detected.

	if (distortion > imin_cost)
		return (min_cost);

	//if (distortion == distortion_SSE && distortion > YGJ_MAX16x16) //&& distortion_SSE < YGJ_MAX16x16 )
	//	printf("output values, compute_SSIM16x16_thres, distortion, %d, distortion_SSE, %d,  distortion_SSIM, %d \n", distortion, distortion_SSE, distortion_SSIM);
	
	return dist_scale(distortion);
}
///*!
// ***********************************************************************
// * \brief
// *    compute 8x8 SSIM
// ***********************************************************************
// */
// YGJ 27th Feb 2012 - Despite Distortion being a type distblk, the function chosen determine PSeudoSSIM is returning type int.
//distblk compute_SSIM8x8(imgpel **imgRef, imgpel **imgSrc, int xRef, int xSrc) 


// YGJ 23rd April 2012 - Updated to support y coord
distblk compute_SSIM8x8(imgpel **imgRef, imgpel **imgSrc, int xRef, int yRef, int xSrc, int ySrc)
{ 		
	int i, j;
	imgpel *lineRef, *lineSrc;
	distblk distortion = 0;
	distblk distortion_SSE = 0;
	distblk distortion_SSIM = 0;
	VideoParameters *p_Vid = p_Enc->p_Vid;

	for (j = 0; j < BLOCK_SIZE_8x8; j++)
	{
		lineRef = &imgRef[j+yRef][xRef];    
		lineSrc = &imgSrc[j+ySrc][xSrc];

		for (i = 0; i < BLOCK_SIZE_8x8; i++)
			distortion_SSE += iabs2( *lineRef++ - *lineSrc++ );
	}

			
	distortion = ((distortion_SSE < YGJ_MIN8x8) || (distortion_SSE > YGJ_MAX8x8 ))?
		distortion_SSE
		: // YGJ 12th Sept 2012 - Only substitute 1/8th of SSE for PseudoSSIM and only when within bounds.		
		distortion_SSE - (distortion_SSE >> YGJ_SSIMSub) + ((YGJ_SSIMDistMetric_dstblk(p_Vid, &imgRef[yRef], &imgSrc[ySrc], xRef, xSrc, BLOCK_SIZE_8x8, dist_down(distortion_SSE))) >> YGJ_SSIMSub) ;
	
	//if (distortion == distortion_SSE && distortion > YGJ_MAX8x8 ) //&& distortion_SSE < YGJ_MAX8x8 )
 // 	printf("output values, compute_SSIM8x8, distortion, %d, distortion_SSE, %d,  distortion_SSIM, %d \n", distortion, distortion_SSE, distortion_SSIM);

	return dist_scale(distortion);

	//return dist_scale(YGJ_SSIMDistMetric_dstblk(p_Enc->p_Vid, imgRef, imgSrc, xRef, xSrc, 8, 8, 0)); 
}

///*!
// ***********************************************************************
// * \brief
// *    compute 4x4 SSIM
// ***********************************************************************
// */
// YGJ 27th Feb 2012 - Despite Distortion being a type distblk, the function chosen determine PSeudoSSIM is returning type int.
//distblk compute_SSIM4x4(imgpel **imgRef, imgpel **imgSrc, int xRef, int xSrc)  

// YGJ 23rd April 2012 - Updated to support y coord
distblk compute_SSIM4x4(imgpel **imgRef, imgpel **imgSrc, int xRef, int yRef, int xSrc, int ySrc)
{ 
		
	int i, j;
	imgpel *lineRef, *lineSrc;
	distblk distortion = 0;
	distblk distortion_SSE = 0;
	distblk distortion_SSIM = 0;
	//distblk dist_SSE = 0;
	//distblk dist_SSIM = 0;
	VideoParameters *p_Vid = p_Enc->p_Vid;

	for (j = 0; j < BLOCK_SIZE; j++)
	{
		lineRef = &imgRef[j+yRef][xRef];    
		lineSrc = &imgSrc[j+ySrc][xSrc];

		for (i = 0; i < BLOCK_SIZE; i++)
			distortion_SSE += iabs2( *lineRef++ - *lineSrc++ );
	}

	distortion = ((distortion_SSE < YGJ_MIN4x4) || (distortion_SSE > YGJ_MAX4x4 ))?
	distortion_SSE
	: // YGJ 12th Sept 2012 - Only substitute 1/8th of SSE for PseudoSSIM and only when within bounds.		
	distortion_SSE - (distortion_SSE >> YGJ_SSIMSub) + ((YGJ_SSIMDistMetric_dstblk(p_Vid, &imgRef[yRef], &imgSrc[ySrc], xRef, xSrc, BLOCK_SIZE, dist_down(distortion_SSE))) >> YGJ_SSIMSub) ;

	// YGJ 10th July 2012 - Investigating why when RDOQ is disabled P and B frames double in size. Not good!
	//if (distortion == distortion_SSE && distortion > YGJ_MAX4x4 )//&& distortion_SSE < YGJ_MAX4x4 )
	//	printf("output values, compute_SSIM4x4, distortion, %d, distortion_SSE, %d,  distortion_SSIM, %d \n", distortion, distortion_SSE, distortion_SSIM);

	return dist_scale(distortion);

}


//====================================================


//====================================================

//==========================================================================
// Based upon md_distotion.c
// compute_SSIMwSATD

//
///*!
// ***********************************************************************
// * \brief
// *    compute 16x16 SSE
// ***********************************************************************
// */
// YGJ 27th Feb 2012 - Despite Distortion being a type distblk, the function chosen determine PSeudoSSIM is returning type int.
//distblk compute_SSIM16x16(imgpel **imgRef, imgpel **imgSrc, int xRef, int xSrc) 

// YGJ 23rd April 2012 - Updated to support y co-ordinates
// YGJ 15th March  - expected to be used when RDCost_for_macroblocks(...) calls getDistortion,  and  when SSIMDistMetric is enabled.
//distblk compute_SSIMwSATD16x16(imgpel **imgRef, imgpel **imgSrc, int xRef, int yRef, int xSrc, int ySrc)
distblk compute_SSIMwSATD16x16(imgpel **imgRef, imgpel **imgSrc, int xRef, int xSrc)
{ 		
	int i=0, j=0, ii=0, jj=0;
	imgpel *lineRef, *lineSrc;
	//distblk distortion = 0;
	//int distortion_SATD = 0;
    int distortion_SSIM = 0;    
	
    //short diff256[256];
	//short *diff = &diff256[0];

    int idist_SATD = -1;
    short diff16[16];
	short *diff = &diff16[0];


	//int imin_cost = dist_down(min_cost);
	//----
	VideoParameters *p_Vid = p_Enc->p_Vid;

	//distblk dist_SSE = 0; 
	//distblk dist_SSIM = 1;

	//for (j = 0; j < MB_BLOCK_SIZE; +4)//j++)
	//{
	//	lineRef = &imgRef[j+yRef][xRef];    
	//	lineSrc = &imgSrc[j+ySrc][xSrc];

	//	for (i = 0; i < MB_BLOCK_SIZE; +4)//i++)
	//		//distortion_SSE += iabs2( *lineRef++ - *lineSrc++ );
 //          // diff += *lineRef++ - *lineSrc++ ;
 //          distortion += compute_SSIMwSATD4x4(&lineRef, &lineSrc, i, 0, i , 0);
	//}

    //printf("compute_SSIMwSATD16x16 - Pre YGJ_SSIMDistMetric.\n");
    	  
    for (jj = 0; jj < MB_BLOCK_SIZE; jj = jj + BLOCK_SIZE )	 
    {   
        if (p_Vid->p_Inp->LogDistSamples == TRUE)        
        {
            for (ii = 0; ii < MB_BLOCK_SIZE; ii = ii + BLOCK_SIZE )	 
            {

                diff = &diff16[0]; // resets the counter

	            for (j = jj; j < jj + BLOCK_SIZE; j++)
	            {
		            lineRef = &imgRef[j][xRef];    
		            lineSrc = &imgSrc[j][xSrc];

		            //for (i = ii; i < ii + BLOCK_SIZE; i++)
			            //distortion_SSE += iabs2( *lineRef++ - *lineSrc++ );
                    *diff++ = *lineRef++ - *lineSrc++;
                    *diff++ = *lineRef++ - *lineSrc++;
                    *diff++ = *lineRef++ - *lineSrc++;                           
                    *diff++ = *lineRef++ - *lineSrc++;
                }

	            idist_SATD = HadamardSAD4x4 (diff16);
                //dist_down(distortion8x8SATD (diff64 , DISTBLK_MAX));
	
                //idist_SSIM = YGJ_SSIMDistMetric(p_Vid, cur_img, mpr8x8, pic_opix_x, 0, BLOCK_SIZE_8x8, idist_SATD);
                distortion_SSIM += YGJ_SSIMDistMetric(p_Vid, &imgRef[jj], &imgSrc[jj], xRef+ii, xSrc+ii, BLOCK_SIZE, idist_SATD);
            }

        }
        else
        {            
            // called PseudoSSIM first then if out of range then SATD
            //idist_SSIM = YGJ_SSIMDistMetric(p_Vid, cur_img, mpr8x8, pic_opix_x, 0, BLOCK_SIZE_8x8, -1);
            distortion_SSIM += YGJ_SSIMDistMetric(p_Vid, &imgRef[jj], &imgSrc[jj], xRef, xSrc, BLOCK_SIZE, -1);
            distortion_SSIM += YGJ_SSIMDistMetric(p_Vid, &imgRef[jj], &imgSrc[jj], xRef+4, xSrc+4, BLOCK_SIZE, -1);
            distortion_SSIM += YGJ_SSIMDistMetric(p_Vid, &imgRef[jj], &imgSrc[jj], xRef+8, xSrc+8, BLOCK_SIZE, -1);
            distortion_SSIM += YGJ_SSIMDistMetric(p_Vid, &imgRef[jj], &imgSrc[jj], xRef+12, xSrc+12, BLOCK_SIZE, -1);
            
        }
        
    }

    //printf("compute_SSIMwSATD16x16 - Post YGJ_SSIMDistMetric.\n");

    return dist_scale((distblk) distortion_SSIM);

    // Since compute_SSIMwSATD4x4 returns as distblk therefore no need to scale.
    //return distortion;

	//distortion = ((distortion_SSE < YGJ_MIN16x16) || (distortion_SSE > YGJ_MAX16x16 ))?
	//distortion_SSE
	//: // YGJ 12th Sept 2012 - Only substitute 1/8th of SSE for PseudoSSIM and only when within bounds.		
	//distortion_SSE - (distortion_SSE >> YGJ_SSIMSub) + ((YGJ_SSIMDistMetric_dstblk(p_Vid, &imgRef[yRef], &imgSrc[ySrc], xRef, xSrc, MB_BLOCK_SIZE, dist_down(distortion_SSE))) >> YGJ_SSIMSub) ;
		
	//return dist_scale(distortion);
}


// YGJ 27th Feb 2012 - Despite Distortion being a type distblk, the function chosen determine PSeudoSSIM is returning type int.
//distblk compute_SSIM16x16_thres(imgpel **imgRef, imgpel **imgSrc, int xRef, int xSrc, distblk min_cost) 

// YGJ 23rd April 2012 - Updated to support y coord
distblk compute_SSIMwSATD16x16_thres(imgpel **imgRef, imgpel **imgSrc, int xRef, int xSrc, distblk min_cost)
{		
	int i=0, j=0, ii=0, jj=0;
	imgpel *lineRef, *lineSrc;
	//distblk distortion = 0;
	//distblk distortion_SSE = 0;
	int distortion_SSIM = 0;
	int imin_cost = dist_down(min_cost);
    int idist_cost = 0;
            
    int idist_SATD = -1;
    short diff16[16];
	short *diff = &diff16[0];

	//----
	VideoParameters *p_Vid = p_Enc->p_Vid;

	//for (j = 0; j < MB_BLOCK_SIZE; j++)
	//{
	//	lineRef = &imgRef[j+yRef][xRef];    
	//	lineSrc = &imgSrc[j+ySrc][xSrc];

	//	for (i = 0; i < MB_BLOCK_SIZE; i++)
	//		//distortion_SSE += iabs2( *lineRef++ - *lineSrc++ );
 //           distortion += compute_SSIMwSATD4x4(&lineRef, &lineSrc, i, 0, i , 0);
	//}
	//
 //   idist_cost = dist_down(distortion);

    	  
    for (jj = 0; jj < MB_BLOCK_SIZE; jj = jj + BLOCK_SIZE )	 
    {   
        if (p_Vid->p_Inp->LogDistSamples == TRUE)        
        {
            for (ii = 0; ii < MB_BLOCK_SIZE; ii = ii + BLOCK_SIZE )	 
            {

                diff = &diff16[0]; // resets the counter

	            for (j = jj; j < jj + BLOCK_SIZE; j++)
	            {
		            lineRef = &imgRef[j][xRef];    
		            lineSrc = &imgSrc[j][xSrc];

		            //for (i = ii; i < ii + BLOCK_SIZE; i++)
			            //distortion_SSE += iabs2( *lineRef++ - *lineSrc++ );
                    *diff++ = *lineRef++ - *lineSrc++;
                    *diff++ = *lineRef++ - *lineSrc++;
                    *diff++ = *lineRef++ - *lineSrc++;                           
                    *diff++ = *lineRef++ - *lineSrc++;
                }

	            idist_SATD = HadamardSAD4x4 (diff16);
                //dist_down(distortion8x8SATD (diff64 , DISTBLK_MAX));
	
                //idist_SSIM = YGJ_SSIMDistMetric(p_Vid, cur_img, mpr8x8, pic_opix_x, 0, BLOCK_SIZE_8x8, idist_SATD);
                distortion_SSIM += YGJ_SSIMDistMetric(p_Vid, &imgRef[jj], &imgSrc[jj], xRef+ii, xSrc+ii, BLOCK_SIZE, idist_SATD);
            }

        }
        else
        {            
            // called PseudoSSIM first then if out of range then SATD
            //idist_SSIM = YGJ_SSIMDistMetric(p_Vid, cur_img, mpr8x8, pic_opix_x, 0, BLOCK_SIZE_8x8, -1);
            distortion_SSIM += YGJ_SSIMDistMetric(p_Vid, &imgRef[jj], &imgSrc[jj], xRef, xSrc, BLOCK_SIZE, -1);
            distortion_SSIM += YGJ_SSIMDistMetric(p_Vid, &imgRef[jj], &imgSrc[jj], xRef+4, xSrc+4, BLOCK_SIZE, -1);
            distortion_SSIM += YGJ_SSIMDistMetric(p_Vid, &imgRef[jj], &imgSrc[jj], xRef+8, xSrc+8, BLOCK_SIZE, -1);
            distortion_SSIM += YGJ_SSIMDistMetric(p_Vid, &imgRef[jj], &imgSrc[jj], xRef+12, xSrc+12, BLOCK_SIZE, -1);
            
        }
        
    }

    return ( idist_cost > imin_cost? min_cost 
            : dist_scale((distblk) distortion_SSIM));

	//distortion = ((distortion_SSE < YGJ_MIN16x16) || (distortion_SSE > YGJ_MAX16x16 ))?
	//	distortion_SSE
	//	: // YGJ 12th Sept 2012 - Only substitute 1/8th of SSE for PseudoSSIM and only when within bounds.		
	//	distortion_SSE - (distortion_SSE >> YGJ_SSIMSub) + ((YGJ_SSIMDistMetric_dstblk(p_Vid, &imgRef[yRef], &imgSrc[ySrc], xRef, xSrc, MB_BLOCK_SIZE, dist_down(distortion_SSE))) >> YGJ_SSIMSub) ;

	//// Avoid SSIM if no errors detected.

	//if (distortion > imin_cost)
	//	return (min_cost);

	//if (distortion == distortion_SSE && distortion > YGJ_MAX16x16) //&& distortion_SSE < YGJ_MAX16x16 )
	//	printf("output values, compute_SSIM16x16_thres, distortion, %d, distortion_SSE, %d,  distortion_SSIM, %d \n", distortion, distortion_SSE, distortion_SSIM);
	
	//return dist_scale(distortion);
}
///*!
// ***********************************************************************
// * \brief
// *    compute 8x8 SSIM
// ***********************************************************************
// */
// YGJ 27th Feb 2012 - Despite Distortion being a type distblk, the function chosen determine PSeudoSSIM is returning type int.
//distblk compute_SSIM8x8(imgpel **imgRef, imgpel **imgSrc, int xRef, int xSrc) 


// YGJ 23rd April 2012 - Updated to support y coord
// YGJ 15th March 2013 - Based on compute_ssimwsatd8x8_cost (transform8x8.c) and compute_SSIM8x8
distblk compute_SSIMwSATD8x8(imgpel **imgRef, imgpel **imgSrc, int xRef, int xSrc)
{ 		
	int i, j;
	imgpel *lineRef, *lineSrc;
	//distblk distortion = 0;
	//distblk distortion_SSE = 0;
	distblk distortion_SSIM = 0;
        	
    int idist_SATD = -1;
	//int idist_SSIM = -1; //One8x8SSIM;
        
	short diff64[64];
	short *diff = &diff64[0];

	VideoParameters *p_Vid = p_Enc->p_Vid;


    // YGJ 13th March 2013 - Simplified with Log support    
    //if (p_Vid->p_Inp->ModeDecisionMetric == ERROR_SSIMwSATD)
    if (p_Vid->p_Inp->LogDistSamples == TRUE)        
    {
	    for (j = 0; j < BLOCK_SIZE_8x8; j++)
	    {
		    lineRef = &imgRef[j][xRef];    
		    lineSrc = &imgSrc[j][xSrc];

		    for (i = 0; i < BLOCK_SIZE_8x8; i++)
			    //distortion_SSE += iabs2( *lineRef++ - *lineSrc++ );
                *diff++ = *lineRef++ - *lineSrc++;
	    }

	    idist_SATD = HadamardSAD8x8 (diff64);
        //dist_down(distortion8x8SATD (diff64 , DISTBLK_MAX));
	
        //idist_SSIM = YGJ_SSIMDistMetric(p_Vid, cur_img, mpr8x8, pic_opix_x, 0, BLOCK_SIZE_8x8, idist_SATD);
        distortion_SSIM = YGJ_SSIMDistMetric_dstblk(p_Vid, imgRef, imgSrc, xRef, xSrc, BLOCK_SIZE_8x8, idist_SATD);
    }
    else
    {
        // called PseudoSSIM first then if out of range then SATD
        //idist_SSIM = YGJ_SSIMDistMetric(p_Vid, cur_img, mpr8x8, pic_opix_x, 0, BLOCK_SIZE_8x8, -1);
        distortion_SSIM = YGJ_SSIMDistMetric_dstblk(p_Vid, imgRef, imgSrc, xRef, xSrc, BLOCK_SIZE_8x8, -1);
    }

    return distortion_SSIM;

	//		
	//distortion = ((distortion_SSE < YGJ_MIN8x8) || (distortion_SSE > YGJ_MAX8x8 ))?
	//	distortion_SSE
	//	: // YGJ 12th Sept 2012 - Only substitute 1/8th of SSE for PseudoSSIM and only when within bounds.		
	//	distortion_SSE - (distortion_SSE >> YGJ_SSIMSub) + ((YGJ_SSIMDistMetric_dstblk(p_Vid, &imgRef[yRef], &imgSrc[ySrc], xRef, xSrc, BLOCK_SIZE_8x8, dist_down(distortion_SSE))) >> YGJ_SSIMSub) ;
	//
	//if (distortion == distortion_SSE && distortion > YGJ_MAX8x8 ) //&& distortion_SSE < YGJ_MAX8x8 )
 // 	printf("output values, compute_SSIM8x8, distortion, %d, distortion_SSE, %d,  distortion_SSIM, %d \n", distortion, distortion_SSE, distortion_SSIM);

	//return dist_scale(idist_SSIM);

	//return dist_scale(YGJ_SSIMDistMetric_dstblk(p_Enc->p_Vid, imgRef, imgSrc, xRef, xSrc, 8, 8, 0)); 
}

///*!
// ***********************************************************************
// * \brief
// *    compute 4x4 SSIM
// ***********************************************************************
// */
// YGJ 27th Feb 2012 - Despite Distortion being a type distblk, the function chosen determine PSeudoSSIM is returning type int.
//distblk compute_SSIM4x4(imgpel **imgRef, imgpel **imgSrc, int xRef, int xSrc)  

// YGJ 23rd April 2012 - Updated to support y coord
distblk compute_SSIMwSATD4x4(imgpel **imgRef, imgpel **imgSrc, int xRef, int xSrc)
{ 
		
	int i, j;
	imgpel *lineRef, *lineSrc;
	//distblk distortion = 0;
	//distblk distortion_SSE = 0;
	//distblk distortion_SSIM = 0;
	//distblk dist_SSE = 0;
	//distblk dist_SSIM = 0;

    distblk distortion_SSIM = 0;
    int idist_SATD = -1;
    short diff16[16];
	short *diff = &diff16[0];

	VideoParameters *p_Vid = p_Enc->p_Vid;

        // YGJ 13th March 2013 - Simplified with Log support    
    //if (p_Vid->p_Inp->ModeDecisionMetric == ERROR_SSIMwSATD)
    if (p_Vid->p_Inp->LogDistSamples == TRUE)        
    {
	    for (j = 0; j < BLOCK_SIZE; j++)
	    {
		    lineRef = &imgRef[j][xRef];    
		    lineSrc = &imgSrc[j][xSrc];

		    for (i = 0; i < BLOCK_SIZE; i++)
			    //distortion_SSE += iabs2( *lineRef++ - *lineSrc++ );                        
                *diff++ = *lineRef++ - *lineSrc++;	        
        }

	    idist_SATD = HadamardSAD8x8 (diff16);
        //dist_down(distortion8x8SATD (diff64 , DISTBLK_MAX));
	
        //idist_SSIM = YGJ_SSIMDistMetric(p_Vid, cur_img, mpr8x8, pic_opix_x, 0, BLOCK_SIZE_8x8, idist_SATD);
        distortion_SSIM = YGJ_SSIMDistMetric_dstblk(p_Vid, imgRef, imgSrc, xRef, xSrc, BLOCK_SIZE, idist_SATD);
    }
    else
    {
        // called PseudoSSIM first then if out of range then SATD
        //idist_SSIM = YGJ_SSIMDistMetric(p_Vid, cur_img, mpr8x8, pic_opix_x, 0, BLOCK_SIZE_8x8, -1);
        distortion_SSIM = YGJ_SSIMDistMetric_dstblk(p_Vid, imgRef, imgSrc, xRef, xSrc, BLOCK_SIZE, -1);
    }

    return distortion_SSIM;

	//distortion = ((distortion_SSE < YGJ_MIN4x4) || (distortion_SSE > YGJ_MAX4x4 ))?
	//distortion_SSE
	//: // YGJ 12th Sept 2012 - Only substitute 1/8th of SSE for PseudoSSIM and only when within bounds.		
	//distortion_SSE - (distortion_SSE >> YGJ_SSIMSub) + ((YGJ_SSIMDistMetric_dstblk(p_Vid, &imgRef[yRef], &imgSrc[ySrc], xRef, xSrc, BLOCK_SIZE, dist_down(distortion_SSE))) >> YGJ_SSIMSub) ;

	//// YGJ 10th July 2012 - Investigating why when RDOQ is disabled P and B frames double in size. Not good!
	////if (distortion == distortion_SSE && distortion > YGJ_MAX4x4 )//&& distortion_SSE < YGJ_MAX4x4 )
	////	printf("output values, compute_SSIM4x4, distortion, %d, distortion_SSE, %d,  distortion_SSIM, %d \n", distortion, distortion_SSE, distortion_SSIM);

	//return dist_scale(distortion);

}


//====================================================


/*!
*************************************************************************************
* \brief
*    SSE distortion calculation for a macroblock
*************************************************************************************
*/
distblk distortionSSE(Macroblock *currMB) 
{
  VideoParameters *p_Vid = currMB->p_Vid;
  InputParameters *p_Inp = currMB->p_Inp;
  distblk distortionY = 0;
  distblk distortionCr[2] = {0, 0};

  // LUMA
  //distortionY = compute_SSE16x16(&p_Vid->pCurImg[currMB->opix_y], &p_Vid->enc_picture->p_curr_img[currMB->pix_y], currMB->pix_x, currMB->pix_x);

  distortionY = currMB->p_Inp->SSIMDistMetric == 1 ? 	
      //compute_SSIMwSATD16x16(p_Vid->pCurImg, p_Vid->enc_picture->p_curr_img, currMB->pix_x, currMB->opix_y, currMB->pix_x, currMB->pix_y)
      //compute_SSIM16x16(p_Vid->pCurImg, p_Vid->enc_picture->p_curr_img, currMB->pix_x, currMB->opix_y, currMB->pix_x, currMB->pix_y)
	  compute_SSIMwSATD16x16(&p_Vid->pCurImg[currMB->opix_y], &p_Vid->enc_picture->p_curr_img[currMB->pix_y], currMB->pix_x, currMB->pix_x)
      : compute_SSE16x16(&p_Vid->pCurImg[currMB->opix_y], &p_Vid->enc_picture->p_curr_img[currMB->pix_y], currMB->pix_x, currMB->pix_x);
	

  // CHROMA
  if ((p_Vid->yuv_format != YUV400) && (p_Inp->separate_colour_plane_flag == 0))
  {
    distortionCr[0] = compute_SSE_cr(&p_Vid->pImgOrg[1][currMB->opix_c_y], &p_Vid->enc_picture->imgUV[0][currMB->pix_c_y], currMB->pix_c_x, currMB->pix_c_x, p_Vid->mb_cr_size_y, p_Vid->mb_cr_size_x);
    distortionCr[1] = compute_SSE_cr(&p_Vid->pImgOrg[2][currMB->opix_c_y], &p_Vid->enc_picture->imgUV[1][currMB->pix_c_y], currMB->pix_c_x, currMB->pix_c_x, p_Vid->mb_cr_size_y, p_Vid->mb_cr_size_x);
  }
#if JCOST_OVERFLOWCHECK //overflow checking;
  if(distortionY * p_Inp->WeightY + distortionCr[0] * p_Inp->WeightCb + distortionCr[1] * p_Inp->WeightCr > DISTBLK_MAX)
  {
    printf("Overflow: %s : %d \n MB: %d, Value: %lf\n", __FILE__, __LINE__, currMB->mbAddrX, (distortionY * p_Inp->WeightY + distortionCr[0] * p_Inp->WeightCb + distortionCr[1] * p_Inp->WeightCr));
    exit(-1);
  }
#endif //end;
  return (distblk)( distortionY * p_Inp->WeightY + distortionCr[0] * p_Inp->WeightCb + distortionCr[1] * p_Inp->WeightCr );
}
