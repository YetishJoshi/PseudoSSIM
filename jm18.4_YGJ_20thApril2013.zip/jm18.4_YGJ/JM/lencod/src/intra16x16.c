/*!
*************************************************************************************
 * \file intra16x16.c
 *
 * \brief
 *    Intra 16x16 mode functions
 *
 * \author
 *    Main contributors (see contributors.h for copyright, address and affiliation details)
 *    - Alexis Michael Tourapis         <alexismt@ieee.org>
 *************************************************************************************
 */

#include "contributors.h"

#include "global.h"
#include "image.h"
#include "mb_access.h"
#include "transform.h"
#include "memalloc.h"

// Added YGJ 3rd Feb 2012
#include <ygj_functions.h>

/*!
 ************************************************************************
 * \brief
 *    Vertical 16x16 Prediction
 ************************************************************************
 */
static inline void get_i16x16_vertical(imgpel **cur_pred, imgpel *PredPel)
{
  int j;
  for (j = 0; j < MB_BLOCK_SIZE; j++)
    memcpy(cur_pred[j], &PredPel[1], MB_BLOCK_SIZE * sizeof(imgpel));
}


/*!
 ************************************************************************
 * \brief
 *    Horizontal 16x16 Prediction
 ************************************************************************
 */
static inline void get_i16x16_horizontal(imgpel **cur_pred, imgpel *PredPel)
{
  int i, j;
  imgpel *prediction = &PredPel[16];

  for (j = 0; j < MB_BLOCK_SIZE; j++)
  {  
    prediction++;
    for (i = 0; i < MB_BLOCK_SIZE; i++)
    {
      cur_pred[j][i]  = *prediction;
    }    
  }
}

/*!
 ************************************************************************
 * \brief
 *    DC 16x16 Prediction
 ************************************************************************
 */
static inline void get_i16x16_dc(imgpel **cur_pred, imgpel *PredPel, int left_available, int up_available)
{
  int i, j, s0 = 0, s1 = 0, s2 = 0;

  if (up_available)
  {
    for (i = 1; i < MB_BLOCK_SIZE + 1; ++i)
      s1 += PredPel[i];
  }

  if (left_available)
  {
    for (i = 17; i < 33; ++i)
      s2 += PredPel[i];    // sum vert pix
  }

  if (up_available)
  {
    s0 = left_available
      ? rshift_rnd_sf((s1 + s2),(MB_BLOCK_SHIFT + 1)) // no edge
      : rshift_rnd_sf(s1, MB_BLOCK_SHIFT);          // left edge
  }
  else
  {
    s0 = left_available
      ? rshift_rnd_sf(s2, MB_BLOCK_SHIFT)           // upper edge
      : PredPel[1];                              // top left corner, nothing to predict from
  }

  for (j = 0; j < MB_BLOCK_SIZE; j++)
  {
    for (i = 0; i < MB_BLOCK_SIZE; i++)
      cur_pred[j][i] = (imgpel) s0;    
  }
}

/*!
 ************************************************************************
 * \brief
 *    Plane 16x16 Prediction
 ************************************************************************
 */
static inline void get_i16x16_plane(imgpel **cur_pred, imgpel *PredPel, int max_imgpel_value)
{
  int i, j;
  // plane prediction
  int ih=0, iv=0;
  int ib, ic, iaa;
  imgpel *t_pred = &PredPel[25];
  imgpel *u_pred = &PredPel[8];
  imgpel *b_pred = &PredPel[23];

  for (i = 1; i < 8;++i)
  {
    ih += i*(*(u_pred + i) - *(u_pred - i));
    iv += i*(*t_pred++ - *b_pred--);
  }
  ih += 8 * (*(u_pred + 8) - PredPel[0]);
  iv += 8 * (*t_pred++ - PredPel[0]);

  ib = (5 * ih + 32) >> 6;
  ic = (5 * iv + 32) >> 6;

  iaa=16 * (PredPel[16] + PredPel[32]);

  for (j=0;j< MB_BLOCK_SIZE;++j)
  {
    for (i=0;i< MB_BLOCK_SIZE;++i)
    {
      cur_pred[j][i]= (imgpel) iClip1( max_imgpel_value, rshift_rnd_sf((iaa + (i - 7) * ib + (j - 7) * ic), 5));// store plane prediction
    }
  }
}

/*!
 ************************************************************************
 * \brief
 *    Set intra 16x16 prediction samples
 *
 *  \par Input:
 *
 *  \par Output:
 *      none
 ************************************************************************
 */
void set_intrapred_16x16(Macroblock *currMB, ColorPlane pl, int *left_available, int *up_available, int *all_available)
{
  VideoParameters *p_Vid = currMB->p_Vid;
  InputParameters *p_Inp = currMB->p_Inp;

  int i;
  imgpel  *PredPel = currMB->intra16x16_pred[pl];  // array of predictor pels
  imgpel **img_enc = (currMB->p_Slice->P444_joined)? p_Vid->enc_picture->p_img[pl]: p_Vid->enc_picture->p_curr_img;

  PixelPos pix_b;
  PixelPos pix_a;
  PixelPos pix_d;

  int *mb_size = p_Vid->mb_size[IS_LUMA];

  p_Vid->getNeighbour(currMB, -1,  -1, mb_size, &pix_d);
  p_Vid->getNeighbour(currMB, -1,    0, mb_size, &pix_a);
  p_Vid->getNeighbour(currMB,    0,   -1, mb_size, &pix_b);

  if (p_Inp->UseConstrainedIntraPred == 0)
  {
    *up_available   = pix_b.available;
    *left_available = pix_a.available;
    *all_available  = pix_d.available;
  }
  else
  {
    *up_available   = pix_b.available ? p_Vid->intra_block[pix_b.mb_addr] : 0;
    *left_available = pix_a.available ? p_Vid->intra_block[pix_a.mb_addr] : 0;
    *all_available  = pix_d.available ? p_Vid->intra_block[pix_d.mb_addr] : 0;
  }

  // form predictor pels
  if (*up_available)
  {
    memcpy(&PredPel[1], &img_enc[pix_b.pos_y][pix_b.pos_x], MB_BLOCK_SIZE * sizeof(imgpel));
  }
  else
  {
    for (i = 1; i < 17; ++i)
      PredPel[i] = (imgpel) p_Vid->dc_pred_value;
  }

  if (*left_available)
  {
    int pos_y = pix_a.pos_y;
    int pos_x = pix_a.pos_x;

    for (i = 1; i < MB_BLOCK_SIZE + 1; ++i)
      PredPel[i + 16] = img_enc[pos_y++][pos_x];
  }
  else
  {
    for (i = 17; i < 33; ++i)
      PredPel[i] = (imgpel) p_Vid->dc_pred_value;
  }

  if (*all_available)
  {
    PredPel[0] = img_enc[pix_d.pos_y][pix_d.pos_x];
  }
  else
  {
    PredPel[0] = p_Vid->dc_pred_value;
  }
}


/*!
 ************************************************************************
 * \brief
 *    Set intra 16x16 prediction samples (MBAFF)
 *
 *  \par Input:
 *
 *  \par Output:
 *      none
 ************************************************************************
 */
void set_intrapred_16x16_mbaff(Macroblock *currMB, ColorPlane pl, int *left_available, int *up_available, int *all_available)
{
  VideoParameters *p_Vid = currMB->p_Vid;
  InputParameters *p_Inp = currMB->p_Inp;

  int i;
  imgpel  *PredPel = currMB->intra16x16_pred[pl];  // array of predictor pels
  imgpel **img_enc = p_Vid->enc_picture->p_curr_img;

  PixelPos pix_b;
  PixelPos pix_a[17];

  int *mb_size = p_Vid->mb_size[IS_LUMA];

  for (i = 0; i < 17; ++i)
  {
    p_Vid->getNeighbour(currMB, -1,  i - 1, mb_size, &pix_a[i]);
  }

  p_Vid->getNeighbour(currMB,    0,   -1, mb_size, &pix_b);

  if (p_Inp->UseConstrainedIntraPred == 0)
  {
    *up_available   = pix_b.available;
    *left_available = pix_a[1].available;
    *all_available  = pix_a[0].available;
  }
  else
  {
    *up_available  = pix_b.available ? p_Vid->intra_block[pix_b.mb_addr] : 0;
    for (i=1, *left_available=1; i<17;++i)
      *left_available &= pix_a[i].available ? p_Vid->intra_block[pix_a[i].mb_addr]: 0;
    *all_available = pix_a[0].available ? p_Vid->intra_block[pix_a[0].mb_addr]: 0;
  }

  // form predictor pels
  if (*up_available)
  {
    memcpy(&PredPel[1], &img_enc[pix_b.pos_y][pix_b.pos_x], MB_BLOCK_SIZE * sizeof(imgpel));
  }
  else
  {
    for (i = 1; i < 17; ++i)
      PredPel[i] = (imgpel) p_Vid->dc_pred_value;
  }

  if (*left_available)
  {
    for (i = 1; i < MB_BLOCK_SIZE + 1; ++i)
      PredPel[i + 16] = img_enc[pix_a[i].pos_y][pix_a[i].pos_x];
  }
  else
  {
    for (i = 17; i < 33; ++i)
      PredPel[i] = (imgpel) p_Vid->dc_pred_value;
  }

  if (*all_available)
  {
    PredPel[0] = img_enc[pix_a[0].pos_y][pix_a[0].pos_x];
  }
  else
  {
    PredPel[0] = p_Vid->dc_pred_value;
  }
}


/*!
 ************************************************************************
 * \brief
 *    Generate 16x16 intra prediction block
 *
 *  \par Input:
 *     Starting point of current 16x16 block image posision
 *
 *  \par Output:
 *      none
 ************************************************************************
 */
void get_intrapred_16x16(Macroblock *currMB, ColorPlane pl, int i16x16_mode, int left_available, int up_available)
{
  imgpel        *PredPel = currMB->intra16x16_pred[pl];  // array of predictor pels
  imgpel ***curr_mpr_16x16 = currMB->p_Slice->mpr_16x16[pl];

  switch (i16x16_mode)
  {
  case VERT_PRED_16 :    
    get_i16x16_vertical(curr_mpr_16x16[VERT_PRED_16], PredPel);
    break;
  case HOR_PRED_16 :
    get_i16x16_horizontal(curr_mpr_16x16[HOR_PRED_16], PredPel);
    break;
  case DC_PRED_16 :
    get_i16x16_dc(curr_mpr_16x16[DC_PRED_16], PredPel, left_available, up_available);
    break;
  case PLANE_16 :
    get_i16x16_plane(curr_mpr_16x16[PLANE_16], PredPel, currMB->p_Vid->max_imgpel_value);
    break;
  default:
    printf("invalid prediction mode \n");
    break;
  }
}

distblk distI16x16_satd(Macroblock *currMB, imgpel **img_org, imgpel **pred_img, distblk min_cost)
{
  Slice *currSlice = currMB->p_Slice;
  int   **M7 = NULL;
  int   **tblk4x4 = currSlice->tblk4x4;
  int   ****i16blk4x4 = currSlice->i16blk4x4;
  imgpel *cur_img, *prd_img;
  distblk current_intra_sad_2 = 0;
  int ii, jj, i, j, i32Cost = 0;
  int imin_cost = dist_down(min_cost);

  for (j = 0; j < MB_BLOCK_SIZE; j++)
  {
    cur_img = &img_org[currMB->opix_y + j][currMB->pix_x];
    prd_img = pred_img[j];
    for (i = 0; i < MB_BLOCK_SIZE; i++)
    {
      i16blk4x4[j >> 2][i >> 2][j & 0x03][i & 0x03] = cur_img[i] - prd_img[i];
    }
  }

  for (jj = 0; jj < 4; jj++)
  {
    for (ii = 0; ii < 4;ii++)
    {
      M7 = i16blk4x4[jj][ii];
      hadamard4x4(M7, M7);
      i32Cost += iabs(M7[0][1]);
      i32Cost += iabs(M7[0][2]);
      i32Cost += iabs(M7[0][3]);

      if (i32Cost > imin_cost)
        return (min_cost);

      for (j = 1; j < 4; j++)
      {
        //i32Cost =0;
        i32Cost += iabs(M7[j][0]);
        i32Cost += iabs(M7[j][1]);
        i32Cost += iabs(M7[j][2]);
        i32Cost += iabs(M7[j][3]);

        if (i32Cost > imin_cost)
          return (min_cost);
      }
    }
  }

  for (j = 0; j < 4;j++)
  {
    tblk4x4[j][0] = (i16blk4x4[j][0][0][0] >> 1);
    tblk4x4[j][1] = (i16blk4x4[j][1][0][0] >> 1);
    tblk4x4[j][2] = (i16blk4x4[j][2][0][0] >> 1);
    tblk4x4[j][3] = (i16blk4x4[j][3][0][0] >> 1);     
  }

  // Hadamard of DC coeff
  hadamard4x4(tblk4x4, tblk4x4);

  for (j = 0; j < 4; j++)
  {
    i32Cost += iabs(tblk4x4[j][0]);
    i32Cost += iabs(tblk4x4[j][1]);
    i32Cost += iabs(tblk4x4[j][2]);
    i32Cost += iabs(tblk4x4[j][3]);

    if (i32Cost > imin_cost)
      return (min_cost);
  }

  current_intra_sad_2 += (dist_scale((distblk)i32Cost));
  return current_intra_sad_2;
}

distblk distI16x16_sad(Macroblock *currMB, imgpel **img_org, imgpel **pred_img, distblk min_cost)
{
  imgpel *cur_img, *prd_img;
  int i32Cost = 0;
  int i, j; 
  int imin_cost = dist_down(min_cost);

  for (j = 0; j < MB_BLOCK_SIZE; j++)
  {
    cur_img = &img_org[currMB->opix_y + j][currMB->pix_x];
    prd_img = pred_img[j];
    for (i = 0; i < MB_BLOCK_SIZE; i++)
    {
      i32Cost += iabs( *cur_img++ - *prd_img++ );
    }

    if (i32Cost > imin_cost)
      return (min_cost);
  }

  return (dist_scale((distblk) i32Cost));
}

distblk distI16x16_sse(Macroblock *currMB, imgpel **img_org, imgpel **pred_img, distblk min_cost)
{
  imgpel *cur_img, *prd_img;  
  int i, j, i32Cost = 0; 
  int imin_cost = dist_down(min_cost);

  for (j = 0; j < MB_BLOCK_SIZE;j++)
  {
    cur_img = &img_org[currMB->opix_y + j][currMB->pix_x];
    prd_img = pred_img[j];
    for (i = 0; i < MB_BLOCK_SIZE; i++)
    {
      i32Cost += iabs2( *cur_img++ - *prd_img++ );
    }

    if (i32Cost > imin_cost)
      return (min_cost);
  }

  return (dist_scale((distblk) i32Cost));
}


/*!
 ************************************************************************
 * \brief
 *    Find best 16x16 based intra mode
 *
 * \par Input:
 *    Image parameters, pointer to best 16x16 intra mode
 *
 * \par Output:
 *    best 16x16 based SAD
 ************************************************************************/
distblk find_sad_16x16_JM(Macroblock *currMB)
{
  Slice *currSlice = currMB->p_Slice;
  VideoParameters *p_Vid = currMB->p_Vid;
  InputParameters *p_Inp = currMB->p_Inp;
  distblk current_intra_sad_2, best_intra_sad2 = DISTBLK_MAX;
  int k;
  imgpel  ***curr_mpr_16x16 = currSlice->mpr_16x16[0];

  int up_avail, left_avail, left_up_avail;

  currMB->i16mode = DC_PRED_16;
  
  currSlice->set_intrapred_16x16(currMB, PLANE_Y, &left_avail, &up_avail, &left_up_avail);
  // For speed purposes, we should just unify all planes
  if (currSlice->P444_joined)
  {
    currSlice->set_intrapred_16x16(currMB, PLANE_U, &left_avail, &up_avail, &left_up_avail);
    currSlice->set_intrapred_16x16(currMB, PLANE_V, &left_avail, &up_avail, &left_up_avail);
  }

  for (k = VERT_PRED_16; k <= PLANE_16; k++)
  {
    if (p_Inp->IntraDisableInterOnly == 0 || (currSlice->slice_type != I_SLICE && currSlice->slice_type != SI_SLICE) )
    {
      if (p_Inp->Intra16x16ParDisable && (k == VERT_PRED_16||k == HOR_PRED_16))
        continue;

      if (p_Inp->Intra16x16PlaneDisable && k == PLANE_16)
        continue;
    }
    //check if there are neighbours to predict from
    if (!((k == VERT_PRED_16 && !up_avail) || (k == HOR_PRED_16 && !left_avail) || (k == PLANE_16 && (!left_avail || !up_avail || !left_up_avail))))
    {
      get_intrapred_16x16(currMB, PLANE_Y, k, left_avail, up_avail);
      current_intra_sad_2 = currSlice->distI16x16(currMB, p_Vid->pCurImg, curr_mpr_16x16[k], best_intra_sad2);
      if (currSlice->P444_joined)
      {
        get_intrapred_16x16(currMB, PLANE_U, k, left_avail, up_avail);
        current_intra_sad_2 += currSlice->distI16x16(currMB, p_Vid->pImgOrg[1], currSlice->mpr_16x16[1][k], best_intra_sad2);
        get_intrapred_16x16(currMB, PLANE_V, k, left_avail, up_avail);
        current_intra_sad_2 += currSlice->distI16x16(currMB, p_Vid->pImgOrg[2], currSlice->mpr_16x16[2][k], best_intra_sad2);
      }

      if (current_intra_sad_2 < best_intra_sad2)
      {
        best_intra_sad2 = current_intra_sad_2;
        currMB->i16mode = (char) k; // update best intra mode
      }
    }    
  }

  return best_intra_sad2;
}

//	/*!
// ***********************************************************************
// * \brief
// *   Based upon compute_ssim8x8_cost & distI16x16_sse. Used in rdopt.c, when Distortion Metric, based on MDDistortion value from Configuration file
//  Created by YGJ 31st Oct 2011
// ***********************************************************************
// */
distblk distI16x16_ssim(Macroblock *currMB, imgpel **img_org, imgpel **pred_img, distblk min_cost)
{	
	int i32Cost = 0; 
	int imin_cost = dist_down(min_cost);
			
	// Stage Two - Run SSIM Distortion Metric, then convert to  type 'distblk'	
	i32Cost = YGJ_SSIMDistMetric(currMB->p_Vid, &img_org[ currMB->opix_y], pred_img, currMB->pix_x, 0, 16, -1);

	if (i32Cost > imin_cost)  
		return (min_cost);

	return (dist_scale((distblk) i32Cost));
}



distblk distI16x16_ssimwsatd_Had1st(Macroblock *currMB, imgpel **img_org, imgpel **pred_img, distblk min_cost)
{		
	int iSSIMCost = 0; 
    int tSSIMCost = 0;
	//int tempiSSIMCost = 0;
	int iCost = 0;

    int i4x4Cost = 0;
	//int imin_cost = dist_down(min_cost);
			
	Slice *currSlice = currMB->p_Slice;
	int   **M7 = NULL;
	int   **tblk4x4 = currSlice->tblk4x4;
	int   ****i16blk4x4 = currSlice->i16blk4x4;
	imgpel *cur_img, *prd_img;
	distblk current_intra_sad_2 = 0;
	int ii, jj, i, j, i32Cost = 0;
	int imin_cost = dist_down(min_cost);


    if (currSlice->p_Vid->p_Inp->LogDistSamples == TRUE)
    {
        // Hadamard and PseudoSSIM so that both values can be logged

	    //--------------------------------------------------------------------------------------------	
	    // Stage Two - Run SSIM Distortion Metric, then convert to  type 'distblk'	
	    //--------------------------------------------------------------------------------------------

	    for (j = 0; j < MB_BLOCK_SIZE; j++)
	    {
		    cur_img = &img_org[currMB->opix_y + j][currMB->pix_x];
		    prd_img = pred_img[j];
		    for (i = 0; i < MB_BLOCK_SIZE; i++)
		    {
			    i16blk4x4[j >> 2][i >> 2][j & 0x03][i & 0x03] = cur_img[i] - prd_img[i];
		    }
	    }

	    for (jj = 0; jj < 4; jj++)
	    {
		    for (ii = 0; ii < 4;ii++)
		    {
			    // YGJ 20th April 2012 - Accumulating cost on a 4x4 basis like Hadamard is done here

			    M7 = i16blk4x4[jj][ii];
			    hadamard4x4(M7, M7);
                i4x4Cost = 0;
			    i4x4Cost += iabs(M7[0][1]);
			    i4x4Cost += iabs(M7[0][2]);
			    i4x4Cost += iabs(M7[0][3]);



			    for (j = 1; j < 4; j++)
			    {
				    //i32Cost =0;
				    i4x4Cost += iabs(M7[j][0]);
				    i4x4Cost += iabs(M7[j][1]);
				    i4x4Cost += iabs(M7[j][2]);
				    i4x4Cost += iabs(M7[j][3]);
				            
			    }
                       
                // 27th Nov 2012 - Rearrange to run PseudoSSIM first and only SATD if -1
                // YGJ 17th Oct 2012 Only use PseudoSSIM if not -1				
            
                // YGJ 6th March 2013 - Unable to consider how to optimise this so that SATD only occurs if SSIM is -1, since here in Intra 16x16 Hadamard occurs twice.
                // The first at the sub 4x4 pixels (excluding 0,0 pixel in 4x4 array). The second on each and every 0,0 pixel in the Macroblock.
                // Unless I am able to reverse Hadamard and work out which pixels relate to it or 
                tSSIMCost = YGJ_SSIMDistMetric(currMB->p_Vid, &img_org[(currMB->opix_y + (jj << 2))], &pred_img[(jj << 2)], (currMB->pix_x + (ii << 2)), (ii << 2), 4, i4x4Cost);

                // YGJ 21st Feb 2013 - Store SATD Values
                //Set_YGJ_SATD4x4(-1);

                // YGJ 4th Jan 2013 - Tried to keep it simple -  One 4x4 Block at a time
                iCost += tSSIMCost > -1 ? tSSIMCost : i4x4Cost;		

			    if (iCost > imin_cost)
				    return (min_cost);

		    }
	    }

        // Wed 13th March 2013
        // Only to run if Hadamard has been run throughout i.e. logging mode.
        // Also if at this stage SSIM is unable to be less than mincost therefore relie on Hadamard score.

	    for (j = 0; j < 4;j++)
	    {
		    tblk4x4[j][0] = (i16blk4x4[j][0][0][0] >> 1);
		    tblk4x4[j][1] = (i16blk4x4[j][1][0][0] >> 1);
		    tblk4x4[j][2] = (i16blk4x4[j][2][0][0] >> 1);
		    tblk4x4[j][3] = (i16blk4x4[j][3][0][0] >> 1);     
	    }

	    // Hadamard of DC coeff
	    hadamard4x4(tblk4x4, tblk4x4);

	    for (j = 0; j < 4; j++)
	    {
		    i32Cost += iabs(tblk4x4[j][0]);
		    i32Cost += iabs(tblk4x4[j][1]);
		    i32Cost += iabs(tblk4x4[j][2]);
		    i32Cost += iabs(tblk4x4[j][3]);
						
		    iCost += i32Cost;

		    if (iCost > imin_cost)
			    return (min_cost);
	    }	
    }

	return (dist_scale((distblk) iCost));
}


distblk distI16x16_ssimwsatd_SSIM1st(Macroblock *currMB, imgpel **img_org, imgpel **pred_img, distblk min_cost)
{		
	int iSSIMCost = 0; 
    int tSSIMCost = 0;
	//int tempiSSIMCost = 0;
	int iCost = 0;

    int i4x4Cost = 0;
	//int imin_cost = dist_down(min_cost);
			
	Slice *currSlice = currMB->p_Slice;
	int   **M7 = NULL;
	int   **tblk4x4 = currSlice->tblk4x4;
	int   ****i16blk4x4 = currSlice->i16blk4x4;
	imgpel *cur_img, *prd_img;
	distblk current_intra_sad_2 = 0;
	int ii, jj, i, j, i32Cost = 0;
	int imin_cost = dist_down(min_cost);
    
    //===============================
        
    // Hadamard only if PseudoSSIM == -1
	
    for (jj = 0; jj < 4; jj++)
	{
		for (ii = 0; ii < 4;ii++)
		{
            // 27th Nov 2012 - Rearrange to run PseudoSSIM first and only SATD if -1
            // YGJ 17th Oct 2012 Only use PseudoSSIM if not -1				
            
            // YGJ 6th March 2013 - Unable to consider how to optimise this so that SATD only occurs if SSIM is -1, since here in Intra 16x16 Hadamard occurs twice.
            // The first at the sub 4x4 pixels (excluding 0,0 pixel in 4x4 array). The second on each and every 0,0 pixel in the Macroblock.
            // Unless I am able to reverse Hadamard and work out which pixels relate to it or 
            tSSIMCost = YGJ_SSIMDistMetric(currMB->p_Vid, &img_org[(currMB->opix_y + (jj << 2))], &pred_img[(jj << 2)], (currMB->pix_x + (ii << 2)), (ii << 2), 4, -1);

            // YGJ 21st Feb 2013 - Store SATD Values
            //Set_YGJ_SATD4x4(-1);

            // YGJ 4th Jan 2013 - Tried to keep it simple -  One 4x4 Block at a time
            if (tSSIMCost > -1)
                iCost += tSSIMCost;
            else
            {
                j = jj << 2;
                i = ii << 2;
                for (j ; j < j + 4 ; j++)
	            {
		            cur_img = &img_org[currMB->opix_y + j][currMB->pix_x];
		            prd_img = pred_img[j];
                    for (i; i < i+4 ; i++)
		            {
			            i16blk4x4[jj][ii][j & 0x03][i & 0x03] = cur_img[i] - prd_img[i];
		            }
	            }
                			    
                // YGJ 20th April 2012 - Accumulating cost on a 4x4 basis like Hadamard is done here

			    M7 = i16blk4x4[jj][ii];
			    hadamard4x4(M7, M7);
                i4x4Cost = 0;
			    i4x4Cost += iabs(M7[0][1]);
			    i4x4Cost += iabs(M7[0][2]);
			    i4x4Cost += iabs(M7[0][3]);


			    for (j = 1; j < 4; j++)
			    {
				    //i32Cost =0;
				    i4x4Cost += iabs(M7[j][0]);
				    i4x4Cost += iabs(M7[j][1]);
				    i4x4Cost += iabs(M7[j][2]);
				    i4x4Cost += iabs(M7[j][3]);
				            
			    }
                iCost += i4x4Cost;
            }
            
			if (iCost > imin_cost)
				return (min_cost);
		}
	}


	return (dist_scale((distblk) iCost));
}


distblk distI16x16_ssimwsatd(Macroblock *currMB, imgpel **img_org, imgpel **pred_img, distblk min_cost)
{		

	//int iCost = 0;

	Slice *currSlice = currMB->p_Slice;


     //iCost = 
        return( (currSlice->p_Vid->p_Inp->LogDistSamples == TRUE)?
         distI16x16_ssimwsatd_Had1st(currMB, img_org, pred_img, min_cost)
         : distI16x16_ssimwsatd_SSIM1st (currMB, img_org, pred_img, min_cost));



	//return (dist_scale((distblk) iCost));
}

//*************************************************
//**************************************************

distblk distI16x16_ssimwsse(Macroblock *currMB, imgpel **img_org, imgpel **pred_img, distblk min_cost)
{		
	int iSSIMCost = 0; 
	//int tempiSSIMCost = 0;
	int iCost = 0;
    int i4x4Cost = 0;
	//int imin_cost = dist_down(min_cost);
			
	Slice *currSlice = currMB->p_Slice;
	int   **M7 = NULL;
	int   **tblk4x4 = currSlice->tblk4x4;
	int   ****i16blk4x4 = currSlice->i16blk4x4;
	imgpel *cur_img, *prd_img;
	distblk current_intra_sad_2 = 0;
	int ii, jj, i, j, i32Cost = 0;
	int imin_cost = dist_down(min_cost);

 
    for (j = 0; j < MB_BLOCK_SIZE; j++)
	{
		cur_img = &img_org[currMB->opix_y + j][currMB->pix_x];
		prd_img = pred_img[j];
		for (i = 0; i < MB_BLOCK_SIZE; i++)
		{
			i16blk4x4[j >> 2][i >> 2][j & 0x03][i & 0x03] = cur_img[i] - prd_img[i];
		}
	}

	for (jj = 0; jj < 4; jj++)
	{
		for (ii = 0; ii < 4;ii++)
		{
			// YGJ 4tth Jan 2013 - Accumulating cost on a 4x4 basis
            // SSE is Dimensionless and can actually operate by assessing on a pixel by pixel basis.
            // However SSIM is limited by its WIndow Size as it factors in the relative changes to the block
            // By taking SSE and SSIM in blocks of 4x4 it is possible to use both.
        
            M7 = i16blk4x4[jj][ii];
            i4x4Cost += iabs2(M7[0][0]);            			
            i4x4Cost += iabs2(M7[0][1]);
			i4x4Cost += iabs2(M7[0][2]);
			i4x4Cost += iabs2(M7[0][3]);
                        
            for (j = 1; j < 4; j++)			 
            {
				    i4x4Cost += iabs2(M7[j][0]);
				    i4x4Cost += iabs2(M7[j][1]);
				    i4x4Cost += iabs2(M7[j][2]);
				    i4x4Cost += iabs2(M7[j][3]);
            }


            i32Cost += i4x4Cost;

			
            //  27th Nov 2012 - Rearrange to run PseudoSSIM first and only SATD if -1
            // YGJ 17th Oct 2012 Only use PseudoSSIM if not -1				
            iSSIMCost += YGJ_SSIMDistMetric(currMB->p_Vid, &img_org[(currMB->opix_y + (jj << 2))], &pred_img[(jj << 2)], (currMB->pix_x + (ii << 2)), (ii << 2), 4, i4x4Cost);
                                    
            // YGJ 4th Jan 2013 - Tried to keep it simple -  One 4x4 Block at a time
            iCost = iSSIMCost > -1 ? iSSIMCost : i32Cost;            			
            
            if (iCost > imin_cost)			
                return (min_cost);

		}
	}
	
	return (dist_scale((distblk) iCost));
}


//*************************************************
//**************************************************

distblk distI16x16_ssimwsad(Macroblock *currMB, imgpel **img_org, imgpel **pred_img, distblk min_cost)
{		
	int iSSIMCost = 0; 
	//int tempiSSIMCost = 0;
	int iCost = 0;
    int i4x4Cost = 0;
	//int imin_cost = dist_down(min_cost);
			
	Slice *currSlice = currMB->p_Slice;
	int   **M7 = NULL;
	int   **tblk4x4 = currSlice->tblk4x4;
	int   ****i16blk4x4 = currSlice->i16blk4x4;
	imgpel *cur_img, *prd_img;
	distblk current_intra_sad_2 = 0;
	int ii, jj, i, j, i32Cost = 0;
	int imin_cost = dist_down(min_cost);

 
    for (j = 0; j < MB_BLOCK_SIZE; j++)
	{
		cur_img = &img_org[currMB->opix_y + j][currMB->pix_x];
		prd_img = pred_img[j];
		for (i = 0; i < MB_BLOCK_SIZE; i++)
		{
			i16blk4x4[j >> 2][i >> 2][j & 0x03][i & 0x03] = cur_img[i] - prd_img[i];
		}
	}

	for (jj = 0; jj < 4; jj++)
	{
		for (ii = 0; ii < 4;ii++)
		{
			// YGJ 4tth Jan 2013 - Accumulating cost on a 4x4 basis
            // SAD is Dimensionless and can actually operate by aSADssing on a pixel by pixel basis.
            // However SSIM is limited by its WIndow Size as it factors in the relative changes to the block
            // By taking SAD and SSIM in blocks of 4x4 it is possible to use both.
        
            M7 = i16blk4x4[jj][ii];
            i4x4Cost += iabs(M7[0][0]);            			
            i4x4Cost += iabs(M7[0][1]);
			i4x4Cost += iabs(M7[0][2]);
			i4x4Cost += iabs(M7[0][3]);
                        
            for (j = 1; j < 4; j++)			 
            {
				    i4x4Cost += iabs(M7[j][0]);
				    i4x4Cost += iabs(M7[j][1]);
				    i4x4Cost += iabs(M7[j][2]);
				    i4x4Cost += iabs(M7[j][3]);
            }

			i32Cost += i4x4Cost;

            //  27th Nov 2012 - Rearrange to run PseudoSSIM first and only SATD if -1
            // YGJ 17th Oct 2012 Only use PseudoSSIM if not -1				
            iSSIMCost += YGJ_SSIMDistMetric(currMB->p_Vid, &img_org[(currMB->opix_y + (jj << 2))], &pred_img[(jj << 2)], (currMB->pix_x + (ii << 2)), (ii << 2), 4, i4x4Cost);
                                    
            // YGJ 4th Jan 2013 - Tried to keep it simple -  One 4x4 Block at a time
            iCost = iSSIMCost > -1 ? iSSIMCost : i32Cost;            			
            
            if (iCost > imin_cost)			
                return (min_cost);

		}
	}
	
	return (dist_scale((distblk) iCost));
}
